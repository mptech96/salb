<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureRoutePermission
{
    private const MANAGER_ROLES = [
        'SUPER_ADMIN',
        'MANAGER',
        'COMPANY_MANAGER',
        'COMPANY_ADMIN',
        'COMPANY_OWNER',
        'ADMIN',
    ];

    private const RESOURCE_MAP = [
        'branches' => 'branches',
        'items' => 'items',
        'cars' => 'cars',
        'suppliers' => 'suppliers',
        'customers' => 'customers',
        'purchase-invoices' => 'purchases',
        'sales-invoices' => 'sales',
        'vouchers' => 'vouchers',
        'expenses' => 'expenses',
        'shipments' => 'shipments',
    ];

    public function handle(Request $request, Closure $next): Response
    {
        $roleCode = strtoupper((string) $request->attributes->get('effective_role_code', ''));
        $isSupportMode = (bool) $request->attributes->get('is_support_mode', false);

        if ($isSupportMode || in_array($roleCode, self::MANAGER_ROLES, true)) {
            return $next($request);
        }

        $routeName = (string) optional($request->route())->getName();
        $routeUri = (string) optional($request->route())->uri();

        // نحافظ على صلاحيات مدير الفرع الإدارية القديمة، بينما تبقى
        // عمليات الفروع الحساسة محكومة داخل BranchController.
        if ($roleCode === 'BRANCH_MANAGER') {
            $branchManagerAllowed = str_starts_with($routeName, 'users.')
                || in_array($routeName, ['branches.index', 'branches.show'], true)
                || $routeUri === 'roles'
                || $routeUri === 'audit-logs'
                || $routeUri === 'dashboard';

            if ($branchManagerAllowed) {
                return $next($request);
            }
        }

        $method = strtoupper($request->method());
        $isReadRequest = in_array($method, ['GET', 'HEAD'], true);

        // لا توجد صلاحيات مستقلة للأصول في جدول permissions الحالي؛
        // نحافظ على وصول المحاسب للوحدة كما كانت مصممة في الواجهة.
        if ($roleCode === 'ACCOUNTANT' && str_starts_with($routeUri, 'fixed-asset')) {
            return $next($request);
        }

        // الأدوار التشغيلية الحالية تملك صلاحيات عرض عامة لبعض الوحدات،
        // لذلك نحدد الكتابة بالدور حتى لا تتحول صلاحية view إلى تعديل وحذف.
        if ($roleCode === 'ACCOUNTANT' && (
            str_starts_with($routeUri, 'accounts')
            || str_starts_with($routeUri, 'journal-entries')
            || str_starts_with($routeUri, 'workers')
            || str_starts_with($routeUri, 'payroll')
        )) {
            return $next($request);
        }

        if ($roleCode === 'STORE' && str_starts_with($routeUri, 'inventory')) {
            return $next($request);
        }

        if (!$isReadRequest && $this->isManagerOnlyWriteRoute($routeUri)) {
            return response()->json([
                'status' => false,
                'code' => 'WRITE_PERMISSION_DENIED',
                'message' => 'دورك يسمح بعرض هذه الوحدة فقط، ولا يسمح بالتعديل عليها.',
            ], 403);
        }

        $requiredPermission = $this->requiredPermission($request);

        if (!$requiredPermission) {
            return response()->json([
                'status' => false,
                'code' => 'PERMISSION_NOT_MAPPED',
                'message' => 'لم يتم تعريف صلاحية آمنة لهذا المسار.',
            ], 403);
        }

        $permissions = $request->attributes->get('permission_codes', []);

        if (!is_array($permissions) || !in_array($requiredPermission, $permissions, true)) {
            return response()->json([
                'status' => false,
                'code' => 'PERMISSION_DENIED',
                'message' => 'لا تملك الصلاحية المطلوبة لتنفيذ هذه العملية.',
                'required_permission' => $requiredPermission,
            ], 403);
        }

        return $next($request);
    }

    private function isManagerOnlyWriteRoute(string $uri): bool
    {
        return str_starts_with($uri, 'company-settings')
            || str_starts_with($uri, 'accounts')
            || str_starts_with($uri, 'journal-entries')
            || str_starts_with($uri, 'inventory')
            || str_starts_with($uri, 'workers')
            || str_starts_with($uri, 'payroll')
            || str_starts_with($uri, 'official-documents')
            || str_starts_with($uri, 'drivers');
    }

    private function requiredPermission(Request $request): ?string
    {
        $routeName = (string) optional($request->route())->getName();

        if ($routeName && preg_match('/^([a-z-]+)\.(index|show|store|update|destroy)$/', $routeName, $matches)) {
            $resource = $matches[1];
            $action = $matches[2];

            if ($resource === 'users') {
                return 'users.view';
            }

            if ($resource === 'drivers') {
                return 'drivers.view';
            }

            if ($resource === 'workers') {
                return 'workers.view';
            }

            if (isset(self::RESOURCE_MAP[$resource])) {
                $module = self::RESOURCE_MAP[$resource];

                return match ($action) {
                    'index', 'show' => $module . '.view',
                    'store' => $module . '.create',
                    'update' => $module . '.update',
                    'destroy' => $module . '.delete',
                    default => null,
                };
            }
        }

        $uri = (string) optional($request->route())->uri();
        if ($uri === 'roles') {
            return 'users.view';
        }

        if ($uri === 'audit-logs') {
            return 'audit_logs.view';
        }

        if (str_starts_with($uri, 'company-settings')) {
            return 'settings.view';
        }

        if (str_starts_with($uri, 'accounts')
            || str_starts_with($uri, 'journal-entries')
            || $uri === 'trial-balance') {
            return 'statements.view';
        }

        if (str_starts_with($uri, 'inventory')) {
            return 'inventory.view';
        }

        if ($uri === 'shipments/sell') {
            return 'sales.create';
        }

        if ($uri === 'shipments/{id}/approve') {
            return 'shipments.approve';
        }

        if (str_starts_with($uri, 'shipment-costs')
            || str_contains($uri, '/costs')) {
            return 'shipments.update';
        }

        if (str_starts_with($uri, 'workers/')
            || str_starts_with($uri, 'payroll')) {
            return 'workers.view';
        }

        if (str_starts_with($uri, 'fixed-asset')) {
            return 'dashboard.view';
        }

        if ($uri === 'dashboard') {
            return 'dashboard.view';
        }

        if (str_starts_with($uri, 'reports/')) {
            return 'reports.view';
        }

        if (str_starts_with($uri, 'statements/')) {
            return 'statements.view';
        }

        if (str_starts_with($uri, 'official-documents')) {
            return 'official_documents.view';
        }

        // مسارات السائقين لا تملك حاليًا صلاحيات create/update/delete مستقلة.
        if (str_starts_with($uri, 'drivers')) {
            return 'drivers.view';
        }

        // موارد بشرية: الصلاحية الحالية العامة للوحدة.
        if (str_starts_with($uri, 'workers')) {
            return 'workers.view';
        }

        return null;
    }
}
