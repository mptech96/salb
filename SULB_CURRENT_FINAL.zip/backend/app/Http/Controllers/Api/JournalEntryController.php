<?php

namespace App\Http\Controllers\Api;

use App\Domain\Accounting\Services\JournalService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class JournalEntryController extends Controller
{
    public function store(Request $request, JournalService $service)
    {
        $validated = $request->validate([
            'entry_date' => ['required', 'date'],
            'description' => ['nullable', 'string'],
            'source_type' => ['nullable', 'string', 'max:50'],
            'source_id' => ['nullable', 'integer'],
            'lines' => ['required', 'array', 'min:2'],
            'lines.*.account_id' => ['required', 'integer'],
            'lines.*.cost_center_id' => ['nullable', 'integer'],
            'lines.*.debit' => ['nullable', 'numeric', 'min:0'],
            'lines.*.credit' => ['nullable', 'numeric', 'min:0'],
            'lines.*.description' => ['nullable', 'string'],
        ]);

        try {
            $id = $service->post([
                ...$validated,
                'company_id' => (int) $request->header('X-Company-ID'),
                'branch_id' => (int) $request->header('X-Branch-ID'),
                'created_by' => (int) $request->header('X-User-ID'),
                'status' => 'POSTED',
            ]);

            return response()->json([
                'status' => true,
                'message' => 'تم ترحيل القيد بنجاح.',
                'id' => $id,
            ], 201);
        } catch (\Throwable $e) {
            return response()->json([
                'status' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    public function show(
        Request $request,
        int $id,
        JournalService $service
    ) {
        $data = $service->show(
            (int) $request->header('X-Company-ID'),
            $id
        );

        if (!$data) {
            return response()->json([
                'status' => false,
                'message' => 'القيد غير موجود.',
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => $data,
        ]);
    }
}
