<?php

namespace App\Http\Controllers\Api;

use App\Domain\Accounting\Services\TrialBalanceService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TrialBalanceController extends Controller
{
    public function index(
        Request $request,
        TrialBalanceService $service
    ) {
        $companyId = (int) $request->header('X-Company-ID');
        $roleCode = strtoupper(
            trim((string) $request->header('X-Role-Code', ''))
        );

        $branchId = in_array(
            $roleCode,
            ['SUPER_ADMIN', 'MANAGER'],
            true
        )
            ? ($request->filled('branch_id')
                ? $request->integer('branch_id')
                : null)
            : (int) $request->header('X-Branch-ID');

        return response()->json([
            'status' => true,
            'data' => $service->report([
                'company_id' => $companyId,
                'branch_id' => $branchId,
                'financial_year_id' => $request->financial_year_id,
                'cost_center_id' => $request->cost_center_id,
            ]),
        ]);
    }
}
