<?php

namespace App\Domain\Accounting\Services;

use App\Domain\Accounting\Repositories\JournalRepository;
use Illuminate\Support\Facades\DB;

class JournalService
{
    public function __construct(
        private JournalRepository $journals
    ) {}

    public function post(array $data): int
    {
        return DB::transaction(function () use ($data) {
            $companyId = (int) $data['company_id'];
            $branchId = (int) ($data['branch_id'] ?? 0);
            $lines = $data['lines'] ?? [];

            if (!$companyId || !$branchId) {
                throw new \Exception('الشركة والفرع مطلوبان للقيد.');
            }

            $branch = DB::table('branches')
                ->where('id', $branchId)
                ->where('company_id', $companyId)
                ->where('is_active', 1)
                ->first();

            if (!$branch) {
                throw new \Exception('الفرع غير موجود أو لا يتبع الشركة.');
            }

            $financialYear = DB::table('financial_years')
                ->where('company_id', $companyId)
                ->whereDate('start_date', '<=', $data['entry_date'])
                ->whereDate('end_date', '>=', $data['entry_date'])
                ->first();

            if (!$financialYear) {
                throw new \Exception('لا توجد سنة مالية تغطي تاريخ القيد.');
            }

            if ((int) $financialYear->is_closed === 1) {
                throw new \Exception('السنة المالية مقفلة.');
            }

            if (count($lines) < 2) {
                throw new \Exception('القيد يجب أن يحتوي على طرفين على الأقل.');
            }

            $totalDebit = 0;
            $totalCredit = 0;

            foreach ($lines as $index => &$line) {
                $account = DB::table('accounts')
                    ->where('id', $line['account_id'])
                    ->where('company_id', $companyId)
                    ->where('is_active', 1)
                    ->where('is_group', 0)
                    ->where('allow_posting', 1)
                    ->first();

                if (!$account) {
                    throw new \Exception(
                        'الحساب في السطر رقم ' . ($index + 1) .
                        ' غير صالح للترحيل.'
                    );
                }

                $debit = round((float) ($line['debit'] ?? 0), 3);
                $credit = round((float) ($line['credit'] ?? 0), 3);

                if ($debit < 0 || $credit < 0) {
                    throw new \Exception('لا يمكن أن يحتوي القيد على مبالغ سالبة.');
                }

                if ($debit > 0 && $credit > 0) {
                    throw new \Exception(
                        'السطر رقم ' . ($index + 1) .
                        ' لا يمكن أن يكون مدينًا ودائنًا معًا.'
                    );
                }

                if ($debit == 0 && $credit == 0) {
                    throw new \Exception(
                        'السطر رقم ' . ($index + 1) .
                        ' يجب أن يحتوي على مبلغ.'
                    );
                }

                if ((int) $account->allow_cost_center === 1) {
                    $costCenterId = (int) ($line['cost_center_id'] ?? 0);

                    $validCostCenter = DB::table('cost_centers')
                        ->where('id', $costCenterId)
                        ->where('company_id', $companyId)
                        ->where(function ($query) use ($branchId) {
                            $query->whereNull('branch_id')
                                ->orWhere('branch_id', $branchId);
                        })
                        ->where('is_active', 1)
                        ->exists();

                    if (!$validCostCenter) {
                        throw new \Exception(
                            'مركز التكلفة في السطر رقم ' .
                            ($index + 1) .
                            ' غير صالح للفرع.'
                        );
                    }
                } else {
                    $line['cost_center_id'] = null;
                }

                $totalDebit += $debit;
                $totalCredit += $credit;
            }
            unset($line);

            if (round($totalDebit, 3) !== round($totalCredit, 3)) {
                throw new \Exception(
                    'القيد غير متوازن. إجمالي المدين: ' .
                    number_format($totalDebit, 3) .
                    '، إجمالي الدائن: ' .
                    number_format($totalCredit, 3)
                );
            }

            $entryId = $this->journals->createEntry([
                'company_id' => $companyId,
                'branch_id' => $branchId,
                'financial_year_id' => $financialYear->id,
                'cost_center_id' => $data['cost_center_id'] ?? null,
                'entry_number' => $data['entry_number']
                    ?? $this->journals->nextEntryNumber($companyId),
                'entry_date' => $data['entry_date'],
                'source_type' => $data['source_type'] ?? null,
                'source_id' => $data['source_id'] ?? null,
                'description' => $data['description'] ?? null,
                'status' => $data['status'] ?? 'POSTED',
                'created_by' => $data['created_by']
                    ?? request()->header('X-User-ID'),
            ]);

            $this->journals->createLines(
                $entryId,
                $companyId,
                $branchId,
                (int) $financialYear->id,
                $lines
            );

            return $entryId;
        });
    }

    public function show(int $companyId, int $entryId)
    {
        return $this->journals->findWithLines($companyId, $entryId);
    }
}
