"use client";

import { usePathname, useRouter } from "next/navigation";
import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

import api from "@/app/api";
import SystemDialog from "@/components/common/SystemDialog";
import AppSidebar from "@/components/navigation/AppSaidbar";
import {
  companyNavigation,
  platformNavigation,
} from "@/components/navigation/menu";
import {
  MANAGER_ROLES,
  filterNavigation,
  getCompanyLandingPath,
} from "@/components/navigation/access";
import {
  SESSION_CHANGED_EVENT,
  clearAllSessions,
  hasPlatformSessionBackup,
  readSession,
  restorePlatformSession,
  updateSessionPayload,
  type StoredSession,
} from "@/lib/session";

const PUBLIC_PATHS = ["/login", "/register"];
const PLATFORM_PATHS = ["/system-center", "/companies"];
type DialogState = {
  open: boolean;
  type: "success" | "error" | "warning" | "info" | "confirm";
  title: string;
  message: string;
  action: "none" | "logout" | "exit-support";
  confirmText?: string;
  showCancel?: boolean;
};

const emptyDialog: DialogState = {
  open: false,
  type: "info",
  title: "",
  message: "",
  action: "none",
};

function pathMatches(pathname: string, root: string): boolean {
  return pathname === root || pathname.startsWith(`${root}/`);
}

export default function AppShell({
  children,
}: Readonly<{
  children: ReactNode;
}>) {
  const pathname = usePathname();
  const router = useRouter();

  const [ready, setReady] = useState(false);
  const [session, setSession] = useState<StoredSession | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openGroups, setOpenGroups] = useState<Set<string>>(new Set());
  const [dialog, setDialog] = useState<DialogState>(emptyDialog);
  const [dialogLoading, setDialogLoading] = useState(false);

  const isPublicPath = PUBLIC_PATHS.some((path) => pathMatches(pathname, path));
  const user = session?.user ?? null;
  const roleCode = String(user?.role?.role_code || "").toUpperCase();
  const isSupportMode = user?.is_support_mode === true;
  const isPlatformAdmin =
    roleCode === "SUPER_ADMIN" && !user?.company_id && !isSupportMode;

  const syncLocalSession = useCallback(() => {
    setSession(readSession());
  }, []);

  useEffect(() => {
    window.addEventListener(SESSION_CHANGED_EVENT, syncLocalSession);
    window.addEventListener("storage", syncLocalSession);

    return () => {
      window.removeEventListener(SESSION_CHANGED_EVENT, syncLocalSession);
      window.removeEventListener("storage", syncLocalSession);
    };
  }, [syncLocalSession]);

  useEffect(() => {
    let cancelled = false;

    async function hydrateSession() {
      if (isPublicPath) {
        if (!cancelled) {
          setSession(readSession());
          setReady(true);
        }
        return;
      }

      const stored = readSession();

      if (!stored) {
        clearAllSessions();
        router.replace("/login");
        return;
      }

      if (!cancelled) {
        setSession(stored);
      }

      try {
        const response = await api.get("/me");

        if (cancelled) return;

        const refreshed = updateSessionPayload({
          user: response.data.user,
          subscription: response.data.subscription ?? null,
        });

        setSession(refreshed);
      } catch {
        if (!cancelled && window.location.pathname !== "/login") {
          setReady(false);
        }
        return;
      }

      if (!cancelled) {
        setReady(true);
      }
    }

    void hydrateSession();

    return () => {
      cancelled = true;
    };
  }, [isPublicPath, pathname, router]);

  const navigationGroups = useMemo(() => {
    if (!user) return [];

    if (isPlatformAdmin) {
      return platformNavigation;
    }

    const allowAll = isSupportMode || MANAGER_ROLES.has(roleCode);

    return filterNavigation(
      companyNavigation,
      roleCode,
      session?.permissions ?? [],
      allowAll
    );
  }, [isPlatformAdmin, isSupportMode, roleCode, session?.permissions, user]);

  const companyLandingPath = useMemo(() => {
    if (!user || isPlatformAdmin) return "/system-center";

    return getCompanyLandingPath(
      roleCode,
      session?.permissions ?? [],
      isSupportMode
    );
  }, [isPlatformAdmin, isSupportMode, roleCode, session?.permissions, user]);

  useEffect(() => {
    if (!ready || isPublicPath || !user) return;

    const isPlatformPath = PLATFORM_PATHS.some((path) =>
      pathMatches(pathname, path)
    );

    if (isPlatformPath && !isPlatformAdmin) {
      router.replace("/");
      return;
    }

    if (pathname === "/" && isPlatformAdmin) {
      router.replace("/system-center");
      return;
    }

    if (
      pathname === "/" &&
      !isPlatformAdmin &&
      companyLandingPath !== "/"
    ) {
      router.replace(companyLandingPath);
    }
  }, [
    companyLandingPath,
    isPlatformAdmin,
    isPublicPath,
    pathname,
    ready,
    router,
    user,
  ]);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = mobileMenuOpen ? "hidden" : "";

    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileMenuOpen]);

  const storageGroupKey = isPlatformAdmin
    ? "sulb-open-platform-group"
    : "sulb-open-company-group";

  useEffect(() => {
    if (!navigationGroups.length) return;

    const activeGroup = navigationGroups.find((group) =>
      group.items.some((item) => pathMatches(pathname, item.href))
    );
    const savedGroup = localStorage.getItem(storageGroupKey);
    const initialGroup = activeGroup?.id || savedGroup || navigationGroups[0].id;

    setOpenGroups((current) => {
      if (current.size > 0 && current.has(initialGroup)) return current;
      return new Set([initialGroup]);
    });
  }, [navigationGroups, pathname, storageGroupKey]);

  const currentPageTitle = useMemo(() => {
    for (const group of navigationGroups) {
      const activeItem = group.items.find((item) =>
        pathMatches(pathname, item.href)
      );
      if (activeItem) return activeItem.label;
    }

    return isPlatformAdmin ? "إدارة منصة صلب" : "بوابة الشركة";
  }, [isPlatformAdmin, navigationGroups, pathname]);

  function toggleGroup(groupId: string) {
    setOpenGroups((current) => {
      const next = new Set(current);

      if (next.has(groupId)) {
        next.delete(groupId);
      } else {
        next.add(groupId);
        localStorage.setItem(storageGroupKey, groupId);
      }

      return next;
    });
  }

  function requestLogout() {
    setDialog({
      open: true,
      type: "confirm",
      title: "تسجيل الخروج",
      message: "سيتم إنهاء جلسة الدخول الحالية. هل تريد المتابعة؟",
      action: "logout",
      confirmText: "تسجيل الخروج",
      showCancel: true,
    });
  }

  function requestExitSupport() {
    setDialog({
      open: true,
      type: "confirm",
      title: "العودة إلى لوحة المنصة",
      message: `سيتم إنهاء جلسة الدعم داخل ${
        user?.company_name || "الشركة"
      } واستعادة جلسة مدير المنصة الأصلية.`,
      action: "exit-support",
      confirmText: "العودة إلى المنصة",
      showCancel: true,
    });
  }

  async function confirmDialogAction() {
    if (dialog.action === "none") {
      setDialog(emptyDialog);
      return;
    }

    setDialogLoading(true);

    try {
      if (dialog.action === "logout") {
        try {
          await api.post("/logout");
        } finally {
          clearAllSessions();
          window.location.replace("/login");
        }
        return;
      }

      if (dialog.action === "exit-support") {
        if (!hasPlatformSessionBackup()) {
          throw new Error(
            "لم يتم العثور على نسخة جلسة مدير المنصة. سجّل الدخول إلى المنصة من جديد."
          );
        }

        await api.post("/support/exit");
        const restored = restorePlatformSession();

        if (!restored) {
          throw new Error("تعذر استعادة جلسة مدير المنصة الأصلية.");
        }

        window.location.replace("/system-center/companies");
      }
    } catch (error: any) {
      setDialog({
        open: true,
        type: "error",
        title: "تعذر تنفيذ العملية",
        message:
          error?.response?.data?.message ||
          error?.message ||
          "حدث خطأ غير متوقع.",
        action: "none",
        confirmText: "حسنًا",
        showCancel: false,
      });
    } finally {
      setDialogLoading(false);
    }
  }

  if (isPublicPath) {
    return <>{children}</>;
  }

  if (!ready || !user) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-slate-100 px-4 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-[#0B2A4A] text-2xl font-black text-white shadow-xl">
          ص
        </div>
        <div className="font-black text-[#0B2A4A]">
          جاري التحقق من جلسة صلب ERP...
        </div>
      </div>
    );
  }

  const portalLabel = isPlatformAdmin
    ? "بوابة إدارة المنصة"
    : isSupportMode
    ? "بوابة الشركة · دعم فني"
    : "بوابة الشركة";

  const sidebarProps = {
    groups: navigationGroups,
    pathname,
    user,
    portalLabel,
    openGroups,
    onToggleGroup: toggleGroup,
    onNavigate: () => setMobileMenuOpen(false),
    onLogout: requestLogout,
    isSupportMode,
    onExitSupport: requestExitSupport,
  };

  return (
    <>
      <div className="min-h-screen bg-slate-100 text-slate-900 lg:pr-[304px]">
          <aside className="fixed inset-y-0 right-0 z-40 hidden w-[304px] lg:block">
            <AppSidebar {...sidebarProps} />
          </aside>

          {mobileMenuOpen ? (
            <div className="fixed inset-0 z-[120] lg:hidden">
              <button
                type="button"
                aria-label="إغلاق القائمة"
                onClick={() => setMobileMenuOpen(false)}
                className="absolute inset-0 bg-slate-950/65 backdrop-blur-sm"
              />
              <aside className="absolute inset-y-0 right-0 w-[88%] max-w-[340px] shadow-2xl">
                <AppSidebar
                  {...sidebarProps}
                  isMobile
                  onClose={() => setMobileMenuOpen(false)}
                />
              </aside>
            </div>
          ) : null}

          <div className="min-w-0">
            <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/95 px-4 py-3 shadow-sm backdrop-blur sm:px-6 lg:px-8">
              <div className="mx-auto flex max-w-[1600px] items-center justify-between gap-3">
                <div className="flex min-w-0 items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setMobileMenuOpen(true)}
                    className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[#0B2A4A] text-xl font-black text-white shadow lg:hidden"
                    aria-label="فتح القائمة"
                  >
                    ☰
                  </button>

                  <div className="min-w-0">
                    <p className="truncate text-[11px] font-bold text-slate-500">
                      {portalLabel}
                    </p>
                    <h2 className="truncate text-lg font-black text-[#0B2A4A] sm:text-xl">
                      {currentPageTitle}
                    </h2>
                  </div>
                </div>

                <div className="hidden min-w-0 items-center gap-3 sm:flex">
                  <div className="min-w-0 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-2 text-left">
                    <div className="max-w-56 truncate text-xs font-black text-[#0B2A4A]">
                      {user.company_name || "إدارة منصة صلب"}
                    </div>
                    <div className="max-w-56 truncate text-[11px] text-slate-500">
                      {user.branch_name || "مركز التحكم"}
                    </div>
                  </div>
                  <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#0B2A4A] font-black text-white">
                    {(user.name || "م").trim().charAt(0)}
                  </div>
                </div>
              </div>
            </header>

            {isSupportMode ? (
              <div className="border-b border-amber-200 bg-amber-50 px-4 py-3 sm:px-6 lg:px-8">
                <div className="mx-auto flex max-w-[1600px] flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <div className="text-sm font-black text-amber-900">
                      أنت الآن داخل {user.company_name} بوضع الدعم الفني
                    </div>
                    <div className="mt-1 text-xs text-amber-700">
                      جميع العمليات مسجلة باسم مدير المنصة، والجلسة محصورة داخل هذه الشركة.
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={requestExitSupport}
                    className="rounded-2xl bg-amber-600 px-5 py-3 text-sm font-black text-white transition hover:bg-amber-700"
                  >
                    العودة إلى لوحة المنصة
                  </button>
                </div>
              </div>
            ) : null}

            <main className="mx-auto min-w-0 max-w-[1600px] p-4 sm:p-6 lg:p-8">
              {children}
            </main>
          </div>
        </div>

      <SystemDialog
        open={dialog.open}
        type={dialog.type}
        title={dialog.title}
        message={dialog.message}
        confirmText={dialog.confirmText}
        showCancel={dialog.showCancel}
        loading={dialogLoading}
        onConfirm={confirmDialogAction}
        onClose={() => {
          if (!dialogLoading) setDialog(emptyDialog);
        }}
      />
    </>
  );
}
