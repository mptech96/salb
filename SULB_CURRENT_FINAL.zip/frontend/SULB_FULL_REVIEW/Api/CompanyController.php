<?php

namespace App\Http\Controllers\Api;

use App\Domain\Accounting\Services\AccountingBootstrapService;
use App\Http\Controllers\Controller;
use App\Traits\LogsActivity;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Throwable;

class CompanyController extends Controller
{
    use LogsActivity;

    public function index()
    {
        $data = DB::table('companies as c')
            ->leftJoin('subscriptions as s', 's.company_id', '=', 'c.id')
            ->leftJoin('plans as p', 'p.id', '=', 's.plan_id')
            ->select(
                'c.*',
                'p.plan_name',
                's.start_date',
                's.end_date',
                's.status'
            )
            ->orderByDesc('c.id')
            ->get();

        return response()->json([
            'status' => true,
            'data' => $data,
        ]);
    }

    public function store(
        Request $request,
        AccountingBootstrapService $bootstrap
    ) {
        $request->validate([
            'company_name' => ['required', 'string', 'max:255'],
            'owner_name' => ['required', 'string', 'max:255'],
            'phone' => ['required', 'string', 'max:50'],
            'email' => ['nullable', 'email', 'max:255'],
            'city' => ['nullable', 'string', 'max:100'],
            'address' => ['nullable', 'string', 'max:1000'],
            'plan_id' => ['required', 'integer', 'exists:plans,id'],
            'start_date' => ['required', 'date'],
            'end_date' => ['required', 'date', 'after_or_equal:start_date'],
        ]);

        DB::beginTransaction();

        try {
            $companyId = DB::table('companies')->insertGetId([
                'company_name' => trim((string) $request->company_name),
                'owner_name' => trim((string) $request->owner_name),
                'phone' => trim((string) $request->phone),
                'email' => $request->email,
                'city' => $request->city,
                'address' => $request->address,
                'is_active' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            DB::table('subscriptions')->insert([
                'company_id' => $companyId,
                'plan_id' => $request->integer('plan_id'),
                'start_date' => $request->start_date,
                'end_date' => $request->end_date,
                'status' => 'ACTIVE',
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $branchId = DB::table('branches')->insertGetId([
                'company_id' => $companyId,
                'branch_name' => 'الفرع الرئيسي',
                'branch_code' => 'MAIN-' . $companyId,
                'phone' => $request->phone,
                'city' => $request->city,
                'address' => $request->address,
                'is_active' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $accounting = $bootstrap->bootstrapCompany(
                $companyId,
                $branchId,
                $request->start_date,
                $request->end_date
            );

            DB::commit();

            $this->logCreate(
                'Companies',
                $companyId,
                'تم إنشاء شركة جديدة مع التأسيس المحاسبي: ' .
                $request->company_name
            );

            return response()->json([
                'status' => true,
                'message' => 'تم إنشاء الشركة والفرع الرئيسي والسنة المالية وشجرة الحسابات ومراكز التكلفة بنجاح.',
                'data' => [
                    'company_id' => $companyId,
                    'main_branch_id' => $branchId,
                    'financial_year_id' => $accounting['financial_year_id'],
                    'company_cost_center_id' => $accounting['company_cost_center_id'],
                    'branch_cost_center_id' => $accounting['branch_cost_center_id'],
                ],
            ], 201);
        } catch (Throwable $e) {
            DB::rollBack();
            report($e);

            return response()->json([
                'status' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function supportAccess($id)
    {
        $company = DB::table('companies')->where('id', $id)->first();

        if (!$company) {
            return response()->json([
                'status' => false,
                'message' => 'الشركة غير موجودة',
            ], 404);
        }

        $branch = DB::table('branches')
            ->where('company_id', $id)
            ->orderBy('id')
            ->first();

        $subscription = DB::table('subscriptions as s')
            ->leftJoin('plans as p', 'p.id', '=', 's.plan_id')
            ->where('s.company_id', $id)
            ->orderByDesc('s.id')
            ->select(
                's.*',
                'p.plan_name',
                'p.plan_code',
                'p.max_branches',
                'p.max_users'
            )
            ->first();

        $permissions = DB::table('permissions')
            ->pluck('permission_code')
            ->values();

        $this->logSupportAccess(
            $company->id,
            'تم الدخول على الشركة كدعم فني: ' . $company->company_name
        );

        return response()->json([
            'status' => true,
            'message' => 'تم الدخول كدعم فني',
            'user' => [
                'id' => 0,
                'company_id' => $company->id,
                'branch_id' => $branch->id ?? null,
                'name' => 'دعم النظام',
                'username' => 'support',
                'company_name' => $company->company_name,
                'branch_name' => $branch->branch_name ?? 'الفرع الرئيسي',
                'role' => [
                    'role_name' => 'دعم فني',
                    'role_code' => 'SUPER_ADMIN',
                ],
                'permissions' => $permissions,
                'is_support_mode' => true,
            ],
            'subscription' => $subscription,
        ]);
    }
}
