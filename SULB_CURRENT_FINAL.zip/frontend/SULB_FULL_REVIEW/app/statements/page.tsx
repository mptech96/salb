"use client";

import { useEffect, useState } from "react";
import api from "../api";
export default function StatementsPage() {

  const [type, setType] = useState("SUPPLIER");

  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [drivers, setDrivers] = useState<any[]>([]);

  const [selectedId, setSelectedId] = useState("");

  const [rows, setRows] = useState<any[]>([]);

  const [summary, setSummary] = useState({
    total_debit: 0,
    total_credit: 0,
    balance: 0,
    name: "",
  });

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {

    const [
      suppliersRes,
      customersRes,
      driversRes
    ] = await Promise.all([
      api.get("/suppliers"),
      api.get("/customers"),
      api.get("/drivers"),
    ]);

    setSuppliers(suppliersRes.data.data || []);
    setCustomers(customersRes.data.data || []);
    setDrivers(driversRes.data.data || []);
  }

  async function loadStatement() {

    if (!selectedId) return;

    let url = "";

    if (type === "SUPPLIER") {
      url = `/statements/supplier/${selectedId}`;
    }

    if (type === "CUSTOMER") {
      url = `/statements/customer/${selectedId}`;
    }

    if (type === "DRIVER") {
      url = `/statements/driver/${selectedId}`;
    }

    const res = await api.get(url);

    setRows(res.data.data.rows || []);

    setSummary({
      total_debit: res.data.data.total_debit || 0,
      total_credit: res.data.data.total_credit || 0,
      balance: res.data.data.balance || 0,
      name: res.data.data.name || "",
    });
  }

  const currentList =
    type === "SUPPLIER"
      ? suppliers
      : type === "CUSTOMER"
      ? customers
      : drivers;

  return (
    <div className="p-6">

      <div className="bg-[#0B2E59] rounded-3xl p-8 text-white mb-6">

        <div className="text-sm opacity-70 mb-2">
          الحسابات والتقارير
        </div>

        <div className="text-5xl font-black mb-3">
          كشف الحساب
        </div>

        <div className="opacity-80">
          الموردين والعملاء والسائقين
        </div>

      </div>

      <div className="bg-white rounded-3xl p-6 border">

        <div className="grid grid-cols-3 gap-4 mb-6">

          <select
            className="border rounded-2xl p-4"
            value={type}
            onChange={(e) => {
              setType(e.target.value);
              setSelectedId("");
              setRows([]);
            }}
          >
            <option value="SUPPLIER">مورد</option>
            <option value="CUSTOMER">عميل</option>
            <option value="DRIVER">سائق</option>
          </select>

          <select
            className="border rounded-2xl p-4"
            value={selectedId}
            onChange={(e) => setSelectedId(e.target.value)}
          >
            <option value="">اختر</option>

            {currentList.map((item: any) => (

              <option key={item.id} value={item.id}>

                {item.supplier_name ||
                  item.customer_name ||
                  item.driver_name}

              </option>

            ))}

          </select>

          <button
            onClick={loadStatement}
            className="bg-[#0B2E59] text-white rounded-2xl"
          >
            عرض الكشف
          </button>

        </div>

        <div className="grid grid-cols-4 gap-4 mb-6">

          <div className="bg-gray-100 rounded-2xl p-4">
            <div className="text-sm text-gray-500">الاسم</div>
            <div className="text-2xl font-bold">
              {summary.name}
            </div>
          </div>

          <div className="bg-red-50 rounded-2xl p-4">
            <div className="text-sm text-gray-500">مدين</div>
            <div className="text-2xl font-bold text-red-600">
              {Number(summary.total_debit).toFixed(3)}
            </div>
          </div>

          <div className="bg-green-50 rounded-2xl p-4">
            <div className="text-sm text-gray-500">دائن</div>
            <div className="text-2xl font-bold text-green-600">
              {Number(summary.total_credit).toFixed(3)}
            </div>
          </div>

          <div className="bg-blue-50 rounded-2xl p-4">
            <div className="text-sm text-gray-500">الرصيد</div>
            <div className="text-2xl font-black text-[#0B2E59]">
              {Number(summary.balance).toFixed(3)}
            </div>
          </div>

        </div>

        <div className="overflow-auto">

          <table className="w-full">

            <thead className="bg-gray-100">

              <tr>

                <th className="p-4 text-right">التاريخ</th>
                <th className="p-4 text-right">الرقم</th>
                <th className="p-4 text-right">النوع</th>
                <th className="p-4 text-right">مدين</th>
                <th className="p-4 text-right">دائن</th>

              </tr>

            </thead>

            <tbody>

              {rows.map((row: any, index) => (

                <tr key={index} className="border-b">

                  <td className="p-4">{row.trx_date}</td>
                  <td className="p-4">{row.trx_number}</td>
                  <td className="p-4">{row.trx_type}</td>

                  <td className="p-4 text-red-600 font-bold">
                    {Number(row.debit).toFixed(3)}
                  </td>

                  <td className="p-4 text-green-600 font-bold">
                    {Number(row.credit).toFixed(3)}
                  </td>

                </tr>

              ))}

            </tbody>

          </table>

        </div>

      </div>

    </div>
  );
}