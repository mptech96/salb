"use client";

import { useEffect, useState } from "react";
import api from "../api";

export default function DriversPage() {

  const [drivers, setDrivers] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const [showForm, setShowForm] = useState(false);

  const [editId, setEditId] = useState<number | null>(null);

  const [form, setForm] = useState({
    driver_name: "",
    phone: "",
    notes: "",
    is_active: 1,
  });

  const loadDrivers = async () => {

    setLoading(true);

    try {

      const res = await api.get("/drivers");

      setDrivers(res.data.data || []);

    } finally {

      setLoading(false);
    }
  };

  useEffect(() => {
    loadDrivers();
  }, []);

  const resetForm = () => {

    setEditId(null);

    setForm({
      driver_name: "",
      phone: "",
      notes: "",
      is_active: 1,
    });
  };

  const saveDriver = async () => {

    if (!form.driver_name) {
      return alert("أدخل اسم السائق");
    }

    try {

      if (editId) {

        await api.put(`/drivers/${editId}`, form);

        alert("تم تعديل السائق");

      } else {

        await api.post("/drivers", form);

        alert("تم حفظ السائق");
      }

      setShowForm(false);

      resetForm();

      loadDrivers();

    } catch (error: any) {

      alert(
        error?.response?.data?.message ||
        "حدث خطأ"
      );
    }
  };

  const editDriver = (driver: any) => {

    setEditId(driver.id);

    setForm({
      driver_name: driver.driver_name || "",
      phone: driver.phone || "",
      notes: driver.notes || "",
      is_active: driver.is_active ?? 1,
    });

    setShowForm(true);
  };

  const deleteDriver = async (id: number) => {

    if (!confirm("حذف السائق ؟")) {
      return;
    }

    await api.delete(`/drivers/${id}`);

    loadDrivers();
  };

  return (
    <section dir="rtl" className="space-y-5">

      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-6 text-white shadow-lg">

        <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">

          <div>

            <p className="text-sm text-blue-100">
              إدارة السائقين
            </p>

            <h1 className="mt-2 text-3xl font-bold">
              السائقين
            </h1>

            <p className="mt-2 text-sm text-blue-100">
              إدارة السائقين والمشاوير والمصاريف.
            </p>

          </div>

          <button
            onClick={() => {
              resetForm();
              setShowForm(true);
            }}
            className="rounded-2xl bg-white px-5 py-3 font-bold text-[#0B2A4A]"
          >
            + إضافة سائق
          </button>

        </div>

      </div>

      <div className="rounded-3xl border border-slate-200 bg-white shadow-sm overflow-hidden">

        <div className="overflow-x-auto">

          <table className="min-w-[900px] w-full text-right">

            <thead className="bg-slate-100 text-slate-700">

              <tr>
                <th className="p-4">الاسم</th>
                <th className="p-4">الجوال</th>
                <th className="p-4">الحالة</th>
                <th className="p-4">ملاحظات</th>
                <th className="p-4">العمليات</th>
              </tr>

            </thead>

            <tbody>

              {loading ? (

                <tr>
                  <td
                    colSpan={5}
                    className="p-6 text-center"
                  >
                    جاري التحميل...
                  </td>
                </tr>

              ) : drivers.length === 0 ? (

                <tr>
                  <td
                    colSpan={5}
                    className="p-6 text-center text-slate-500"
                  >
                    لا يوجد سائقين
                  </td>
                </tr>

              ) : (

                drivers.map((driver) => (

                  <tr
                    key={driver.id}
                    className="border-t border-slate-100"
                  >

                    <td className="p-4 font-bold">
                      {driver.driver_name}
                    </td>

                    <td className="p-4">
                      {driver.phone || "-"}
                    </td>

                    <td className="p-4">

                      {driver.is_active ? (

                        <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">
                          نشط
                        </span>

                      ) : (

                        <span className="rounded-full bg-rose-100 px-3 py-1 text-xs font-bold text-rose-700">
                          متوقف
                        </span>

                      )}

                    </td>

                    <td className="p-4">
                      {driver.notes || "-"}
                    </td>

                    <td className="p-4">

                      <div className="flex gap-2">

                        <button
                          onClick={() => editDriver(driver)}
                          className="rounded-xl bg-blue-100 px-3 py-2 text-sm font-bold text-blue-700"
                        >
                          تعديل
                        </button>

                        <button
                          onClick={() => deleteDriver(driver.id)}
                          className="rounded-xl bg-rose-100 px-3 py-2 text-sm font-bold text-rose-700"
                        >
                          حذف
                        </button>

                      </div>

                    </td>

                  </tr>

                ))

              )}

            </tbody>

          </table>

        </div>

      </div>

      {showForm && (

        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm">

          <div className="absolute left-0 top-0 h-full w-full overflow-y-auto bg-white p-5 shadow-2xl sm:w-[520px]">

            <div className="mb-6 flex items-center justify-between">

              <div>

                <h2 className="text-2xl font-bold text-[#0B2A4A]">

                  {editId
                    ? "تعديل سائق"
                    : "إضافة سائق"}

                </h2>

              </div>

              <button
                onClick={() => setShowForm(false)}
                className="rounded-xl bg-slate-200 px-4 py-2 font-bold"
              >
                ✕
              </button>

            </div>

            <div className="grid grid-cols-1 gap-3">

              <input
                type="text"
                placeholder="اسم السائق"
                className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                value={form.driver_name}
                onChange={(e) =>
                  setForm({
                    ...form,
                    driver_name: e.target.value,
                  })
                }
              />

              <input
                type="text"
                placeholder="رقم الجوال"
                className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                value={form.phone}
                onChange={(e) =>
                  setForm({
                    ...form,
                    phone: e.target.value,
                  })
                }
              />

              <textarea
                placeholder="ملاحظات"
                className="min-h-28 rounded-2xl border border-slate-200 bg-slate-50 p-4"
                value={form.notes}
                onChange={(e) =>
                  setForm({
                    ...form,
                    notes: e.target.value,
                  })
                }
              />

              <select
                className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                value={form.is_active}
                onChange={(e) =>
                  setForm({
                    ...form,
                    is_active: Number(e.target.value),
                  })
                }
              >

                <option value={1}>
                  نشط
                </option>

                <option value={0}>
                  متوقف
                </option>

              </select>

              <button
                onClick={saveDriver}
                className="rounded-2xl bg-[#0B2A4A] px-5 py-4 font-bold text-white"
              >

                {editId
                  ? "حفظ التعديلات"
                  : "حفظ السائق"}

              </button>

            </div>

          </div>

        </div>

      )}

    </section>
  );
}