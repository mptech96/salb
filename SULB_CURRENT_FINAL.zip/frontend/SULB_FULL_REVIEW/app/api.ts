import axios from "axios";

const api = axios.create({
  baseURL:
    process.env.NEXT_PUBLIC_API_URL ||
    "http://127.0.0.1:8000/api",

  headers: {
    Accept: "application/json",
    "Content-Type": "application/json",
  },
});

api.interceptors.request.use(
  (config) => {
    if (typeof window === "undefined") {
      return config;
    }

    let savedUser: any = null;

    try {
      const rawUser = localStorage.getItem("scrap_user");

      if (rawUser) {
        savedUser = JSON.parse(rawUser);
      }
    } catch {
      savedUser = null;
    }

    const companyId =
      savedUser?.company_id ||
      savedUser?.company?.id ||
      localStorage.getItem("company_id") ||
      localStorage.getItem("companyId") ||
      localStorage.getItem("current_company_id");

    const branchId =
      savedUser?.branch_id ||
      savedUser?.branch?.id ||
      localStorage.getItem("branch_id") ||
      localStorage.getItem("branchId") ||
      localStorage.getItem("current_branch_id");

    const userId =
      savedUser?.id ||
      savedUser?.user_id ||
      localStorage.getItem("user_id") ||
      localStorage.getItem("userId");

    const token =
      savedUser?.token ||
      localStorage.getItem("token") ||
      localStorage.getItem("auth_token");

    if (companyId) {
      config.headers["X-Company-ID"] = String(companyId);
    }

    if (branchId) {
      config.headers["X-Branch-ID"] = String(branchId);
    }

    if (userId) {
      config.headers["X-User-ID"] = String(userId);
    }

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => response,
  (error) => {
    return Promise.reject(error);
  }
);

export default api;