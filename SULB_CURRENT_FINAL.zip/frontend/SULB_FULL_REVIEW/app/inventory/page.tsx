"use client";

import { useEffect, useMemo, useState } from "react";
import api from "../api";

export default function InventoryPage() {
  const [inventory, setInventory] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);
  const [cars, setCars] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);

  const [form, setForm] = useState({
    item_id: "",
    car_id: "",
    movement_type: "IN",
    qty: "",
    unit_cost: "",
    movement_date: "",
    notes: "",
  });

  const loadAll = async () => {
    setLoading(true);
    try {
      const [invRes, itemsRes, carsRes] = await Promise.all([
        api.get("/inventory"),
        api.get("/items"),
        api.get("/cars"),
      ]);

      setInventory(invRes.data.data || []);
      setItems(itemsRes.data.data || []);
      setCars(carsRes.data.data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const filtered = useMemo(() => {
    return inventory.filter((row) => {
      const text = `${row.item_name || ""} ${row.car_number || ""}`.toLowerCase();
      return text.includes(search.toLowerCase());
    });
  }, [inventory, search]);

  const totalStockValue = useMemo(() => {
    return filtered.reduce((sum, row) => sum + Number(row.stock_value || 0), 0);
  }, [filtered]);

  const resetForm = () => {
    setForm({
      item_id: "",
      car_id: "",
      movement_type: "IN",
      qty: "",
      unit_cost: "",
      movement_date: "",
      notes: "",
    });
  };

  const saveAdjustment = async () => {
    if (!form.item_id) return alert("اختر الصنف");
    if (!form.qty || Number(form.qty) <= 0) return alert("أدخل الكمية");

    setSaving(true);

    try {
      await api.post("/inventory/adjustment", {
        ...form,
        car_id: form.car_id || null,
        qty: Number(form.qty),
        unit_cost: Number(form.unit_cost || 0),
        movement_date: form.movement_date || null,
      });

      alert("تمت تسوية المخزون بنجاح");
      setShowForm(false);
      resetForm();
      loadAll();
    } catch (error: any) {
      alert(error?.response?.data?.message || "حدث خطأ أثناء الحفظ");
    } finally {
      setSaving(false);
    }
  };

  return (
    <section dir="rtl" className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-5 text-white shadow-lg sm:p-7">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-sm text-blue-100">إدارة المخزون</p>
            <h1 className="mt-2 text-2xl font-bold sm:text-4xl">
              المخزون الحالي
            </h1>
            <p className="mt-2 text-sm text-blue-100">
              متابعة الكميات الحالية حسب السيارة والصنف.
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-2xl bg-white/10 p-4">
                <div className="text-sm text-blue-100">الأصناف</div>
                <div className="mt-1 text-3xl font-bold">{filtered.length}</div>
              </div>

              <div className="rounded-2xl bg-white/10 p-4">
                <div className="text-sm text-blue-100">قيمة المخزون</div>
                <div className="mt-1 text-2xl font-bold">
                  {totalStockValue.toFixed(3)}
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowForm(true)}
              className="rounded-2xl bg-white px-5 py-3 font-bold text-[#0B2A4A] shadow"
            >
              + تسوية مخزون
            </button>
          </div>
        </div>
      </div>

      <div className="rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="flex flex-col gap-3 border-b border-slate-200 p-4 lg:flex-row lg:items-center lg:justify-between">
          <h2 className="text-xl font-bold text-slate-900">المخزون الفعلي</h2>

          <input
            className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-[#0B2A4A] lg:w-[320px]"
            placeholder="بحث بالصنف أو السيارة..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-[1200px] w-full text-right">
            <thead className="bg-slate-100 text-slate-600">
              <tr>
                <th className="p-4">الصنف</th>
                <th className="p-4">السيارة</th>
                <th className="p-4">الداخل</th>
                <th className="p-4">الخارج</th>
                <th className="p-4">المتبقي</th>
                <th className="p-4">متوسط التكلفة</th>
                <th className="p-4">قيمة المخزون</th>
                <th className="p-4">الحالة</th>
              </tr>
            </thead>

            <tbody>
              {loading ? (
                <tr>
                  <td className="p-6 text-center text-slate-500" colSpan={8}>
                    جاري التحميل...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td className="p-6 text-center text-slate-500" colSpan={8}>
                    لا توجد بيانات
                  </td>
                </tr>
              ) : (
                filtered.map((row, index) => (
                  <tr key={index} className="border-t border-slate-100">
                    <td className="p-4 font-bold text-[#0B2A4A]">
                      {row.item_name}
                    </td>
                    <td className="p-4">{row.car_number || "الحوش / عام"}</td>
                    <td className="p-4 font-bold text-emerald-700">
                      {Number(row.total_in || 0).toFixed(3)}
                    </td>
                    <td className="p-4 font-bold text-rose-700">
                      {Number(row.total_out || 0).toFixed(3)}
                    </td>
                    <td className="p-4 font-bold">
                      {Number(row.balance_qty || 0).toFixed(3)}
                    </td>
                    <td className="p-4">
                      {Number(row.avg_cost || 0).toFixed(3)}
                    </td>
                    <td className="p-4 font-bold text-[#0B2A4A]">
                      {Number(row.stock_value || 0).toFixed(3)}
                    </td>
                    <td className="p-4">
                      {Number(row.balance_qty || 0) <= 1 ? (
                        <span className="rounded-full bg-rose-100 px-3 py-1 text-xs font-bold text-rose-700">
                          منخفض
                        </span>
                      ) : (
                        <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">
                          جيد
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm">
          <div className="absolute left-0 top-0 h-full w-full overflow-y-auto bg-white p-5 shadow-2xl sm:w-[540px]">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-[#0B2A4A]">
                  تسوية مخزون
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  إدخال أو إخراج يدوي للمخزون.
                </p>
              </div>

              <button
                onClick={() => setShowForm(false)}
                className="rounded-xl bg-slate-200 px-4 py-2 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 gap-3">
              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">الصنف *</span>
                <select
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={form.item_id}
                  onChange={(e) => setForm({ ...form, item_id: e.target.value })}
                >
                  <option value="">اختر الصنف</option>
                  {items.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.item_name}
                    </option>
                  ))}
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">
                  السيارة / الحوش
                </span>
                <select
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={form.car_id}
                  onChange={(e) => setForm({ ...form, car_id: e.target.value })}
                >
                  <option value="">الحوش / مخزون عام</option>
                  {cars.map((car) => (
                    <option key={car.id} value={car.id}>
                      سيارة: {car.car_number || car.plate_number}
                    </option>
                  ))}
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">نوع الحركة</span>
                <select
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={form.movement_type}
                  onChange={(e) =>
                    setForm({ ...form, movement_type: e.target.value })
                  }
                >
                  <option value="IN">إدخال مخزون</option>
                  <option value="OUT">إخراج / نقص مخزون</option>
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">
                  الكمية بالطن *
                </span>
                <input
                  type="number"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  placeholder="مثال: 1.500"
                  value={form.qty}
                  onChange={(e) => setForm({ ...form, qty: e.target.value })}
                />
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">
                  تكلفة الطن
                </span>
                <input
                  type="number"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  placeholder="اختياري"
                  value={form.unit_cost}
                  onChange={(e) =>
                    setForm({ ...form, unit_cost: e.target.value })
                  }
                />
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">
                  تاريخ الحركة
                </span>
                <input
                  type="date"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={form.movement_date}
                  onChange={(e) =>
                    setForm({ ...form, movement_date: e.target.value })
                  }
                />
              </label>

              <textarea
                className="min-h-28 rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                placeholder="سبب التسوية / ملاحظات"
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />

              <button
                onClick={saveAdjustment}
                disabled={saving}
                className="mt-3 rounded-2xl bg-[#0B2A4A] px-5 py-4 font-bold text-white disabled:opacity-60"
              >
                {saving ? "جاري الحفظ..." : "حفظ التسوية"}
              </button>

              <button
                onClick={() => setShowForm(false)}
                className="rounded-2xl bg-slate-200 px-5 py-4 font-bold text-slate-700"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}