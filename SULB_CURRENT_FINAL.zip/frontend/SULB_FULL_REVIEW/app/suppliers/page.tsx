"use client";

import { useEffect, useMemo, useState } from "react";
import api from "../api";

type Row = {
  id: number;
  company_id: number;
  branch_id: number;
  company_name?: string | null;
  branch_name?: string | null;
  supplier_code: string | null;
  supplier_name: string;
  phone: string | null;
  city: string | null;
  address: string | null;
  opening_balance: string | number;
  notes: string | null;
  is_active: number;
};

type Branch = {
  id: number;
  company_id: number;
  branch_name: string;
};

const emptyForm = {
  branch_id: "",
  supplier_code: "",
  supplier_name: "",
  phone: "",
  city: "",
  address: "",
  opening_balance: "",
  notes: "",
  is_active: 1,
};

function currentUser() {
  if (typeof window === "undefined") return null;

  try {
    return JSON.parse(localStorage.getItem("scrap_user") || "null");
  } catch {
    return null;
  }
}

function requestConfig() {
  const user = currentUser();
  const roleCode = user?.role?.role_code || user?.role_code || "";
  const headers: Record<string, string> = {};

  if (user?.company_id !== null && user?.company_id !== undefined) {
    headers["X-Company-ID"] = String(user.company_id);
  }

  if (user?.branch_id !== null && user?.branch_id !== undefined) {
    headers["X-Branch-ID"] = String(user.branch_id);
  }

  if (user?.id !== null && user?.id !== undefined) {
    headers["X-User-ID"] = String(user.id);
  }

  if (roleCode) headers["X-Role-Code"] = String(roleCode);

  return { headers };
}

export default function Page() {
  const [rows, setRows] = useState<Row[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [branchFilter, setBranchFilter] = useState("ALL");
  const [form, setForm] = useState(emptyForm);

  const user = useMemo(() => currentUser(), []);
  const roleCode = user?.role?.role_code || user?.role_code || "";
  const canManage = ["SUPER_ADMIN", "MANAGER", "ACCOUNTANT"].includes(roleCode);
  const canViewAllCompanyBranches = ["SUPER_ADMIN", "MANAGER"].includes(roleCode);

  const visibleBranches = useMemo(
    () => branches.filter((branch) => Number(branch.company_id) === Number(user?.company_id)),
    [branches, user?.company_id]
  );

  const filteredRows = useMemo(() => {
    if (branchFilter === "ALL") return rows;
    return rows.filter((row) => String(row.branch_id) === String(branchFilter));
  }, [rows, branchFilter]);

  const loadData = async () => {
    setLoading(true);

    try {
      const config = requestConfig();
      const requests = [api.get("/suppliers", config)];

      if (canViewAllCompanyBranches) {
        requests.push(api.get("/branches", config));
      }

      const responses = await Promise.all(requests);
      setRows(responses[0].data?.data || []);

      if (responses[1]) {
        setBranches(responses[1].data?.data || []);
      }
    } catch (error: any) {
      alert(error?.response?.data?.message || "تعذر تحميل البيانات.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setForm({
      ...emptyForm,
      branch_id: user?.branch_id ? String(user.branch_id) : "",
    });
  };

  const openCreate = () => {
    resetForm();
    setShowForm(true);
  };

  const openEdit = (row: Row) => {
    setEditingId(row.id);
    setForm({
      branch_id: String(row.branch_id || ""),
      supplier_code: row.supplier_code || "",
      supplier_name: row.supplier_name || "",
      phone: row.phone || "",
      city: row.city || "",
      address: row.address || "",
      opening_balance: String(row.opening_balance || ""),
      notes: row.notes || "",
      is_active: Number(row.is_active ?? 1),
    });
    setShowForm(true);
  };

  const save = async () => {
    if (!form.supplier_name.trim()) return alert("اسم مورد مطلوب.");
    if (canViewAllCompanyBranches && !form.branch_id) return alert("اختر الفرع.");

    setSaving(true);

    try {
      const payload = {
        ...form,
        branch_id: form.branch_id ? Number(form.branch_id) : undefined,
        opening_balance: Number(form.opening_balance || 0),
      };

      const config = requestConfig();

      if (editingId) {
        await api.put("/suppliers/" + editingId, payload, config);
      } else {
        await api.post("/suppliers", payload, config);
      }

      alert(editingId ? "تم التحديث بنجاح." : "تم الإنشاء بنجاح.");
      setShowForm(false);
      resetForm();
      await loadData();
    } catch (error: any) {
      const data = error?.response?.data;
      const firstError = data?.errors
        ? Object.values(data.errors).flat().find(Boolean)
        : null;

      alert(String(firstError || data?.message || "حدث خطأ أثناء الحفظ."));
    } finally {
      setSaving(false);
    }
  };

  const remove = async (row: Row) => {
    if (!confirm(`هل تريد حذف ${row.supplier_name}؟`)) return;

    try {
      await api.delete("/suppliers/" + row.id, requestConfig());
      alert("تم الحذف بنجاح.");
      await loadData();
    } catch (error: any) {
      alert(error?.response?.data?.message || "تعذر الحذف.");
    }
  };

  return (
    <section dir="rtl" className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-6 text-white shadow-lg">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm text-blue-100">إدارة الموردين</p>
            <h1 className="mt-2 text-3xl font-black">الموردين وحسابات الشراء</h1>
            <p className="mt-2 text-sm text-blue-100">
              البيانات معزولة حسب الشركة والفرع الحالي.
            </p>
          </div>

          {canManage && (
            <button
              type="button"
              onClick={openCreate}
              className="w-fit rounded-2xl bg-white px-5 py-3 font-black text-[#0B2A4A]"
            >
              + إضافة مورد
            </button>
          )}
        </div>

        <div className="mt-6 grid max-w-md grid-cols-2 gap-3">
          <Stat label="الإجمالي" value={rows.length} />
          <Stat
            label="النشطون"
            value={rows.filter((row) => Number(row.is_active) === 1).length}
          />
        </div>
      </div>

      {canViewAllCompanyBranches && (
        <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
          <select
            value={branchFilter}
            onChange={(event) => setBranchFilter(event.target.value)}
            className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4"
          >
            <option value="ALL">كل فروع الشركة</option>
            {visibleBranches.map((branch) => (
              <option key={branch.id} value={branch.id}>
                {branch.branch_name}
              </option>
            ))}
          </select>
        </div>
      )}

      <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b p-4">
          <h2 className="text-xl font-black text-[#0B2A4A]">قائمة الموردين</h2>
          <span className="text-sm text-slate-500">
            {loading ? "جاري التحميل..." : `${filteredRows.length} سجل`}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[1050px] text-right">
            <thead className="bg-slate-100 text-slate-700">
              <tr>
                <th className="p-4">الفرع</th>
                <th className="p-4">الكود</th>
                <th className="p-4">الاسم</th>
                <th className="p-4">الجوال</th>
                <th className="p-4">المدينة</th>
                <th className="p-4">الرصيد</th>
                <th className="p-4">الحالة</th>
                <th className="p-4">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={8} className="p-10 text-center">جاري التحميل...</td>
                </tr>
              ) : filteredRows.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-10 text-center text-slate-500">
                    لا توجد بيانات.
                  </td>
                </tr>
              ) : (
                filteredRows.map((row) => (
                  <tr key={row.id} className="border-t border-slate-100">
                    <td className="p-4">{row.branch_name || "-"}</td>
                    <td className="p-4">{row.supplier_code || "-"}</td>
                    <td className="p-4 font-black text-[#0B2A4A]">{row.supplier_name}</td>
                    <td className="p-4">{row.phone || "-"}</td>
                    <td className="p-4">{row.city || "-"}</td>
                    <td className="p-4">{Number(row.opening_balance || 0).toFixed(3)}</td>
                    <td className="p-4">
                      <span className={Number(row.is_active) === 1
                        ? "rounded-full bg-emerald-100 px-3 py-1 text-xs font-black text-emerald-700"
                        : "rounded-full bg-slate-200 px-3 py-1 text-xs font-black text-slate-600"
                      }>
                        {Number(row.is_active) === 1 ? "نشط" : "متوقف"}
                      </span>
                    </td>
                    <td className="p-4">
                      {canManage && (
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => openEdit(row)}
                            className="rounded-xl bg-blue-100 px-3 py-2 font-bold text-blue-700"
                          >
                            تعديل
                          </button>
                          <button
                            type="button"
                            onClick={() => remove(row)}
                            className="rounded-xl bg-rose-100 px-3 py-2 font-bold text-rose-700"
                          >
                            حذف
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 bg-slate-950/45 backdrop-blur-sm">
          <div className="absolute left-0 top-0 h-full w-full overflow-y-auto bg-white shadow-2xl sm:w-[560px]">
            <div className="sticky top-0 flex items-center justify-between border-b bg-white p-5">
              <h2 className="text-2xl font-black text-[#0B2A4A]">
                {editingId ? "تعديل مورد" : "إضافة مورد"}
              </h2>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="rounded-2xl bg-slate-100 px-4 py-3 font-black"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 gap-3 p-5">
              {canViewAllCompanyBranches && (
                <select
                  value={form.branch_id}
                  onChange={(event) => setForm({...form, branch_id: event.target.value})}
                  className="rounded-2xl border bg-slate-50 p-4"
                >
                  <option value="">اختر الفرع</option>
                  {visibleBranches.map((branch) => (
                    <option key={branch.id} value={branch.id}>
                      {branch.branch_name}
                    </option>
                  ))}
                </select>
              )}

              <input
                value={form.supplier_code}
                onChange={(event) => setForm({...form, supplier_code: event.target.value})}
                placeholder="الكود"
                className="rounded-2xl border bg-slate-50 p-4"
              />

              <input
                value={form.supplier_name}
                onChange={(event) => setForm({...form, supplier_name: event.target.value})}
                placeholder="اسم مورد *"
                className="rounded-2xl border bg-slate-50 p-4"
              />

              <input value={form.phone} onChange={(event) => setForm({...form, phone: event.target.value})} placeholder="الجوال" className="rounded-2xl border bg-slate-50 p-4" />
              <input value={form.city} onChange={(event) => setForm({...form, city: event.target.value})} placeholder="المدينة" className="rounded-2xl border bg-slate-50 p-4" />
              <input value={form.address} onChange={(event) => setForm({...form, address: event.target.value})} placeholder="العنوان" className="rounded-2xl border bg-slate-50 p-4" />
              <input type="number" value={form.opening_balance} onChange={(event) => setForm({...form, opening_balance: event.target.value})} placeholder="الرصيد الافتتاحي" className="rounded-2xl border bg-slate-50 p-4" />
              <select value={form.is_active} onChange={(event) => setForm({...form, is_active: Number(event.target.value)})} className="rounded-2xl border bg-slate-50 p-4">
                <option value={1}>نشط</option>
                <option value={0}>متوقف</option>
              </select>
              <textarea value={form.notes} onChange={(event) => setForm({...form, notes: event.target.value})} placeholder="ملاحظات" className="min-h-28 rounded-2xl border bg-slate-50 p-4" />

              <button
                type="button"
                onClick={save}
                disabled={saving}
                className="rounded-2xl bg-[#0B2A4A] p-4 font-black text-white disabled:opacity-60"
              >
                {saving ? "جاري الحفظ..." : "حفظ"}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl bg-white/10 p-4">
      <div className="text-sm text-blue-100">{label}</div>
      <div className="mt-2 text-3xl font-black">{value}</div>
    </div>
  );
}
