"use client";

import { useEffect, useMemo, useState } from "react";
import api from "../api";

type Purchase = {
  id: number;
  invoice_number: string | null;
  invoice_date: string | null;
  supplier_name: string | null;
  car_number: string | null;
  total_qty: string | number;
  total_amount: string | number;
  payment_status: string | null;
};

export default function PurchasesPage() {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [cars, setCars] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(false);

  const [invoice, setInvoice] = useState({
    branch_id: 1,
    supplier_id: "",
    car_id: "",
    invoice_number: "",
    invoice_date: "",
    discount_amount: 0,
    transport_cost: 0,
    extra_cost: 0,
    notes: "",
  });

  const [lines, setLines] = useState([
    { item_id: "", qty: 0, unit_price: 0, discount_amount: 0, line_total: 0, notes: "" },
  ]);

  const loadAll = async () => {
    setLoading(true);
    const [p, s, c, i] = await Promise.all([
      api.get("/purchase-invoices"),
      api.get("/suppliers"),
      api.get("/cars"),
      api.get("/items"),
    ]);
    setPurchases(p.data.data || []);
    setSuppliers(s.data.data || []);
    setCars(c.data.data || []);
    setItems(i.data.data || []);
    setLoading(false);
  };

  useEffect(() => {
    loadAll();
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setInvoice({
      branch_id: 1,
      supplier_id: "",
      car_id: "",
      invoice_number: "",
      invoice_date: "",
      discount_amount: 0,
      transport_cost: 0,
      extra_cost: 0,
      notes: "",
    });
    setLines([
      { item_id: "", qty: 0, unit_price: 0, discount_amount: 0, line_total: 0, notes: "" },
    ]);
  };

  const openAddForm = () => {
    resetForm();
    setShowForm(true);
  };

  const updateLine = (index: number, field: string, value: any) => {
    const updated = [...lines] as any[];
    updated[index] = { ...updated[index], [field]: value };

    const qty = Number(updated[index].qty || 0);
    const price = Number(updated[index].unit_price || 0);
    const discount = Number(updated[index].discount_amount || 0);
    updated[index].line_total = qty * price - discount;

    setLines(updated);
  };

  const addLine = () => {
    setLines([
      ...lines,
      { item_id: "", qty: 0, unit_price: 0, discount_amount: 0, line_total: 0, notes: "" },
    ]);
  };

  const removeLine = (index: number) => {
    if (lines.length === 1) return;
    setLines(lines.filter((_, i) => i !== index));
  };

  const totalQty = useMemo(
    () => lines.reduce((sum, l) => sum + Number(l.qty || 0), 0),
    [lines]
  );

  const subtotal = useMemo(
    () => lines.reduce((sum, l) => sum + Number(l.line_total || 0), 0),
    [lines]
  );

  const finalTotal = useMemo(() => {
    return (
      subtotal -
      Number(invoice.discount_amount || 0) +
      Number(invoice.transport_cost || 0) +
      Number(invoice.extra_cost || 0)
    );
  }, [subtotal, invoice]);

  const saveInvoice = async () => {
    if (!invoice.supplier_id) return alert("اختر المورد");
    if (!invoice.car_id) return alert("اختر السيارة");

    const cleanLines = lines.filter((l) => l.item_id && Number(l.qty) > 0);

    if (cleanLines.length === 0) return alert("أضف صنف واحد على الأقل");

    setSaving(true);

    try {
      const payload = {
        ...invoice,
        total_qty: totalQty,
        total_before_discount: subtotal,
        total_amount: finalTotal,
        items: cleanLines,
      };

      if (editingId) {
        await api.put(`/purchase-invoices/${editingId}`, payload);
        alert("تم تعديل الفاتورة");
      } else {
        await api.post("/purchase-invoices", payload);
        alert("تم حفظ الفاتورة");
      }

      setShowForm(false);
      resetForm();
      loadAll();
    } catch (error: any) {
      alert(error?.response?.data?.message || "حدث خطأ أثناء الحفظ");
    } finally {
      setSaving(false);
    }
  };

  const editPurchase = async (id: number) => {
    const res = await api.get(`/purchase-invoices/${id}`);
    const data = res.data.data;

    setEditingId(id);
    setInvoice({
      branch_id: data.invoice.branch_id || 1,
      supplier_id: String(data.invoice.supplier_id || ""),
      car_id: String(data.invoice.car_id || ""),
      invoice_number: data.invoice.invoice_number || "",
      invoice_date: data.invoice.invoice_date || "",
      discount_amount: Number(data.invoice.discount_amount || 0),
      transport_cost: Number(data.invoice.transport_cost || 0),
      extra_cost: Number(data.invoice.extra_cost || 0),
      notes: data.invoice.notes || "",
    });

    setLines(
      data.lines.map((l: any) => ({
        item_id: String(l.item_id),
        qty: Number(l.qty || 0),
        unit_price: Number(l.unit_price || 0),
        discount_amount: Number(l.discount_amount || 0),
        line_total: Number(l.line_total || 0),
        notes: l.notes || "",
      }))
    );

    setShowForm(true);
  };

  const deletePurchase = async (id: number) => {
    if (!confirm("هل تريد حذف فاتورة الشراء؟")) return;
    await api.delete(`/purchase-invoices/${id}`);
    alert("تم حذف الفاتورة");
    loadAll();
  };

  return (
    <section dir="rtl" className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-5 text-white shadow-lg sm:p-7">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm text-blue-100">المشتريات</p>
            <h1 className="mt-2 text-2xl font-bold sm:text-4xl">
              فواتير شراء السكراب
            </h1>
          </div>

          <button
            onClick={openAddForm}
            className="rounded-2xl bg-white px-5 py-3 font-bold text-[#0B2A4A] shadow"
          >
            + إضافة فاتورة
          </button>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 sm:max-w-md">
          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">عدد الفواتير</div>
            <div className="mt-1 text-3xl font-bold">{purchases.length}</div>
          </div>

          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">إجمالي الشراء</div>
            <div className="mt-1 text-2xl font-bold">
              {purchases
                .reduce((s, p) => s + Number(p.total_amount || 0), 0)
                .toFixed(3)}
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-200 p-4">
          <h2 className="text-xl font-bold text-slate-900">قائمة الفواتير</h2>
          <span className="text-sm text-slate-500">
            {loading ? "جاري التحميل..." : `${purchases.length} فاتورة`}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-[1000px] w-full text-right">
            <thead className="bg-slate-100 text-slate-600">
              <tr>
                <th className="p-4">رقم الفاتورة</th>
                <th className="p-4">التاريخ</th>
                <th className="p-4">المورد</th>
                <th className="p-4">السيارة</th>
                <th className="p-4">الكمية</th>
                <th className="p-4">الإجمالي</th>
                <th className="p-4">الحالة</th>
                <th className="p-4">الإجراءات</th>
              </tr>
            </thead>

            <tbody>
              {purchases.length === 0 ? (
                <tr>
                  <td className="p-6 text-center text-slate-500" colSpan={8}>
                    لا توجد فواتير
                  </td>
                </tr>
              ) : (
                purchases.map((p) => (
                  <tr key={p.id} className="border-t border-slate-100">
                    <td className="p-4 font-bold text-[#0B2A4A]">
                      {p.invoice_number || "-"}
                    </td>
                    <td className="p-4">{p.invoice_date || "-"}</td>
                    <td className="p-4">{p.supplier_name || "-"}</td>
                    <td className="p-4">{p.car_number || "-"}</td>
                    <td className="p-4">{Number(p.total_qty || 0).toFixed(3)}</td>
                    <td className="p-4">{Number(p.total_amount || 0).toFixed(3)}</td>
                    <td className="p-4">
                      <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-700">
                        {p.payment_status || "UNPAID"}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => editPurchase(p.id)}
                          className="rounded-xl bg-blue-700 px-4 py-2 text-sm font-bold text-white"
                        >
                          تعديل
                        </button>
                        <button
                          onClick={() => deletePurchase(p.id)}
                          className="rounded-xl bg-rose-600 px-4 py-2 text-sm font-bold text-white"
                        >
                          حذف
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm">
          <div className="absolute left-0 top-0 h-full w-full overflow-y-auto bg-white p-5 shadow-2xl xl:w-[900px]">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-[#0B2A4A]">
                  {editingId ? "تعديل فاتورة شراء" : "إضافة فاتورة شراء"}
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  اختر المورد والسيارة ثم أضف الأصناف والكميات والأسعار.
                </p>
              </div>

              <button
                onClick={() => setShowForm(false)}
                className="rounded-xl bg-slate-200 px-4 py-2 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">المورد</span>
                <select
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={invoice.supplier_id}
                  onChange={(e) => setInvoice({ ...invoice, supplier_id: e.target.value })}
                >
                  <option value="">اختر المورد</option>
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>{s.supplier_name}</option>
                  ))}
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">السيارة</span>
                <select
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={invoice.car_id}
                  onChange={(e) => setInvoice({ ...invoice, car_id: e.target.value })}
                >
                  <option value="">اختر السيارة</option>
                  {cars.map((c) => (
                    <option key={c.id} value={c.id}>{c.car_number || c.plate_number}</option>
                  ))}
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">رقم الفاتورة</span>
                <input
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={invoice.invoice_number}
                  onChange={(e) => setInvoice({ ...invoice, invoice_number: e.target.value })}
                  placeholder="مثال: PUR-0001"
                />
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">تاريخ الفاتورة</span>
                <input
                  type="date"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={invoice.invoice_date}
                  onChange={(e) => setInvoice({ ...invoice, invoice_date: e.target.value })}
                />
              </label>
            </div>

            <div className="mt-6 rounded-3xl border border-slate-200 p-4">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-xl font-bold text-[#0B2A4A]">الأصناف</h3>
                <button
                  onClick={addLine}
                  className="rounded-2xl bg-[#0B2A4A] px-4 py-3 font-bold text-white"
                >
                  + صنف
                </button>
              </div>

              <div className="space-y-3">
                {lines.map((line, index) => (
                  <div key={index} className="rounded-2xl bg-slate-50 p-3">
                    <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-5">
                      <label className="space-y-1 xl:col-span-1">
                        <span className="text-xs font-bold text-slate-500">الصنف</span>
                        <select
                          className="w-full rounded-xl border border-slate-200 bg-white p-3"
                          value={line.item_id}
                          onChange={(e) => updateLine(index, "item_id", e.target.value)}
                        >
                          <option value="">اختر الصنف</option>
                          {items.map((item) => (
                            <option key={item.id} value={item.id}>{item.item_name}</option>
                          ))}
                        </select>
                      </label>

                      <label className="space-y-1">
                        <span className="text-xs font-bold text-slate-500">الكمية / طن</span>
                        <input
                          type="number"
                          className="w-full rounded-xl border border-slate-200 bg-white p-3"
                          value={line.qty}
                          onChange={(e) => updateLine(index, "qty", e.target.value)}
                        />
                      </label>

                      <label className="space-y-1">
                        <span className="text-xs font-bold text-slate-500">سعر الطن</span>
                        <input
                          type="number"
                          className="w-full rounded-xl border border-slate-200 bg-white p-3"
                          value={line.unit_price}
                          onChange={(e) => updateLine(index, "unit_price", e.target.value)}
                        />
                      </label>

                      <label className="space-y-1">
                        <span className="text-xs font-bold text-slate-500">خصم السطر</span>
                        <input
                          type="number"
                          className="w-full rounded-xl border border-slate-200 bg-white p-3"
                          value={line.discount_amount}
                          onChange={(e) => updateLine(index, "discount_amount", e.target.value)}
                        />
                      </label>

                      <div className="flex items-end gap-2">
                        <div className="flex-1 rounded-xl bg-blue-50 p-3 text-center font-bold text-[#0B2A4A]">
                          الإجمالي: {Number(line.line_total || 0).toFixed(3)}
                        </div>
                        <button
                          onClick={() => removeLine(index)}
                          className="rounded-xl bg-rose-600 px-4 py-3 font-bold text-white"
                        >
                          حذف
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6 grid grid-cols-1 gap-3 md:grid-cols-3">
              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">خصم الفاتورة</span>
                <input
                  type="number"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4"
                  value={invoice.discount_amount}
                  onChange={(e) => setInvoice({ ...invoice, discount_amount: Number(e.target.value) })}
                />
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">إيجار / نقل</span>
                <input
                  type="number"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4"
                  value={invoice.transport_cost}
                  onChange={(e) => setInvoice({ ...invoice, transport_cost: Number(e.target.value) })}
                />
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">مصاريف أخرى</span>
                <input
                  type="number"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4"
                  value={invoice.extra_cost}
                  onChange={(e) => setInvoice({ ...invoice, extra_cost: Number(e.target.value) })}
                />
              </label>
            </div>

            <textarea
              className="mt-3 min-h-24 w-full rounded-2xl border border-slate-200 bg-slate-50 p-4"
              placeholder="ملاحظات"
              value={invoice.notes}
              onChange={(e) => setInvoice({ ...invoice, notes: e.target.value })}
            />

            <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
              <div className="rounded-2xl bg-slate-100 p-4">
                <div className="text-sm text-slate-500">إجمالي الكمية</div>
                <div className="mt-1 text-2xl font-bold">{totalQty.toFixed(3)}</div>
              </div>

              <div className="rounded-2xl bg-slate-100 p-4">
                <div className="text-sm text-slate-500">قبل الخصم</div>
                <div className="mt-1 text-2xl font-bold">{subtotal.toFixed(3)}</div>
              </div>

              <div className="rounded-2xl bg-blue-50 p-4">
                <div className="text-sm text-[#0B2A4A]">الإجمالي النهائي</div>
                <div className="mt-1 text-2xl font-bold text-[#0B2A4A]">
                  {finalTotal.toFixed(3)}
                </div>
              </div>

              <button
                onClick={saveInvoice}
                disabled={saving}
                className="rounded-2xl bg-[#0B2A4A] p-4 text-lg font-bold text-white disabled:opacity-60"
              >
                {saving ? "جاري الحفظ..." : editingId ? "حفظ التعديل" : "حفظ الفاتورة"}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}