"use client";

import { useEffect, useState } from "react";
import api from "../api";

export default function CompaniesPage() {
  const [companies, setCompanies] = useState<any[]>([]);
  const [plans, setPlans] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    company_name: "",
    owner_name: "",
    phone: "",
    email: "",
    city: "",
    address: "",
    plan_id: "",
    start_date: "",
    end_date: "",
  });

  const loadData = async () => {
    const [companiesRes, plansRes] = await Promise.all([
      api.get("/companies"),
      api.get("/plans"),
    ]);

    setCompanies(companiesRes.data.data || []);
    setPlans(plansRes.data.data || []);
  };

  useEffect(() => {
    loadData();
  }, []);

  const saveCompany = async () => {
    if (!form.company_name) return alert("أدخل اسم الشركة");
    if (!form.owner_name) return alert("أدخل اسم المالك");
    if (!form.phone) return alert("أدخل رقم الجوال");
    if (!form.plan_id) return alert("اختر الباقة");
    if (!form.start_date || !form.end_date) return alert("حدد تاريخ الاشتراك");

    setLoading(true);

    try {
      await api.post("/companies", form);
      alert("تم إنشاء الشركة والاشتراك بنجاح");

      setForm({
        company_name: "",
        owner_name: "",
        phone: "",
        email: "",
        city: "",
        address: "",
        plan_id: "",
        start_date: "",
        end_date: "",
      });

      loadData();
    } catch (error: any) {
      alert(error?.response?.data?.message || "حدث خطأ أثناء الحفظ");
    } finally {
      setLoading(false);
    }
  };

  const supportAccess = async (companyId: number) => {
    try {
      const res = await api.get(`/companies/${companyId}/support-access`);

      localStorage.setItem("scrap_user", JSON.stringify(res.data.user));
      localStorage.setItem("scrap_subscription", JSON.stringify(res.data.subscription));
      localStorage.setItem("scrap_permissions", JSON.stringify(res.data.user.permissions || []));

      window.location.href = "/";
    } catch (error: any) {
      alert(error?.response?.data?.message || "فشل دخول الدعم");
    }
  };

  return (
    <section dir="rtl" className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-6 text-white shadow-lg">
        <p className="text-sm text-blue-100">إدارة الشركات والاشتراكات</p>
        <h1 className="mt-2 text-3xl font-bold">الشركات</h1>
        <p className="mt-2 text-sm text-blue-100">
          إنشاء عميل جديد، اختيار الباقة، وتحديد مدة الاشتراك.
        </p>

        <div className="mt-5 w-fit rounded-2xl bg-white/10 p-4">
          <div className="text-sm text-blue-100">إجمالي الشركات</div>
          <div className="mt-1 text-3xl font-bold">{companies.length}</div>
        </div>
      </div>

      <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
        <h2 className="mb-4 text-xl font-bold text-[#0B2A4A]">إضافة شركة جديدة</h2>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          <input className="rounded-2xl border bg-slate-50 p-4" placeholder="اسم الشركة" value={form.company_name} onChange={(e) => setForm({ ...form, company_name: e.target.value })} />
          <input className="rounded-2xl border bg-slate-50 p-4" placeholder="اسم المالك" value={form.owner_name} onChange={(e) => setForm({ ...form, owner_name: e.target.value })} />
          <input className="rounded-2xl border bg-slate-50 p-4" placeholder="الجوال" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <input className="rounded-2xl border bg-slate-50 p-4" placeholder="البريد الإلكتروني" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <input className="rounded-2xl border bg-slate-50 p-4" placeholder="المدينة" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
          <input className="rounded-2xl border bg-slate-50 p-4" placeholder="العنوان" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />

          <select className="rounded-2xl border bg-slate-50 p-4" value={form.plan_id} onChange={(e) => setForm({ ...form, plan_id: e.target.value })}>
            <option value="">اختر الباقة</option>
            {plans.map((plan) => (
              <option key={plan.id} value={plan.id}>
                {plan.plan_name} - {Number(plan.monthly_price || 0).toFixed(3)}
              </option>
            ))}
          </select>

          <input type="date" className="rounded-2xl border bg-slate-50 p-4" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
          <input type="date" className="rounded-2xl border bg-slate-50 p-4" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} />
        </div>

        <button
          onClick={saveCompany}
          disabled={loading}
          className="mt-5 rounded-2xl bg-[#0B2A4A] px-8 py-4 font-bold text-white disabled:opacity-60"
        >
          {loading ? "جاري الحفظ..." : "حفظ الشركة"}
        </button>
      </div>

      <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b p-4">
          <h2 className="text-xl font-bold text-[#0B2A4A]">الشركات الحالية</h2>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-[1200px] w-full text-right">
            <thead className="bg-slate-100 text-slate-700">
              <tr>
                <th className="p-4">الشركة</th>
                <th className="p-4">المالك</th>
                <th className="p-4">الجوال</th>
                <th className="p-4">الباقة</th>
                <th className="p-4">بداية الاشتراك</th>
                <th className="p-4">نهاية الاشتراك</th>
                <th className="p-4">الحالة</th>
                <th className="p-4">العمليات</th>
              </tr>
            </thead>

            <tbody>
              {companies.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-6 text-center text-slate-500">
                    لا توجد شركات
                  </td>
                </tr>
              ) : (
                companies.map((item) => (
                  <tr key={item.id} className="border-t hover:bg-slate-50">
                    <td className="p-4 font-bold text-[#0B2A4A]">{item.company_name}</td>
                    <td className="p-4">{item.owner_name}</td>
                    <td className="p-4">{item.phone}</td>
                    <td className="p-4">{item.plan_name || "-"}</td>
                    <td className="p-4">{item.start_date || "-"}</td>
                    <td className="p-4">{item.end_date || "-"}</td>
                    <td className="p-4">
                      <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">
                        {item.status || "ACTIVE"}
                      </span>
                    </td>
                    <td className="p-4">
                      <button
                        onClick={() => supportAccess(item.id)}
                        className="rounded-xl bg-[#0B2A4A] px-4 py-2 text-sm font-bold text-white hover:bg-[#123D68]"
                      >
                        دخول دعم
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}