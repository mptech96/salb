"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

import "./globals.css";

type MenuItem = {
  href: string;
  label: string;
  permission?: string;
  icon?: string;
};

/*
|--------------------------------------------------------------------------
| قائمة بوابة إدارة المنصة
|--------------------------------------------------------------------------
|
| هذه القائمة تظهر فقط لمدير المنصة الحقيقي.
| لا تحتوي على عمليات الشركة التشغيلية.
|
*/

const platformMenu: MenuItem[] = [
  {
    href: "/system-center",
    label: "لوحة إدارة المنصة",
    icon: "▦",
  },
  {
    href: "/system-center/companies",
    label: "الشركات",
    icon: "🏢",
   },
  {
  href: "/system-center/subscriptions",
  label: "الاشتراكات",
  icon: "💳",
  },
  {
  href: "/system-center/plans",
  label: "الباقات",
  icon: "💎",
   },
   {
  href: "/system-center/payments",
  label: "الفواتير والمدفوعات",
  icon: "💰",
   },
  {
    href: "/users",
    label: "مستخدمو الشركات",
    icon: "👥",
  },
  {
    href: "/branches",
    label: "فروع الشركات",
    icon: "🏬",
  },
  {
    href: "/audit-logs",
    label: "سجل العمليات",
    icon: "🧾",
  },
];

/*
|--------------------------------------------------------------------------
| قائمة بوابة الشركة
|--------------------------------------------------------------------------
*/

const companyMenu: MenuItem[] = [
  {
    href: "/",
    label: "الرئيسية",
    permission: "dashboard.view",
    icon: "⌂",
  },
  {
    href: "/users",
    label: "المستخدمون",
    permission: "users.view",
    icon: "👥",
  },
  {
    href: "/branches",
    label: "الفروع",
    permission: "branches.view",
    icon: "🏬",
  },
  {
    href: "/items",
    label: "الأصناف",
    permission: "items.view",
    icon: "▤",
  },
  {
    href: "/cars",
    label: "السيارات",
    permission: "cars.view",
    icon: "🚚",
  },
  {
    href: "/suppliers",
    label: "الموردون",
    permission: "suppliers.view",
    icon: "📦",
  },
  {
    href: "/customers",
    label: "العملاء",
    permission: "customers.view",
    icon: "👤",
  },
  {
    href: "/purchases",
    label: "المشتريات",
    permission: "purchases.view",
    icon: "🛒",
  },
  {
    href: "/sales",
    label: "المبيعات",
    permission: "sales.view",
    icon: "🧾",
  },
  {
    href: "/inventory",
    label: "المخزون",
    permission: "inventory.view",
    icon: "▦",
  },
  {
    href: "/fixed-assets/workspace",
    label: "الأصول الثابتة",
    permission: "dashboard.view",
    icon: "🏗️",
  },
  {
    href: "/shipments",
    label: "الحمولات",
    permission: "shipments.view",
    icon: "🚛",
  },
  {
    href: "/drivers",
    label: "السائقون",
    permission: "drivers.view",
    icon: "🚘",
  },
  {
    href: "/workers",
    label: "الموارد البشرية",
    permission: "workers.view",
    icon: "👷",
  },
  {
    href: "/payroll",
    label: "الرواتب",
    permission: "workers.view",
    icon: "💳",
  },
  {
    href: "/expenses",
    label: "المصروفات",
    permission: "expenses.view",
    icon: "💸",
  },
  {
    href: "/vouchers",
    label: "السندات",
    permission: "vouchers.view",
    icon: "📄",
  },
  {
    href: "/accounts",
    label: "شجرة الحسابات",
    permission: "accounts.view",
    icon: "🌳",
  },
  {
    href: "/statements",
    label: "كشوف الحسابات",
    permission: "statements.view",
    icon: "📑",
  },
  {
    href: "/reports",
    label: "التقارير",
    permission: "reports.view",
    icon: "📊",
  },
  {
    href: "/official-documents",
    label: "الأوراق الرسمية",
    permission: "official_documents.view",
    icon: "📁",
  },
  {
    href: "/audit-logs",
    label: "سجل الأنشطة",
    permission: "audit_logs.view",
    icon: "🧾",
  },
  {
    href: "/settings",
    label: "إعدادات الشركة",
    permission: "settings.view",
    icon: "⚙️",
  },
];

/*
|--------------------------------------------------------------------------
| المسارات الخاصة بمدير المنصة
|--------------------------------------------------------------------------
*/

const superOnlyPaths = [
  "/system-center",
];

/*
|--------------------------------------------------------------------------
| التخطيط الرئيسي
|--------------------------------------------------------------------------
*/

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const pathname = usePathname();
  const router = useRouter();

  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [permissions, setPermissions] = useState<string[]>([]);

  const isLoginPage = pathname === "/login";

  /*
  |--------------------------------------------------------------------------
  | تحميل جلسة المستخدم
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    const savedUser = localStorage.getItem("scrap_user");
    const savedPermissions = localStorage.getItem("scrap_permissions");

    if (!savedUser && !isLoginPage) {
      router.replace("/login");
      return;
    }

    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser);

        setUser(parsedUser);

        const roleCode = parsedUser?.role?.role_code;
        const isSuperUser = roleCode === "SUPER_ADMIN";

        const isSuperPath = superOnlyPaths.some(
          (path) =>
            pathname === path ||
            pathname.startsWith(`${path}/`)
        );

        if (isSuperPath && !isSuperUser) {
          router.replace("/");
          return;
        }
      } catch {
        clearCurrentSession();
        router.replace("/login");
        return;
      }
    }

    if (savedPermissions) {
      try {
        const parsedPermissions = JSON.parse(savedPermissions);

        setPermissions(
          Array.isArray(parsedPermissions)
            ? parsedPermissions
            : []
        );
      } catch {
        setPermissions([]);
      }
    } else {
      setPermissions([]);
    }

    setReady(true);
  }, [pathname, router, isLoginPage]);

  /*
  |--------------------------------------------------------------------------
  | تحديد نوع البوابة
  |--------------------------------------------------------------------------
  |
  | مدير المنصة:
  | SUPER_ADMIN ولا يحمل company_id وليس في وضع الدعم.
  |
  | عند دخول الدعم يصبح لديه company_id و is_support_mode.
  |
  */

  const isSuper =
    user?.role?.role_code === "SUPER_ADMIN";

  const isSupportMode =
    user?.is_support_mode === true;

  const isPlatformAdmin =
    isSuper &&
    !user?.company_id &&
    !isSupportMode;

  /*
  |--------------------------------------------------------------------------
  | القائمة المسموحة
  |--------------------------------------------------------------------------
  */

  const allowedMenu = useMemo(() => {
    if (!user) {
      return [];
    }

    if (isPlatformAdmin) {
      return platformMenu;
    }

    return companyMenu.filter((item) => {
      if (!item.permission) {
        return true;
      }

      if (isSuper) {
        return true;
      }

      return permissions.includes(item.permission);
    });
  }, [
    user,
    permissions,
    isSuper,
    isPlatformAdmin,
  ]);

  /*
  |--------------------------------------------------------------------------
  | تسجيل الخروج
  |--------------------------------------------------------------------------
  */

  function clearCurrentSession() {
    localStorage.removeItem("scrap_user");
    localStorage.removeItem("scrap_subscription");
    localStorage.removeItem("scrap_permissions");
  }

  function logout() {
    clearCurrentSession();

    localStorage.removeItem(
      "scrap_platform_admin_user"
    );

    localStorage.removeItem(
      "scrap_platform_admin_permissions"
    );

    router.replace("/login");
  }

  /*
  |--------------------------------------------------------------------------
  | تحديد الرابط النشط
  |--------------------------------------------------------------------------
  */

  function isMenuItemActive(
    href: string
  ): boolean {
    if (href === "/") {
      return pathname === "/";
    }

    return (
      pathname === href ||
      pathname.startsWith(`${href}/`)
    );
  }

  /*
  |--------------------------------------------------------------------------
  | شاشة التحميل
  |--------------------------------------------------------------------------
  */

  if (!ready && !isLoginPage) {
    return (
      <html lang="ar" dir="rtl">
        <body className="min-h-screen bg-slate-100">
          <div className="flex min-h-screen items-center justify-center font-bold text-[#0B2A4A]">
            جاري تحميل النظام...
          </div>
        </body>
      </html>
    );
  }

  /*
  |--------------------------------------------------------------------------
  | تسجيل الدخول
  |--------------------------------------------------------------------------
  */

  if (isLoginPage) {
    return (
      <html lang="ar" dir="rtl">
        <body className="min-h-screen bg-slate-100 text-slate-900">
          {children}
        </body>
      </html>
    );
  }

  /*
  |--------------------------------------------------------------------------
  | واجهة النظام
  |--------------------------------------------------------------------------
  */

  return (
    <html lang="ar" dir="rtl">
      <body className="min-h-screen bg-slate-100 text-slate-900">
        <div className="flex min-h-screen flex-col lg:flex-row">
          <aside className="bg-[#0B2A4A] text-white lg:sticky lg:top-0 lg:h-screen lg:w-72 lg:shrink-0">
            <div className="border-b border-white/10 p-5">
              <div className="flex items-center gap-3">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-2xl bg-white p-1 shadow-sm">
                  <img
                    src="/sulb-logo.png"
                    alt="شعار صلب ERP"
                    className="h-full w-full object-contain"
                  />
                </div>

                <div className="min-w-0">
                  <h1 className="truncate text-xl font-black">
                    صلب ERP
                  </h1>

                  <p className="mt-0.5 truncate text-[10px] font-semibold tracking-[0.18em] text-blue-100">
                    SULB ERP
                  </p>

                  <p className="mt-1 truncate text-xs text-blue-100">
                    {isPlatformAdmin
                      ? "بوابة إدارة المنصة"
                      : user?.company_name ||
                        "بوابة الشركة"}
                  </p>
                </div>
              </div>

              <div className="mt-4 rounded-2xl bg-white/10 p-3">
                <div className="text-sm font-bold">
                  {user?.name || "-"}
                </div>

                <div className="mt-1 text-xs text-blue-100">
                  {isPlatformAdmin
                    ? "مدير المنصة | مركز التحكم"
                    : `${
                        user?.branch_name || "-"
                      } | ${
                        user?.role?.role_name || "-"
                      }`}
                </div>
              </div>

              {isPlatformAdmin ? (
                <div className="mt-3 rounded-xl border border-cyan-300/20 bg-cyan-400/10 px-3 py-2 text-xs font-bold text-cyan-100">
                  إدارة الشركات والاشتراكات والمنصة
                </div>
              ) : null}

              {isSupportMode ? (
                <div className="mt-3 rounded-xl border border-amber-300/30 bg-amber-400/10 px-3 py-2 text-xs font-bold text-amber-100">
                  وضع الدعم الفني مفعل
                </div>
              ) : null}
            </div>

            <nav className="flex gap-2 overflow-x-auto px-4 py-4 lg:block lg:max-h-[calc(100vh-210px)] lg:space-y-2 lg:overflow-y-auto">
              {allowedMenu.map((item) => {
                const active =
                  isMenuItemActive(item.href);

                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center gap-3 whitespace-nowrap rounded-xl px-4 py-3 text-sm font-semibold transition ${
                      active
                        ? "bg-white text-[#0B2A4A] shadow"
                        : "text-blue-50 hover:bg-white/10"
                    }`}
                  >
                    <span className="flex w-6 shrink-0 justify-center text-base">
                      {item.icon || "•"}
                    </span>

                    <span>{item.label}</span>
                  </Link>
                );
              })}

              <div className="my-3 hidden border-t border-white/10 lg:block" />

              <button
                type="button"
                onClick={logout}
                className="w-full whitespace-nowrap rounded-xl bg-rose-600 px-4 py-3 text-sm font-bold text-white transition hover:bg-rose-700"
              >
                تسجيل الخروج
              </button>
            </nav>
          </aside>

          <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-8">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}