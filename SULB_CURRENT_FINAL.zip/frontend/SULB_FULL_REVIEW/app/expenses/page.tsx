"use client";

import { useEffect, useMemo, useState } from "react";
import api from "../api";

export default function ExpensesPage() {
  const [expenses, setExpenses] = useState<any[]>([]);
  const [types, setTypes] = useState<any[]>([]);
  const [refs, setRefs] = useState<any>({
    shipments: [],
    cars: [],
    purchases: [],
    sales: [],
    drivers: [],
    workers: [],
  });

  const [search, setSearch] = useState("");
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [showTypeForm, setShowTypeForm] = useState(false);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState(defaultExpense());
  const [typeForm, setTypeForm] = useState(defaultType());

  useEffect(() => {
    loadAll();
  }, []);

  async function loadAll() {
    const [ex, ty, sh, ca, pi, si, dr, wo] = await Promise.allSettled([
      api.get("/expenses"),
      api.get("/expense-types"),
      api.get("/shipments"),
      api.get("/cars"),
      api.get("/purchase-invoices"),
      api.get("/sales-invoices"),
      api.get("/drivers"),
      api.get("/workers"),
    ]);

    setExpenses(ex.status === "fulfilled" ? ex.value.data.data || [] : []);
    setTypes(ty.status === "fulfilled" ? ty.value.data.data || [] : []);

    setRefs({
      shipments: sh.status === "fulfilled" ? sh.value.data.data || [] : [],
      cars: ca.status === "fulfilled" ? ca.value.data.data || [] : [],
      purchases: pi.status === "fulfilled" ? pi.value.data.data || [] : [],
      sales: si.status === "fulfilled" ? si.value.data.data || [] : [],
      drivers: dr.status === "fulfilled" ? dr.value.data.data || [] : [],
      workers: wo.status === "fulfilled" ? wo.value.data.data || [] : [],
    });
  }

  function openNewExpense() {
    setForm(defaultExpense());
    setShowExpenseForm(true);
  }

  function selectedType() {
    return types.find((x) => String(x.id) === String(form.expense_type_id));
  }

  function applyTypeDefaults(typeId: any) {
    const t = types.find((x) => String(x.id) === String(typeId));

    setForm({
      ...form,
      expense_type_id: typeId,
      scope_type: t?.default_scope || "GENERAL",
    });
  }

  async function saveExpense() {
    if (!form.expense_type_id) return alert("اختر نوع المصروف");
    if (!form.expense_date) return alert("اختر تاريخ المصروف");
    if (!form.amount || Number(form.amount) <= 0) return alert("أدخل مبلغ صحيح");

    try {
      setSaving(true);

      const payload: any = {
        expense_type_id: Number(form.expense_type_id),
        expense_date: form.expense_date,
        scope_type: form.scope_type,
        amount: Number(form.amount),
        payment_status: form.payment_status,
        payment_method: form.payment_method,
        expense_effect: form.expense_effect,
        notes: form.notes,
      };

      if (form.scope_type === "SHIPMENT") payload.shipment_id = form.reference_id;
      if (form.scope_type === "CAR") payload.car_id = form.reference_id;
      if (form.scope_type === "PURCHASE_INVOICE") payload.purchase_invoice_id = form.reference_id;
      if (form.scope_type === "SALES_INVOICE") payload.sales_invoice_id = form.reference_id;
      if (form.scope_type === "DRIVER") payload.driver_id = form.reference_id;
      if (form.scope_type === "WORKER") payload.worker_id = form.reference_id;

      await api.post("/expenses", payload);

      alert("تم حفظ المصروف وإنشاء السند والقيد حسب الحالة");
      setShowExpenseForm(false);
      await loadAll();
    } catch (e: any) {
      alert(e?.response?.data?.message || "فشل حفظ المصروف");
    } finally {
      setSaving(false);
    }
  }

  async function saveExpenseType() {
    if (!typeForm.type_name.trim()) return alert("اكتب اسم نوع المصروف");

    try {
      setSaving(true);

      const res = await api.post("/expense-types", {
        type_name: typeForm.type_name,
        type_code: typeForm.type_code || null,
        default_scope: typeForm.default_scope,
        affects_cost: Number(typeForm.affects_cost),
        description: typeForm.description || null,
        account_id: null,
      });

      alert("تم إنشاء نوع المصروف وحسابه المحاسبي تلقائيًا");

      setShowTypeForm(false);
      setTypeForm(defaultType());

      await loadAll();

      if (res.data.id) {
        setForm((old: any) => ({
          ...old,
          expense_type_id: res.data.id,
          scope_type: typeForm.default_scope,
        }));
      }
    } catch (e: any) {
      alert(e?.response?.data?.message || "فشل إضافة نوع المصروف");
    } finally {
      setSaving(false);
    }
  }

  const filtered = useMemo(() => {
    return expenses.filter((x) =>
      `${x.type_name || ""} ${x.notes || ""} ${x.voucher_number || ""} ${x.shipment_number || ""} ${x.car_number || ""}`
        .toLowerCase()
        .includes(search.toLowerCase())
    );
  }, [expenses, search]);

  const total = filtered.reduce((s, x) => s + Number(x.amount || 0), 0);

  return (
    <section dir="rtl" className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-6 text-white shadow-lg">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-sm text-blue-100">إدارة المصروفات</p>
            <h1 className="mt-2 text-3xl font-black">مركز المصروفات</h1>
            <p className="mt-2 text-sm text-blue-100">
              سجّل المصروف، اربطه بحمولة أو سيارة أو فاتورة أو عامل، والنظام ينشئ سند وقيد محاسبي تلقائيًا.
            </p>
          </div>

          <div className="flex gap-2">
            <button onClick={() => setShowTypeForm(true)} className="rounded-2xl bg-white/15 px-5 py-3 font-bold text-white">
              + نوع مصروف
            </button>
            <button onClick={openNewExpense} className="rounded-2xl bg-white px-5 py-3 font-bold text-[#0B2A4A]">
              + مصروف جديد
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
        <Stat title="عدد المصروفات" value={expenses.length} />
        <Stat title="إجمالي المعروض" value={money(total)} />
        <Stat title="المدفوعة" value={expenses.filter((x) => x.payment_status === "PAID").length} />
        <Stat title="لها سند" value={expenses.filter((x) => x.voucher_id).length} />
      </div>

      <div className="rounded-3xl border bg-white p-4 shadow-sm">
        <input
          className="w-full rounded-2xl border bg-slate-50 p-4 outline-none"
          placeholder="بحث بنوع المصروف أو السند أو الملاحظات أو الحمولة..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="overflow-hidden rounded-3xl border bg-white shadow-sm">
        <div className="border-b p-4">
          <h2 className="text-xl font-black text-[#0B2A4A]">قائمة المصروفات</h2>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-[1200px] w-full text-right">
            <thead className="bg-slate-100">
              <tr>
                <th className="p-4">التاريخ</th>
                <th className="p-4">النوع</th>
                <th className="p-4">المبلغ</th>
                <th className="p-4">مرتبط بـ</th>
                <th className="p-4">طريقة الدفع</th>
                <th className="p-4">الحالة</th>
                <th className="p-4">السند</th>
                <th className="p-4">القيد</th>
                <th className="p-4">ملاحظات</th>
              </tr>
            </thead>

            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-6 text-center text-slate-500">لا توجد مصروفات</td>
                </tr>
              ) : (
                filtered.map((x) => (
                  <tr key={x.id} className="border-t hover:bg-slate-50">
                    <td className="p-4">{x.expense_date}</td>
                    <td className="p-4 font-black text-[#0B2A4A]">{x.type_name || "-"}</td>
                    <td className="p-4 font-bold">{money(x.amount)}</td>
                    <td className="p-4">{refLabel(x)}</td>
                    <td className="p-4">{paymentMethodLabel(x.payment_method)}</td>
                    <td className="p-4">{x.payment_status === "PAID" ? "مدفوع" : "غير مدفوع"}</td>
                    <td className="p-4">{x.voucher_number || x.voucher_id || "-"}</td>
                    <td className="p-4">{x.journal_entry_id || "-"}</td>
                    <td className="p-4">{x.notes || "-"}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showExpenseForm && (
        <Modal title="إضافة مصروف" onClose={() => setShowExpenseForm(false)}>
          <InfoBox text="إذا كان المصروف مدفوعًا، سيتم إنشاء سند صرف وقيد محاسبي. إذا كان غير مدفوع، سنطوره لاحقًا ليذهب إلى مستحقات." />

          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <Select
              label="نوع المصروف *"
              value={form.expense_type_id}
              onChange={applyTypeDefaults}
              options={[
                { id: "", name: "اختر نوع المصروف" },
                ...types.filter((x) => Number(x.is_active) === 1).map((x) => ({
                  id: x.id,
                  name: `${x.type_name}${x.account_code ? ` - ${x.account_code}` : ""}`,
                })),
              ]}
            />

            <button onClick={() => setShowTypeForm(true)} className="mt-6 rounded-2xl bg-blue-700 px-5 py-3 font-bold text-white">
              + إضافة نوع سريع
            </button>

            <Input type="date" label="تاريخ المصروف *" value={form.expense_date} onChange={(v: any) => setForm({ ...form, expense_date: v })} />

            <Input type="number" label="المبلغ *" value={form.amount} onChange={(v: any) => setForm({ ...form, amount: v })} />

            <Select
              label="مرتبط بـ"
              value={form.scope_type}
              onChange={(v: any) => setForm({ ...form, scope_type: v, reference_id: "" })}
              options={[
                { id: "GENERAL", name: "عام" },
                { id: "SHIPMENT", name: "حمولة" },
                { id: "CAR", name: "سيارة" },
                { id: "PURCHASE_INVOICE", name: "فاتورة شراء" },
                { id: "SALES_INVOICE", name: "فاتورة بيع" },
                { id: "DRIVER", name: "سائق" },
                { id: "WORKER", name: "عامل" },
              ]}
            />

            {form.scope_type !== "GENERAL" && (
              <Select
                label="اختر المرجع"
                value={form.reference_id}
                onChange={(v: any) => setForm({ ...form, reference_id: v })}
                options={referenceOptions(form.scope_type, refs)}
              />
            )}

            <Select
              label="حالة الدفع"
              value={form.payment_status}
              onChange={(v: any) => setForm({ ...form, payment_status: v })}
              options={[
                { id: "PAID", name: "مدفوع الآن - ينشئ سند وقيد" },
                { id: "UNPAID", name: "غير مدفوع" },
              ]}
            />

            <Select
              label="طريقة الدفع"
              value={form.payment_method}
              onChange={(v: any) => setForm({ ...form, payment_method: v })}
              options={[
                { id: "CASH", name: "نقد" },
                { id: "BANK", name: "تحويل بنكي" },
                { id: "CARD", name: "بطاقة" },
              ]}
            />

            <Select
              label="تأثير المصروف"
              value={form.expense_effect}
              onChange={(v: any) => setForm({ ...form, expense_effect: v })}
              options={[
                { id: "COST", name: "يدخل في تكلفة التشغيل" },
                { id: "ADMIN", name: "مصروف إداري فقط" },
              ]}
            />
          </div>

          {selectedType() && (
            <div className="rounded-2xl bg-amber-50 p-4 text-sm font-bold text-amber-800">
              الحساب المحاسبي: {selectedType()?.account_code || "-"} - {selectedType()?.account_name || "سيستخدم الحساب العام إذا لم يوجد حساب"}
            </div>
          )}

          <textarea
            className="w-full rounded-2xl border bg-slate-50 p-4"
            rows={4}
            placeholder="ملاحظات"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
          />

          <button disabled={saving} onClick={saveExpense} className="w-full rounded-2xl bg-[#0B2A4A] px-5 py-4 font-black text-white">
            {saving ? "جاري الحفظ..." : "حفظ المصروف"}
          </button>
        </Modal>
      )}

      {showTypeForm && (
        <Modal title="إضافة نوع مصروف سريع" onClose={() => setShowTypeForm(false)}>
          <InfoBox text="اكتب نوع المصروف فقط. إذا لم تحدد حسابًا، النظام سينشئ له حساب مصروف تلقائيًا في شجرة الحسابات." />

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Input label="اسم نوع المصروف *" value={typeForm.type_name} onChange={(v: any) => setTypeForm({ ...typeForm, type_name: v })} />
            <Input label="كود اختياري" value={typeForm.type_code} onChange={(v: any) => setTypeForm({ ...typeForm, type_code: v })} />

            <Select
              label="الارتباط الافتراضي"
              value={typeForm.default_scope}
              onChange={(v: any) => setTypeForm({ ...typeForm, default_scope: v })}
              options={[
                { id: "GENERAL", name: "عام" },
                { id: "SHIPMENT", name: "حمولة" },
                { id: "CAR", name: "سيارة" },
                { id: "PURCHASE_INVOICE", name: "فاتورة شراء" },
                { id: "SALES_INVOICE", name: "فاتورة بيع" },
                { id: "DRIVER", name: "سائق" },
                { id: "WORKER", name: "عامل" },
              ]}
            />

            <Select
              label="هل يؤثر على التكلفة؟"
              value={String(typeForm.affects_cost)}
              onChange={(v: any) => setTypeForm({ ...typeForm, affects_cost: Number(v) })}
              options={[
                { id: "1", name: "نعم" },
                { id: "0", name: "لا" },
              ]}
            />
          </div>

          <textarea
            className="w-full rounded-2xl border bg-slate-50 p-4"
            rows={3}
            placeholder="وصف مختصر"
            value={typeForm.description}
            onChange={(e) => setTypeForm({ ...typeForm, description: e.target.value })}
          />

          <button disabled={saving} onClick={saveExpenseType} className="w-full rounded-2xl bg-[#0B2A4A] px-5 py-4 font-black text-white">
            {saving ? "جاري الحفظ..." : "حفظ نوع المصروف"}
          </button>
        </Modal>
      )}
    </section>
  );
}

function defaultExpense() {
  return {
    expense_type_id: "",
    expense_date: today(),
    scope_type: "GENERAL",
    reference_id: "",
    amount: "",
    payment_status: "PAID",
    payment_method: "CASH",
    expense_effect: "COST",
    notes: "",
  };
}

function defaultType() {
  return {
    type_name: "",
    type_code: "",
    default_scope: "GENERAL",
    affects_cost: 1,
    description: "",
  };
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function Stat({ title, value }: any) {
  return (
    <div className="rounded-3xl border bg-white p-5 shadow-sm">
      <div className="text-sm text-slate-500">{title}</div>
      <div className="mt-2 text-2xl font-black text-[#0B2A4A]">{value}</div>
    </div>
  );
}

function Input({ label, value, onChange, type = "text" }: any) {
  return (
    <label className="block">
      <div className="mb-1 text-sm font-bold text-slate-700">{label}</div>
      <input type={type} className="w-full rounded-2xl border bg-slate-50 p-3" value={value ?? ""} onChange={(e) => onChange(e.target.value)} />
    </label>
  );
}

function Select({ label, value, onChange, options }: any) {
  return (
    <label className="block">
      <div className="mb-1 text-sm font-bold text-slate-700">{label}</div>
      <select className="w-full rounded-2xl border bg-slate-50 p-3" value={value ?? ""} onChange={(e) => onChange(e.target.value)}>
        {options.map((x: any) => <option key={x.id} value={x.id}>{x.name}</option>)}
      </select>
    </label>
  );
}

function Modal({ title, onClose, children }: any) {
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 p-4 backdrop-blur-sm">
      <div className="mx-auto max-w-6xl rounded-3xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b p-5">
          <h2 className="text-2xl font-black text-[#0B2A4A]">{title}</h2>
          <button onClick={onClose} className="rounded-2xl bg-slate-200 px-5 py-3 font-bold">إغلاق</button>
        </div>
        <div className="space-y-5 p-5">{children}</div>
      </div>
    </div>
  );
}

function InfoBox({ text }: any) {
  return <div className="rounded-2xl bg-blue-50 p-4 text-sm font-bold text-[#0B2A4A]">{text}</div>;
}

function money(v: any) {
  return Number(v || 0).toFixed(3);
}

function paymentMethodLabel(v: string) {
  const map: any = { CASH: "نقد", BANK: "تحويل بنكي", CARD: "بطاقة" };
  return map[v] || v || "-";
}

function refLabel(x: any) {
  if (x.shipment_number) return `حمولة: ${x.shipment_number}`;
  if (x.car_number) return `سيارة: ${x.car_number}`;
  if (x.purchase_invoice_number) return `فاتورة شراء: ${x.purchase_invoice_number}`;
  if (x.sales_invoice_number) return `فاتورة بيع: ${x.sales_invoice_number}`;
  if (x.driver_name) return `سائق: ${x.driver_name}`;
  if (x.worker_name) return `عامل: ${x.worker_name}`;
  return "عام";
}

function referenceOptions(scope: string, refs: any) {
  if (scope === "SHIPMENT") return [{ id: "", name: "اختر الحمولة" }, ...refs.shipments.map((x: any) => ({ id: x.id, name: x.shipment_number || `حمولة ${x.id}` }))];
  if (scope === "CAR") return [{ id: "", name: "اختر السيارة" }, ...refs.cars.map((x: any) => ({ id: x.id, name: x.car_number || x.plate_number || `سيارة ${x.id}` }))];
  if (scope === "PURCHASE_INVOICE") return [{ id: "", name: "اختر فاتورة الشراء" }, ...refs.purchases.map((x: any) => ({ id: x.id, name: x.invoice_number || `فاتورة ${x.id}` }))];
  if (scope === "SALES_INVOICE") return [{ id: "", name: "اختر فاتورة البيع" }, ...refs.sales.map((x: any) => ({ id: x.id, name: x.invoice_number || `فاتورة ${x.id}` }))];
  if (scope === "DRIVER") return [{ id: "", name: "اختر السائق" }, ...refs.drivers.map((x: any) => ({ id: x.id, name: x.driver_name || `سائق ${x.id}` }))];
  if (scope === "WORKER") return [{ id: "", name: "اختر العامل" }, ...refs.workers.map((x: any) => ({ id: x.id, name: x.worker_name || `عامل ${x.id}` }))];
  return [{ id: "", name: "عام" }];
}