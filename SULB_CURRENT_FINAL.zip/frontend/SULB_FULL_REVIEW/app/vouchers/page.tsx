"use client";

import { useEffect, useMemo, useState } from "react";
import api from "../api";

export default function VouchersPage() {
  const [vouchers, setVouchers] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [drivers, setDrivers] = useState<any[]>([]);
  const [workers, setWorkers] = useState<any[]>([]);

  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);

  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState("ALL");
  const [filterRef, setFilterRef] = useState("ALL");
  const [filterPay, setFilterPay] = useState("ALL");

  const [form, setForm] = useState({
    voucher_type_id: "1",
    voucher_number: "",
    voucher_date: "",
    reference_type: "CUSTOMER",
    reference_id: "",
    amount: "",
    payment_method: "CASH",
    notes: "",
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [v, c, s, d, w] = await Promise.all([
        api.get("/vouchers"),
        api.get("/customers"),
        api.get("/suppliers"),
        api.get("/drivers"),
        api.get("/workers"),
      ]);

      setVouchers(v.data.data || []);
      setCustomers(c.data.data || []);
      setSuppliers(s.data.data || []);
      setDrivers(d.data.data || []);
      setWorkers(w.data.data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const resetForm = () => {
    setEditId(null);
    setForm({
      voucher_type_id: "1",
      voucher_number: "",
      voucher_date: "",
      reference_type: "CUSTOMER",
      reference_id: "",
      amount: "",
      payment_method: "CASH",
      notes: "",
    });
  };

  const currentList = useMemo(() => {
    if (form.reference_type === "SUPPLIER") return suppliers;
    if (form.reference_type === "DRIVER") return drivers;
    if (form.reference_type === "WORKER") return workers;
    return customers;
  }, [form.reference_type, suppliers, customers, drivers, workers]);

  const getName = (row: any) =>
    row.customer_name || row.supplier_name || row.driver_name || row.worker_name || "-";

  const filtered = useMemo(() => {
    return vouchers.filter((v) => {
      const text = `
        ${v.voucher_number || ""}
        ${v.reference_name || ""}
        ${v.reference_type || ""}
        ${v.type_name || ""}
        ${v.payment_method || ""}
        ${v.notes || ""}
      `.toLowerCase();

      const okSearch = text.includes(search.toLowerCase());
      const okType = filterType === "ALL" || String(v.voucher_type_id) === filterType;
      const okRef = filterRef === "ALL" || v.reference_type === filterRef;
      const okPay = filterPay === "ALL" || v.payment_method === filterPay;

      return okSearch && okType && okRef && okPay;
    });
  }, [vouchers, search, filterType, filterRef, filterPay]);

  const totals = useMemo(() => {
    const receipt = filtered
      .filter((v) => v.type_code === "RECEIPT" || Number(v.voucher_type_id) === 1)
      .reduce((s, v) => s + Number(v.amount || 0), 0);

    const payment = filtered
      .filter((v) => v.type_code === "PAYMENT" || Number(v.voucher_type_id) === 2)
      .reduce((s, v) => s + Number(v.amount || 0), 0);

    return {
      receipt,
      payment,
      net: receipt - payment,
      count: filtered.length,
    };
  }, [filtered]);

  const saveVoucher = async () => {
    if (!form.voucher_date) return alert("أدخل تاريخ السند");
    if (!form.reference_id) return alert("اختر الجهة");
    if (!form.amount || Number(form.amount) <= 0) return alert("أدخل المبلغ");

    const payload = {
      ...form,
      amount: Number(form.amount),
    };

    try {
      if (editId) {
        await api.put(`/vouchers/${editId}`, payload);
        alert("تم تعديل السند");
      } else {
        await api.post("/vouchers", payload);
        alert("تم حفظ السند");
      }

      setShowForm(false);
      resetForm();
      loadData();
    } catch (error: any) {
      alert(error?.response?.data?.message || "حدث خطأ");
    }
  };

  const editVoucher = (voucher: any) => {
    setEditId(voucher.id);
    setForm({
      voucher_type_id: String(voucher.voucher_type_id || "1"),
      voucher_number: voucher.voucher_number || "",
      voucher_date: voucher.voucher_date || "",
      reference_type: voucher.reference_type || "CUSTOMER",
      reference_id: String(voucher.reference_id || ""),
      amount: String(voucher.amount || ""),
      payment_method: voucher.payment_method || "CASH",
      notes: voucher.notes || "",
    });
    setShowForm(true);
  };

  const deleteVoucher = async (id: number) => {
    if (!confirm("هل تريد حذف السند؟")) return;
    await api.delete(`/vouchers/${id}`);
    loadData();
  };

  const refLabel = (type: string) => {
    if (type === "SUPPLIER") return "مورد";
    if (type === "DRIVER") return "سائق";
    if (type === "WORKER") return "عامل";
    return "عميل";
  };

  return (
    <section dir="rtl" className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-6 text-white shadow-lg">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-sm text-blue-100">الإدارة المالية</p>
            <h1 className="mt-2 text-3xl font-bold">السندات المالية</h1>
            <p className="mt-2 text-sm text-blue-100">
              سندات قبض وصرف مرتبطة بالعملاء والموردين والسائقين والعمال.
            </p>
          </div>

          <button
            onClick={() => {
              resetForm();
              setShowForm(true);
            }}
            className="rounded-2xl bg-white px-5 py-3 font-bold text-[#0B2A4A]"
          >
            + إضافة سند
          </button>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">عدد السندات</div>
            <div className="mt-1 text-2xl font-bold">{totals.count}</div>
          </div>

          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">إجمالي القبض</div>
            <div className="mt-1 text-2xl font-bold">{totals.receipt.toFixed(3)}</div>
          </div>

          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">إجمالي الصرف</div>
            <div className="mt-1 text-2xl font-bold">{totals.payment.toFixed(3)}</div>
          </div>

          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">الصافي</div>
            <div className="mt-1 text-2xl font-bold">{totals.net.toFixed(3)}</div>
          </div>
        </div>
      </div>

      <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-5">
          <input
            className="rounded-2xl border border-slate-200 bg-slate-50 p-3 outline-none focus:border-[#0B2A4A] md:col-span-2"
            placeholder="بحث بالرقم أو الاسم أو الملاحظات..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <select
            className="rounded-2xl border border-slate-200 bg-slate-50 p-3"
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
          >
            <option value="ALL">كل السندات</option>
            <option value="1">سند قبض</option>
            <option value="2">سند صرف</option>
          </select>

          <select
            className="rounded-2xl border border-slate-200 bg-slate-50 p-3"
            value={filterRef}
            onChange={(e) => setFilterRef(e.target.value)}
          >
            <option value="ALL">كل الجهات</option>
            <option value="CUSTOMER">عميل</option>
            <option value="SUPPLIER">مورد</option>
            <option value="DRIVER">سائق</option>
            <option value="WORKER">عامل</option>
          </select>

          <select
            className="rounded-2xl border border-slate-200 bg-slate-50 p-3"
            value={filterPay}
            onChange={(e) => setFilterPay(e.target.value)}
          >
            <option value="ALL">كل طرق الدفع</option>
            <option value="CASH">نقدًا</option>
            <option value="BANK">تحويل بنكي</option>
          </select>
        </div>
      </div>

      <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-[1150px] w-full text-right">
            <thead className="bg-slate-100 text-slate-700">
              <tr>
                <th className="p-4">رقم السند</th>
                <th className="p-4">النوع</th>
                <th className="p-4">التاريخ</th>
                <th className="p-4">الجهة</th>
                <th className="p-4">الاسم</th>
                <th className="p-4">المبلغ</th>
                <th className="p-4">الدفع</th>
                <th className="p-4">ملاحظات</th>
                <th className="p-4">العمليات</th>
              </tr>
            </thead>

            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={9} className="p-6 text-center">
                    جاري التحميل...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-6 text-center text-slate-500">
                    لا توجد سندات
                  </td>
                </tr>
              ) : (
                filtered.map((voucher) => (
                  <tr key={voucher.id} className="border-t border-slate-100">
                    <td className="p-4 font-bold text-[#0B2A4A]">
                      {voucher.voucher_number || voucher.id}
                    </td>

                    <td className="p-4">
                      {voucher.type_code === "RECEIPT" || Number(voucher.voucher_type_id) === 1 ? (
                        <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">
                          سند قبض
                        </span>
                      ) : (
                        <span className="rounded-full bg-rose-100 px-3 py-1 text-xs font-bold text-rose-700">
                          سند صرف
                        </span>
                      )}
                    </td>

                    <td className="p-4">{voucher.voucher_date}</td>
                    <td className="p-4">{refLabel(voucher.reference_type)}</td>
                    <td className="p-4 font-bold">{voucher.reference_name || "-"}</td>
                    <td className="p-4 font-bold text-[#0B2A4A]">
                      {Number(voucher.amount || 0).toFixed(3)}
                    </td>
                    <td className="p-4">
                      {voucher.payment_method === "BANK" ? "تحويل بنكي" : "نقدًا"}
                    </td>
                    <td className="p-4">{voucher.notes || "-"}</td>

                    <td className="p-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => editVoucher(voucher)}
                          className="rounded-xl bg-blue-100 px-3 py-2 text-sm font-bold text-blue-700"
                        >
                          تعديل
                        </button>

                        <button
                          onClick={() => deleteVoucher(voucher.id)}
                          className="rounded-xl bg-rose-100 px-3 py-2 text-sm font-bold text-rose-700"
                        >
                          حذف
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm">
          <div className="absolute left-0 top-0 h-full w-full overflow-y-auto bg-white p-5 shadow-2xl sm:w-[560px]">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-[#0B2A4A]">
                  {editId ? "تعديل سند" : "إضافة سند"}
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  اترك رقم السند فارغًا ليتم توليده تلقائيًا.
                </p>
              </div>

              <button
                onClick={() => setShowForm(false)}
                className="rounded-xl bg-slate-200 px-4 py-2 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 gap-3">
              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">نوع السند</span>
                <select
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4"
                  value={form.voucher_type_id}
                  onChange={(e) =>
                    setForm({ ...form, voucher_type_id: e.target.value })
                  }
                >
                  <option value="1">سند قبض</option>
                  <option value="2">سند صرف</option>
                </select>
              </label>

              <input
                type="text"
                placeholder="رقم السند - اختياري"
                className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                value={form.voucher_number}
                onChange={(e) =>
                  setForm({ ...form, voucher_number: e.target.value })
                }
              />

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">تاريخ السند</span>
                <input
                  type="date"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4"
                  value={form.voucher_date}
                  onChange={(e) =>
                    setForm({ ...form, voucher_date: e.target.value })
                  }
                />
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">نوع الجهة</span>
                <select
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4"
                  value={form.reference_type}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      reference_type: e.target.value,
                      reference_id: "",
                    })
                  }
                >
                  <option value="CUSTOMER">عميل</option>
                  <option value="SUPPLIER">مورد</option>
                  <option value="DRIVER">سائق</option>
                  <option value="WORKER">عامل</option>
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">الجهة</span>
                <select
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4"
                  value={form.reference_id}
                  onChange={(e) =>
                    setForm({ ...form, reference_id: e.target.value })
                  }
                >
                  <option value="">اختر الجهة</option>
                  {currentList.map((row: any) => (
                    <option key={row.id} value={row.id}>
                      {getName(row)}
                    </option>
                  ))}
                </select>
              </label>

              <input
                type="number"
                placeholder="المبلغ"
                className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
              />

              <select
                className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                value={form.payment_method}
                onChange={(e) =>
                  setForm({ ...form, payment_method: e.target.value })
                }
              >
                <option value="CASH">نقدًا</option>
                <option value="BANK">تحويل بنكي</option>
              </select>

              <textarea
                placeholder="ملاحظات"
                className="min-h-28 rounded-2xl border border-slate-200 bg-slate-50 p-4"
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />

              <button
                onClick={saveVoucher}
                className="rounded-2xl bg-[#0B2A4A] px-5 py-4 font-bold text-white"
              >
                {editId ? "حفظ التعديلات" : "حفظ السند"}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}