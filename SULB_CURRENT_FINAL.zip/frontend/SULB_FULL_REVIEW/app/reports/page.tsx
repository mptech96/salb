"use client";

import { useEffect, useMemo, useState } from "react";
import api from "../api";

const reportTabs = [
  { key: "profit", label: "ربح الأصناف" },
  { key: "car-profit", label: "ربح السيارات" },
  { key: "supplier-balances", label: "أرصدة الموردين" },
  { key: "customer-balances", label: "أرصدة العملاء" },
  { key: "driver-balances", label: "أرصدة السائقين" },
  { key: "expense-summary", label: "ملخص المصروفات" },
];

export default function ReportsPage() {
  const [active, setActive] = useState("car-profit");
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const loadReport = async (key = active) => {
    setLoading(true);
    try {
      const res = await api.get(`/reports/${key}`);
      setRows(res.data.data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReport(active);
  }, [active]);

  const total = useMemo(() => {
    return rows.reduce((sum, r) => {
      return (
        sum +
        Number(
          r.profit ??
            r.balance ??
            r.total_amount ??
            r.sales_total ??
            0
        )
      );
    }, 0);
  }, [rows]);

  const money = (v: any) => Number(v || 0).toFixed(3);

  return (
    <section dir="rtl" className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-6 text-white shadow-lg">
        <p className="text-sm text-blue-100">مركز التقارير</p>
        <h1 className="mt-2 text-3xl font-bold">التقارير والتحليلات</h1>
        <p className="mt-2 text-sm text-blue-100">
          تقارير الأرباح، السيارات، العملاء، الموردين، السائقين والمصروفات.
        </p>

        <div className="mt-5 rounded-2xl bg-white/10 p-4 w-fit">
          <div className="text-sm text-blue-100">إجمالي التقرير الحالي</div>
          <div className="mt-1 text-2xl font-bold">{money(total)}</div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 rounded-3xl border border-slate-200 bg-white p-3 shadow-sm">
        {reportTabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActive(tab.key)}
            className={`rounded-2xl px-4 py-3 text-sm font-bold ${
              active === tab.key
                ? "bg-[#0B2A4A] text-white"
                : "bg-slate-100 text-slate-700"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="rounded-3xl border border-slate-200 bg-white shadow-sm overflow-hidden">
        <div className="border-b border-slate-200 p-4">
          <h2 className="text-xl font-bold text-[#0B2A4A]">
            {reportTabs.find((x) => x.key === active)?.label}
          </h2>
        </div>

        <div className="overflow-x-auto">
          {loading ? (
            <div className="p-8 text-center text-slate-500">جاري التحميل...</div>
          ) : rows.length === 0 ? (
            <div className="p-8 text-center text-slate-500">لا توجد بيانات</div>
          ) : active === "car-profit" ? (
            <table className="min-w-[1000px] w-full text-right">
              <thead className="bg-slate-100">
                <tr>
                  <th className="p-4">السيارة</th>
                  <th className="p-4">المشتريات</th>
                  <th className="p-4">المبيعات</th>
                  <th className="p-4">المصروفات</th>
                  <th className="p-4">المخزون المتبقي</th>
                  <th className="p-4">صافي الربح</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.car_id} className="border-t">
                    <td className="p-4 font-bold">{r.car_number}</td>
                    <td className="p-4">{money(r.purchase_total)}</td>
                    <td className="p-4 text-emerald-700 font-bold">{money(r.sales_total)}</td>
                    <td className="p-4 text-rose-700 font-bold">{money(r.expenses_total)}</td>
                    <td className="p-4">{money(r.stock_qty)}</td>
                    <td className="p-4 font-bold text-[#0B2A4A]">{money(r.profit)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : active === "supplier-balances" ? (
            <table className="min-w-[1000px] w-full text-right">
              <thead className="bg-slate-100">
                <tr>
                  <th className="p-4">المورد</th>
                  <th className="p-4">الجوال</th>
                  <th className="p-4">افتتاحي</th>
                  <th className="p-4">مشتريات</th>
                  <th className="p-4">مدفوع</th>
                  <th className="p-4">الرصيد</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.supplier_id} className="border-t">
                    <td className="p-4 font-bold">{r.supplier_name}</td>
                    <td className="p-4">{r.phone || "-"}</td>
                    <td className="p-4">{money(r.opening_balance)}</td>
                    <td className="p-4">{money(r.purchases)}</td>
                    <td className="p-4">{money(r.payments)}</td>
                    <td className="p-4 font-bold text-[#0B2A4A]">{money(r.balance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : active === "customer-balances" ? (
            <table className="min-w-[1000px] w-full text-right">
              <thead className="bg-slate-100">
                <tr>
                  <th className="p-4">العميل</th>
                  <th className="p-4">الجوال</th>
                  <th className="p-4">افتتاحي</th>
                  <th className="p-4">مبيعات</th>
                  <th className="p-4">مقبوض</th>
                  <th className="p-4">الرصيد</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.customer_id} className="border-t">
                    <td className="p-4 font-bold">{r.customer_name}</td>
                    <td className="p-4">{r.phone || "-"}</td>
                    <td className="p-4">{money(r.opening_balance)}</td>
                    <td className="p-4">{money(r.sales)}</td>
                    <td className="p-4">{money(r.receipts)}</td>
                    <td className="p-4 font-bold text-[#0B2A4A]">{money(r.balance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : active === "driver-balances" ? (
            <table className="min-w-[900px] w-full text-right">
              <thead className="bg-slate-100">
                <tr>
                  <th className="p-4">السائق</th>
                  <th className="p-4">الجوال</th>
                  <th className="p-4">مصروفات/مشاوير</th>
                  <th className="p-4">مدفوع</th>
                  <th className="p-4">الرصيد</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.driver_id} className="border-t">
                    <td className="p-4 font-bold">{r.driver_name}</td>
                    <td className="p-4">{r.phone || "-"}</td>
                    <td className="p-4">{money(r.expenses)}</td>
                    <td className="p-4">{money(r.payments)}</td>
                    <td className="p-4 font-bold text-[#0B2A4A]">{money(r.balance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : active === "expense-summary" ? (
            <table className="min-w-[800px] w-full text-right">
              <thead className="bg-slate-100">
                <tr>
                  <th className="p-4">نوع المصروف</th>
                  <th className="p-4">عدد الحركات</th>
                  <th className="p-4">الإجمالي</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.expense_type_id} className="border-t">
                    <td className="p-4 font-bold">{r.type_name}</td>
                    <td className="p-4">{r.count_expenses}</td>
                    <td className="p-4 font-bold text-rose-700">{money(r.total_amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="min-w-[1000px] w-full text-right">
              <thead className="bg-slate-100">
                <tr>
                  <th className="p-4">الصنف</th>
                  <th className="p-4">السيارة</th>
                  <th className="p-4">الكمية</th>
                  <th className="p-4">المبيعات</th>
                  <th className="p-4">التكلفة</th>
                  <th className="p-4">الربح</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={i} className="border-t">
                    <td className="p-4 font-bold">{r.item_name}</td>
                    <td className="p-4">{r.car_number || "الحوش / عام"}</td>
                    <td className="p-4">{money(r.sold_qty)}</td>
                    <td className="p-4 text-emerald-700 font-bold">{money(r.sales_total)}</td>
                    <td className="p-4 text-rose-700 font-bold">{money(r.cost_total)}</td>
                    <td className="p-4 font-bold text-[#0B2A4A]">{money(r.profit)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </section>
  );
}