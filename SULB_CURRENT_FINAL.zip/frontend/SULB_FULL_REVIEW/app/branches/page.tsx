"use client";

import { useEffect, useMemo, useState } from "react";
import SystemDialog from "../../components/common/SystemDialog";
import api from "../api";

type StoredUser = {
  id?: number | string | null;
  company_id?: number | string | null;
  branch_id?: number | string | null;
  company_name?: string | null;
  branch_name?: string | null;
  role_code?: string | null;
  role?: {
    role_code?: string | null;
    role_name?: string | null;
  } | null;
  company?: {
    company_name?: string | null;
  } | null;
  branch?: {
    branch_name?: string | null;
  } | null;
};

type Company = {
  id: number | string;
  company_name: string;
};

type Branch = {
  id: number;
  company_id: number | null;
  company_name: string | null;
  branch_code: string | null;
  branch_name: string;
  phone: string | null;
  city: string | null;
  address: string | null;
  is_active: number;
  cost_center_id?: number | null;
  cost_center_code?: string | null;
  cost_center_name?: string | null;
  users_count?: number | string | null;
};

type BranchForm = {
  company_id: string;
  branch_code: string;
  branch_name: string;
  phone: string;
  city: string;
  address: string;
  is_active: number;
};

type DialogType = "success" | "error" | "warning" | "info" | "confirm";

type DialogState = {
  open: boolean;
  type: DialogType;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  showCancel?: boolean;
  onConfirm?: () => void | Promise<void>;
};

const SUPER_ADMIN_ROLE = "SUPER_ADMIN";
const COMPANY_MANAGER_ROLES = ["COMPANY_MANAGER", "COMPANY_ADMIN", "MANAGER"];
const BRANCH_MANAGER_ROLE = "BRANCH_MANAGER";

const closedDialog: DialogState = {
  open: false,
  type: "info",
  title: "",
  message: "",
};

function getCurrentUser(): StoredUser {
  if (typeof window === "undefined") return {};

  try {
    const value = localStorage.getItem("scrap_user");
    return value ? JSON.parse(value) : {};
  } catch {
    return {};
  }
}

function roleCodeOf(user: StoredUser): string {
  return String(user?.role?.role_code || user?.role_code || "")
    .trim()
    .toUpperCase();
}

function getRequestConfig() {
  const user = getCurrentUser();
  const roleCode = roleCodeOf(user);
  const headers: Record<string, string> = {};

  if (user?.company_id !== null && user?.company_id !== undefined) {
    headers["X-Company-ID"] = String(user.company_id);
  }

  if (user?.branch_id !== null && user?.branch_id !== undefined) {
    headers["X-Branch-ID"] = String(user.branch_id);
  }

  if (user?.id !== null && user?.id !== undefined) {
    headers["X-User-ID"] = String(user.id);
  }

  if (roleCode) {
    headers["X-Role-Code"] = roleCode;
  }

  return { headers };
}

function extractApiMessage(error: any): string {
  const errors = error?.response?.data?.errors;

  if (errors && typeof errors === "object") {
    const firstValue = Object.values(errors)[0];

    if (Array.isArray(firstValue) && firstValue.length > 0) {
      return String(firstValue[0]);
    }

    if (typeof firstValue === "string") {
      return firstValue;
    }
  }

  return (
    error?.response?.data?.message ||
    error?.message ||
    "تعذر إكمال العملية. حاول مرة أخرى."
  );
}

function validateForm(form: BranchForm): string | null {
  if (!form.company_id) {
    return "اختر الشركة التي يتبع لها الفرع.";
  }

  const branchName = form.branch_name.trim();

  if (!branchName) {
    return "اسم الفرع مطلوب.";
  }

  if (branchName.length < 2) {
    return "اسم الفرع يجب ألا يقل عن حرفين.";
  }

  if (!/^[\p{L}\p{N}\s.'()_-]+$/u.test(branchName)) {
    return "اسم الفرع يحتوي على رموز غير مسموحة.";
  }

  const branchCode = form.branch_code.trim();

  if (branchCode && !/^[A-Za-z0-9_-]{2,50}$/.test(branchCode)) {
    return "كود الفرع يقبل الحروف الإنجليزية والأرقام والشرطة فقط، من خانتين إلى 50 خانة.";
  }

  const phone = form.phone.trim();

  if (phone && !/^[0-9]{7,15}$/.test(phone)) {
    return "رقم الجوال يجب أن يحتوي على أرقام فقط، من 7 إلى 15 رقمًا.";
  }

  const city = form.city.trim();

  if (city && !/^[\p{L}\s.'()-]{2,100}$/u.test(city)) {
    return "اسم المدينة يجب أن يحتوي على حروف ومسافات فقط.";
  }

  if (form.address.trim().length > 1000) {
    return "العنوان لا يمكن أن يتجاوز 1000 حرف.";
  }

  return null;
}

export default function BranchesPage() {
  const [currentUser, setCurrentUser] = useState<StoredUser>({});
  const [branches, setBranches] = useState<Branch[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [dialogLoading, setDialogLoading] = useState(false);

  const [search, setSearch] = useState("");
  const [companyFilter, setCompanyFilter] = useState("ALL");

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [dialog, setDialog] = useState<DialogState>(closedDialog);

  const currentRoleCode = roleCodeOf(currentUser);
  const isSuper = currentRoleCode === SUPER_ADMIN_ROLE;
  const isCompanyManager = COMPANY_MANAGER_ROLES.includes(currentRoleCode);
  const isBranchManager = currentRoleCode === BRANCH_MANAGER_ROLE;
  const canViewBranches = isSuper || isCompanyManager || isBranchManager;
  const canManageBranches = isSuper || isCompanyManager;

  const currentCompanyId =
    currentUser?.company_id !== null && currentUser?.company_id !== undefined
      ? String(currentUser.company_id)
      : "";

  const currentCompanyName =
    currentUser?.company_name ||
    currentUser?.company?.company_name ||
    companies.find((company) => String(company.id) === currentCompanyId)
      ?.company_name ||
    branches.find((branch) => String(branch.company_id) === currentCompanyId)
      ?.company_name ||
    "الشركة الحالية";

  const emptyForm = (): BranchForm => ({
    company_id: isSuper ? "" : currentCompanyId,
    branch_code: "",
    branch_name: "",
    phone: "",
    city: "",
    address: "",
    is_active: 1,
  });

  const [form, setForm] = useState<BranchForm>({
    company_id: "",
    branch_code: "",
    branch_name: "",
    phone: "",
    city: "",
    address: "",
    is_active: 1,
  });

  const activeCount = useMemo(
    () => branches.filter((branch) => Number(branch.is_active) === 1).length,
    [branches],
  );

  const filteredBranches = useMemo(() => {
    const normalizedSearch = search.trim().toLowerCase();

    return branches.filter((branch) => {
      const text = [
        branch.company_name,
        branch.branch_code,
        branch.branch_name,
        branch.phone,
        branch.city,
        branch.address,
        branch.cost_center_code,
        branch.cost_center_name,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      const matchesSearch =
        !normalizedSearch || text.includes(normalizedSearch);

      const matchesCompany =
        !isSuper ||
        companyFilter === "ALL" ||
        String(branch.company_id) === companyFilter;

      return matchesSearch && matchesCompany;
    });
  }, [branches, companyFilter, isSuper, search]);

  const closeDialog = () => {
    if (!dialogLoading) {
      setDialog(closedDialog);
    }
  };

  const showMessage = (
    type: Exclude<DialogType, "confirm">,
    title: string,
    message: string,
  ) => {
    setDialog({
      open: true,
      type,
      title,
      message,
      confirmText: "حسنًا",
      showCancel: false,
      onConfirm: () => setDialog(closedDialog),
    });
  };

  const loadData = async (showErrors = true) => {
    setLoading(true);

    try {
      const storedUser = getCurrentUser();
      const storedRoleCode = roleCodeOf(storedUser);
      const superAdmin = storedRoleCode === SUPER_ADMIN_ROLE;
      const companyManager = COMPANY_MANAGER_ROLES.includes(storedRoleCode);
      const branchManager = storedRoleCode === BRANCH_MANAGER_ROLE;

      setCurrentUser(storedUser);

      if (!superAdmin && !companyManager && !branchManager) {
        setBranches([]);
        setCompanies([]);

        if (showErrors) {
          showMessage(
            "warning",
            "صلاحية غير متاحة",
            "لا تملك صلاحية عرض شاشة الفروع.",
          );
        }

        return;
      }

      const config = getRequestConfig();
      const branchesResponse = await api.get("/branches", config);
      const loadedBranches: Branch[] = branchesResponse.data.data || [];

      setBranches(loadedBranches);

      if (superAdmin) {
        const companiesResponse = await api.get("/companies", config);
        setCompanies(companiesResponse.data.data || []);
      } else {
        const companyId = storedUser.company_id;
        const companyName =
          storedUser.company_name ||
          storedUser.company?.company_name ||
          loadedBranches[0]?.company_name ||
          "الشركة الحالية";

        setCompanies(
          companyId !== null && companyId !== undefined
            ? [{ id: companyId, company_name: companyName }]
            : [],
        );

        setCompanyFilter(
          companyId !== null && companyId !== undefined
            ? String(companyId)
            : "ALL",
        );
      }
    } catch (error: any) {
      setBranches([]);

      if (showErrors) {
        showMessage(
          "error",
          "تعذر تحميل الفروع",
          extractApiMessage(error),
        );
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadData();
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setForm(emptyForm());
  };

  const openAddForm = () => {
    if (!canManageBranches) {
      showMessage(
        "warning",
        "غير مسموح",
        "لا تملك صلاحية إضافة فروع جديدة.",
      );
      return;
    }

    resetForm();
    setShowForm(true);
  };

  const openEditForm = (branch: Branch) => {
    if (!canManageBranches) {
      showMessage(
        "warning",
        "غير مسموح",
        "لا تملك صلاحية تعديل الفروع.",
      );
      return;
    }

    setEditingId(branch.id);
    setForm({
      company_id: String(branch.company_id || ""),
      branch_code: branch.branch_code || "",
      branch_name: branch.branch_name || "",
      phone: branch.phone || "",
      city: branch.city || "",
      address: branch.address || "",
      is_active: Number(branch.is_active) === 1 ? 1 : 0,
    });
    setShowForm(true);
  };

  const saveBranch = async () => {
    const validationMessage = validateForm(form);

    if (validationMessage) {
      showMessage("warning", "تحقق من البيانات", validationMessage);
      return;
    }

    if (!canManageBranches) {
      showMessage(
        "error",
        "غير مسموح",
        "لا تملك صلاحية حفظ بيانات الفروع.",
      );
      return;
    }

    setSaving(true);

    try {
      const payload = {
        company_id: Number(form.company_id),
        branch_code: form.branch_code.trim()
          ? form.branch_code.trim().toUpperCase()
          : null,
        branch_name: form.branch_name.trim(),
        phone: form.phone.trim() || null,
        city: form.city.trim() || null,
        address: form.address.trim() || null,
        is_active: Number(form.is_active),
      };

      const response = editingId
        ? await api.put(
            `/branches/${editingId}`,
            payload,
            getRequestConfig(),
          )
        : await api.post("/branches", payload, getRequestConfig());

      setShowForm(false);
      resetForm();
      await loadData(false);

      showMessage(
        "success",
        editingId ? "تم تحديث الفرع" : "تم إنشاء الفرع",
        response?.data?.message ||
          (editingId
            ? "تم تحديث الفرع ومركز التكلفة بنجاح."
            : "تم إنشاء الفرع ومركز التكلفة بنجاح."),
      );
    } catch (error: any) {
      showMessage(
        "error",
        editingId ? "تعذر تحديث الفرع" : "تعذر إنشاء الفرع",
        extractApiMessage(error),
      );
    } finally {
      setSaving(false);
    }
  };

  const requestDeleteBranch = (branch: Branch) => {
    if (!canManageBranches) {
      showMessage(
        "warning",
        "غير مسموح",
        "لا تملك صلاحية حذف الفروع.",
      );
      return;
    }

    setDialog({
      open: true,
      type: "confirm",
      title: "تأكيد حذف الفرع",
      message:
        `هل تريد حذف فرع «${branch.branch_name}»؟\n` +
        "لن يسمح النظام بالحذف إذا كان الفرع مرتبطًا بمستخدمين أو حركات تشغيلية أو قيود محاسبية.",
      confirmText: "نعم، احذف الفرع",
      cancelText: "إلغاء",
      showCancel: true,
      onConfirm: async () => {
        setDialogLoading(true);

        try {
          const response = await api.delete(
            `/branches/${branch.id}`,
            getRequestConfig(),
          );

          setDialog(closedDialog);
          await loadData(false);

          showMessage(
            "success",
            "تم حذف الفرع",
            response?.data?.message ||
              "تم حذف الفرع ومركز التكلفة بنجاح.",
          );
        } catch (error: any) {
          setDialog({
            open: true,
            type: "error",
            title: "تعذر حذف الفرع",
            message: extractApiMessage(error),
            confirmText: "حسنًا",
            showCancel: false,
            onConfirm: () => setDialog(closedDialog),
          });
        } finally {
          setDialogLoading(false);
        }
      },
    });
  };

  return (
    <section dir="rtl" className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-5 text-white shadow-lg sm:p-7">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm text-blue-100">إدارة الفروع</p>
            <h1 className="mt-2 text-2xl font-bold sm:text-4xl">
              الفروع ومراكز التكلفة
            </h1>
            <p className="mt-2 text-sm text-blue-100">
              إدارة فروع الشركة والتحقق من إنشاء مركز تكلفة مستقل لكل فرع.
            </p>
          </div>

          {canManageBranches && (
            <button
              type="button"
              onClick={openAddForm}
              className="rounded-2xl bg-white px-5 py-3 font-bold text-[#0B2A4A] shadow"
            >
              + إضافة فرع
            </button>
          )}
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 sm:max-w-md">
          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">إجمالي الفروع</div>
            <div className="mt-1 text-3xl font-bold">{branches.length}</div>
          </div>

          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">الفروع النشطة</div>
            <div className="mt-1 text-3xl font-bold">{activeCount}</div>
          </div>
        </div>
      </div>

      {!canViewBranches && !loading && (
        <div className="rounded-3xl border border-amber-200 bg-amber-50 p-6 text-center font-bold text-amber-800">
          لا تملك صلاحية عرض شاشة الفروع.
        </div>
      )}

      {canViewBranches && (
        <>
          <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
            <div
              className={`grid grid-cols-1 gap-3 ${
                isSuper ? "md:grid-cols-3" : ""
              }`}
            >
              <input
                className={`rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A] ${
                  isSuper ? "md:col-span-2" : ""
                }`}
                placeholder="بحث باسم الفرع، الكود، المدينة أو مركز التكلفة..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />

              {isSuper && (
                <select
                  className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={companyFilter}
                  onChange={(event) => setCompanyFilter(event.target.value)}
                >
                  <option value="ALL">كل الشركات</option>
                  {companies.map((company) => (
                    <option key={company.id} value={company.id}>
                      {company.company_name}
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>

          <div className="rounded-3xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-200 p-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900">
                  قائمة الفروع
                </h2>
                {!isSuper && (
                  <p className="mt-1 text-sm text-slate-500">
                    {currentCompanyName}
                  </p>
                )}
              </div>

              <span className="text-sm text-slate-500">
                {loading
                  ? "جاري التحميل..."
                  : `${filteredBranches.length} فرع`}
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-[1300px] w-full text-right">
                <thead className="bg-slate-100 text-slate-600">
                  <tr>
                    <th className="p-4">الشركة</th>
                    <th className="p-4">الكود</th>
                    <th className="p-4">اسم الفرع</th>
                    <th className="p-4">مركز التكلفة</th>
                    <th className="p-4">المستخدمون</th>
                    <th className="p-4">الجوال</th>
                    <th className="p-4">المدينة</th>
                    <th className="p-4">الحالة</th>
                    {canManageBranches && (
                      <th className="p-4">الإجراءات</th>
                    )}
                  </tr>
                </thead>

                <tbody>
                  {loading ? (
                    <tr>
                      <td
                        className="p-8 text-center text-slate-500"
                        colSpan={canManageBranches ? 9 : 8}
                      >
                        جاري تحميل الفروع...
                      </td>
                    </tr>
                  ) : filteredBranches.length === 0 ? (
                    <tr>
                      <td
                        className="p-8 text-center text-slate-500"
                        colSpan={canManageBranches ? 9 : 8}
                      >
                        لا توجد فروع مطابقة.
                      </td>
                    </tr>
                  ) : (
                    filteredBranches.map((branch) => (
                      <tr
                        key={branch.id}
                        className="border-t border-slate-100 hover:bg-slate-50"
                      >
                        <td className="p-4 font-bold text-slate-700">
                          {branch.company_name || "غير مرتبط"}
                        </td>
                        <td className="p-4">{branch.branch_code || "-"}</td>
                        <td className="p-4 font-bold text-[#0B2A4A]">
                          {branch.branch_name}
                        </td>
                        <td className="p-4">
                          {branch.cost_center_name ? (
                            <div>
                              <div className="font-bold text-emerald-700">
                                {branch.cost_center_name}
                              </div>
                              <div className="mt-1 text-xs text-slate-500">
                                {branch.cost_center_code || "-"}
                              </div>
                            </div>
                          ) : (
                            <span className="rounded-full bg-rose-100 px-3 py-1 text-xs font-bold text-rose-700">
                              غير منشأ
                            </span>
                          )}
                        </td>
                        <td className="p-4">
                          {Number(branch.users_count || 0)}
                        </td>
                        <td className="p-4">{branch.phone || "-"}</td>
                        <td className="p-4">{branch.city || "-"}</td>
                        <td className="p-4">
                          <span
                            className={`rounded-full px-3 py-1 text-xs font-bold ${
                              Number(branch.is_active) === 1
                                ? "bg-emerald-100 text-emerald-700"
                                : "bg-slate-200 text-slate-600"
                            }`}
                          >
                            {Number(branch.is_active) === 1
                              ? "نشط"
                              : "غير نشط"}
                          </span>
                        </td>

                        {canManageBranches && (
                          <td className="p-4">
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => openEditForm(branch)}
                                className="rounded-xl bg-blue-700 px-4 py-2 text-sm font-bold text-white"
                              >
                                تعديل
                              </button>

                              <button
                                type="button"
                                onClick={() => requestDeleteBranch(branch)}
                                className="rounded-xl bg-rose-600 px-4 py-2 text-sm font-bold text-white"
                              >
                                حذف
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {showForm && canManageBranches && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm">
          <div className="absolute left-0 top-0 h-full w-full overflow-y-auto bg-white p-5 shadow-2xl sm:w-[540px]">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-[#0B2A4A]">
                  {editingId ? "تعديل فرع" : "إضافة فرع"}
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  سيُنشأ مركز تكلفة للفرع تلقائيًا عند الحفظ.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  if (!saving) {
                    setShowForm(false);
                    resetForm();
                  }
                }}
                className="rounded-xl bg-slate-200 px-4 py-2 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {isSuper ? (
                <label className="space-y-2">
                  <span className="text-sm font-bold text-slate-700">
                    الشركة <span className="text-rose-600">*</span>
                  </span>
                  <select
                    className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                    value={form.company_id}
                    onChange={(event) =>
                      setForm({
                        ...form,
                        company_id: event.target.value,
                      })
                    }
                  >
                    <option value="">اختر الشركة</option>
                    {companies.map((company) => (
                      <option key={company.id} value={company.id}>
                        {company.company_name}
                      </option>
                    ))}
                  </select>
                </label>
              ) : (
                <div className="rounded-2xl border border-blue-100 bg-blue-50 p-4">
                  <div className="text-xs font-bold text-blue-600">
                    الشركة
                  </div>
                  <div className="mt-1 font-black text-[#0B2A4A]">
                    {currentCompanyName}
                  </div>
                </div>
              )}

              <label className="space-y-2">
                <span className="text-sm font-bold text-slate-700">
                  كود الفرع
                </span>
                <input
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 uppercase outline-none focus:border-[#0B2A4A]"
                  placeholder="مثال: HOD-001"
                  value={form.branch_code}
                  maxLength={50}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      branch_code: event.target.value
                        .toUpperCase()
                        .replace(/[^A-Z0-9_-]/g, ""),
                    })
                  }
                />
                <p className="text-xs text-slate-500">
                  يمكن تكرار الكود في شركة أخرى، ولا يمكن تكراره داخل الشركة
                  نفسها.
                </p>
              </label>

              <label className="space-y-2">
                <span className="text-sm font-bold text-slate-700">
                  اسم الفرع <span className="text-rose-600">*</span>
                </span>
                <input
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  placeholder="مثال: فرع الحديدة"
                  value={form.branch_name}
                  maxLength={255}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      branch_name: event.target.value,
                    })
                  }
                />
              </label>

              <label className="space-y-2">
                <span className="text-sm font-bold text-slate-700">
                  رقم الجوال
                </span>
                <input
                  type="tel"
                  inputMode="numeric"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  placeholder="أرقام فقط"
                  value={form.phone}
                  maxLength={15}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      phone: event.target.value.replace(/\D/g, ""),
                    })
                  }
                />
              </label>

              <label className="space-y-2">
                <span className="text-sm font-bold text-slate-700">
                  المدينة
                </span>
                <input
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  placeholder="مثال: الحديدة"
                  value={form.city}
                  maxLength={100}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      city: event.target.value,
                    })
                  }
                />
              </label>

              <label className="space-y-2">
                <span className="text-sm font-bold text-slate-700">
                  العنوان
                </span>
                <textarea
                  className="min-h-28 w-full resize-y rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  placeholder="اكتب عنوان الفرع"
                  value={form.address}
                  maxLength={1000}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      address: event.target.value,
                    })
                  }
                />
              </label>

              <label className="space-y-2">
                <span className="text-sm font-bold text-slate-700">
                  حالة الفرع
                </span>
                <select
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={form.is_active}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      is_active: Number(event.target.value),
                    })
                  }
                >
                  <option value={1}>نشط</option>
                  <option value={0}>غير نشط</option>
                </select>
              </label>

              <button
                type="button"
                onClick={() => void saveBranch()}
                disabled={saving}
                className="mt-2 rounded-2xl bg-[#0B2A4A] px-5 py-4 font-bold text-white disabled:cursor-not-allowed disabled:opacity-60"
              >
                {saving
                  ? "جاري الحفظ..."
                  : editingId
                    ? "حفظ التعديلات"
                    : "إنشاء الفرع"}
              </button>

              <button
                type="button"
                onClick={() => {
                  if (!saving) {
                    setShowForm(false);
                    resetForm();
                  }
                }}
                disabled={saving}
                className="rounded-2xl bg-slate-200 px-5 py-4 font-bold text-slate-700 disabled:opacity-60"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      <SystemDialog
        open={dialog.open}
        type={dialog.type}
        title={dialog.title}
        message={dialog.message}
        confirmText={dialog.confirmText}
        cancelText={dialog.cancelText}
        showCancel={dialog.showCancel}
        loading={dialogLoading}
        onClose={closeDialog}
        onConfirm={async () => {
          if (dialog.onConfirm) {
            await dialog.onConfirm();
          } else {
            closeDialog();
          }
        }}
      />
    </section>
  );
}