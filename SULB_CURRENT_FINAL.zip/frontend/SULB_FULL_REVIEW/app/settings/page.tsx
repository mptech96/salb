"use client";

import { useEffect, useRef, useState } from "react";
import api from "../api";

export default function SettingsPage() {
  const invoiceEditorRef = useRef<HTMLDivElement>(null);
  const reportEditorRef = useRef<HTMLDivElement>(null);

  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState<any>({
    print_company_name: "",
    print_phone: "",
    print_email: "",
    print_city: "",
    print_address: "",
    tax_number: "",
    commercial_register: "",
    currency_name: "ريال",
    currency_code: "SAR",
    invoice_footer: "",
    report_footer: "",
    primary_color: "#0B2A4A",
    secondary_color: "#123D68",
    logo_path: "",
    signature_path: "",
    stamp_path: "",
  });

  const fileUrl = (path?: string) => {
    if (!path) return "";
    return `http://127.0.0.1:8000/storage/${path}`;
  };

  const loadSettings = async () => {
    const res = await api.get("/company-settings");
    const data = res.data.data || {};
    setSettings(data);

    setTimeout(() => {
      if (invoiceEditorRef.current) {
        invoiceEditorRef.current.innerHTML = data.invoice_footer || "";
      }
      if (reportEditorRef.current) {
        reportEditorRef.current.innerHTML = data.report_footer || "";
      }
    }, 100);
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const exec = (cmd: string, value?: string) => {
    document.execCommand(cmd, false, value);
  };

  const saveSettings = async () => {
    setLoading(true);

    try {
      await api.post("/company-settings", {
        ...settings,
        invoice_footer: invoiceEditorRef.current?.innerHTML || "",
        report_footer: reportEditorRef.current?.innerHTML || "",
      });

      alert("تم حفظ إعدادات المكتب بنجاح");
      loadSettings();
    } catch (e: any) {
      alert(e?.response?.data?.message || "حدث خطأ أثناء الحفظ");
    } finally {
      setLoading(false);
    }
  };

  const uploadFile = async (type: "logo" | "signature" | "stamp", file: File) => {
    const formData = new FormData();
    formData.append("type", type);
    formData.append("file", file);

    await api.post("/company-settings/upload", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });

    alert("تم رفع الملف بنجاح");
    loadSettings();
  };

  const printPreview = () => {
    const html = `
      <html dir="rtl" lang="ar">
      <head>
        <title>معاينة ورقة رسمية</title>
        <style>
          body { font-family: Arial; padding: 40px; color: #111827; }
          .paper { max-width: 850px; margin: auto; border: 1px solid #ddd; padding: 30px; min-height: 1100px; position: relative; }
          .header { display:flex; justify-content:space-between; align-items:center; border-bottom:3px solid ${settings.primary_color || "#0B2A4A"}; padding-bottom:20px; }
          .logo { max-height:90px; max-width:160px; }
          .company h1 { margin:0; color:${settings.primary_color || "#0B2A4A"}; }
          .content { padding: 45px 0; line-height: 2; font-size: 17px; min-height: 650px; }
          .footer { border-top:2px solid #ddd; padding-top:15px; position:absolute; bottom:30px; left:30px; right:30px; font-size:14px; color:#555; }
          .sign-area { display:flex; gap:40px; justify-content:flex-end; margin-top:50px; }
          .sign-area img { max-height:90px; }
          .stamp { opacity:.85; }
        </style>
      </head>
      <body>
        <div class="paper">
          <div class="header">
            <div class="company">
              <h1>${settings.print_company_name || "اسم المكتب"}</h1>
              <div>${settings.print_address || ""}</div>
              <div>${settings.print_phone || ""} - ${settings.print_email || ""}</div>
              <div>السجل: ${settings.commercial_register || "-"} | الضريبي: ${settings.tax_number || "-"}</div>
            </div>
            ${settings.logo_path ? `<img class="logo" src="${fileUrl(settings.logo_path)}" />` : ""}
          </div>

          <div class="content">
            <h2 style="text-align:center;">ورقة رسمية / ورقة طريق</h2>
            <p>هذا نموذج معاينة للترويسة والتذييل والختم والتوقيع الإلكتروني.</p>
            <p>يمكن لاحقًا ربط هذا القالب بفواتير البيع والشراء والسندات وورقة الطريق.</p>

            <div class="sign-area">
              ${settings.signature_path ? `<img src="${fileUrl(settings.signature_path)}" />` : ""}
              ${settings.stamp_path ? `<img class="stamp" src="${fileUrl(settings.stamp_path)}" />` : ""}
            </div>
          </div>

          <div class="footer">
            ${settings.report_footer || settings.invoice_footer || ""}
          </div>
        </div>
      </body>
      </html>
    `;

    const win = window.open("", "_blank");
    if (!win) return;
    win.document.write(html);
    win.document.close();
  };

  return (
    <section dir="rtl" className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-6 text-white shadow-lg">
        <p className="text-sm text-blue-100">إعدادات المكتب والطباعة</p>
        <h1 className="mt-2 text-3xl font-black">إعدادات المكتب</h1>
        <p className="mt-2 text-sm text-blue-100">
          الشعار، الختم، التوقيع، الترويسة، التذييل، وبيانات الأوراق الرسمية.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {[
          ["logo", "شعار المكتب", settings.logo_path],
          ["signature", "توقيع إلكتروني", settings.signature_path],
          ["stamp", "ختم إلكتروني", settings.stamp_path],
        ].map(([type, title, path]: any) => (
          <div key={type} className="rounded-3xl border bg-white p-5 shadow-sm">
            <h2 className="mb-3 text-lg font-black text-[#0B2A4A]">{title}</h2>

            <div className="mb-4 flex h-36 items-center justify-center rounded-2xl bg-slate-100">
              {path ? (
                <img src={fileUrl(path)} className="max-h-32 max-w-full object-contain" />
              ) : (
                <span className="text-slate-400">لا يوجد ملف</span>
              )}
            </div>

            <input
              type="file"
              accept="image/*"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) uploadFile(type, file);
              }}
              className="w-full rounded-xl border p-3"
            />
          </div>
        ))}
      </div>

      <div className="rounded-3xl border bg-white p-5 shadow-sm">
        <h2 className="mb-4 text-xl font-black text-[#0B2A4A]">بيانات الورقة الرسمية</h2>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          {[
            ["print_company_name", "اسم المكتب في الطباعة"],
            ["print_phone", "رقم الجوال"],
            ["print_email", "البريد الإلكتروني"],
            ["print_city", "المدينة"],
            ["tax_number", "الرقم الضريبي"],
            ["commercial_register", "السجل التجاري"],
            ["currency_name", "اسم العملة"],
            ["currency_code", "رمز العملة"],
            ["primary_color", "اللون الأساسي"],
            ["secondary_color", "اللون الثانوي"],
          ].map(([key, label]) => (
            <input
              key={key}
              type={key.includes("color") ? "color" : "text"}
              className="rounded-2xl border bg-slate-50 p-4"
              placeholder={label}
              value={settings[key] || ""}
              onChange={(e) => setSettings({ ...settings, [key]: e.target.value })}
            />
          ))}

          <textarea
            className="md:col-span-2 xl:col-span-3 rounded-2xl border bg-slate-50 p-4"
            placeholder="العنوان"
            value={settings.print_address || ""}
            onChange={(e) => setSettings({ ...settings, print_address: e.target.value })}
          />
        </div>
      </div>

      <EditorBlock
        title="تذييل الفاتورة"
        editorRef={invoiceEditorRef}
        exec={exec}
      />

      <EditorBlock
        title="تذييل التقارير والأوراق الرسمية"
        editorRef={reportEditorRef}
        exec={exec}
      />

      <div className="flex flex-wrap gap-3">
        <button
          onClick={saveSettings}
          disabled={loading}
          className="rounded-2xl bg-[#0B2A4A] px-8 py-4 font-bold text-white disabled:opacity-60"
        >
          {loading ? "جاري الحفظ..." : "حفظ الإعدادات"}
        </button>

        <button
          onClick={printPreview}
          className="rounded-2xl bg-emerald-600 px-8 py-4 font-bold text-white"
        >
          معاينة ورقة رسمية
        </button>
      </div>
    </section>
  );
}

function EditorBlock({ title, editorRef, exec }: any) {
  return (
    <div className="rounded-3xl border bg-white p-5 shadow-sm">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl font-black text-[#0B2A4A]">{title}</h2>

        <div className="flex flex-wrap gap-2">
          <button onClick={() => exec("bold")} className="rounded-lg bg-slate-100 px-3 py-2 font-bold">B</button>
          <button onClick={() => exec("italic")} className="rounded-lg bg-slate-100 px-3 py-2 italic">I</button>
          <button onClick={() => exec("underline")} className="rounded-lg bg-slate-100 px-3 py-2 underline">U</button>
          <button onClick={() => exec("justifyRight")} className="rounded-lg bg-slate-100 px-3 py-2">يمين</button>
          <button onClick={() => exec("justifyCenter")} className="rounded-lg bg-slate-100 px-3 py-2">وسط</button>
          <button onClick={() => exec("insertUnorderedList")} className="rounded-lg bg-slate-100 px-3 py-2">قائمة</button>
          <button onClick={() => exec("fontSize", "5")} className="rounded-lg bg-slate-100 px-3 py-2">تكبير</button>
        </div>
      </div>

      <div
        ref={editorRef}
        contentEditable
        suppressContentEditableWarning
        className="min-h-52 rounded-2xl border bg-slate-50 p-5 leading-8 outline-none focus:ring-2 focus:ring-[#0B2A4A]"
      />
    </div>
  );
}