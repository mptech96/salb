"use client";

import { useEffect, useMemo, useState } from "react";
import api from "../api";

type Car = {
  id: number;
  car_number: string | null;
  plate_number: string | null;
  weight_card_number: string | null;
  gross_weight: string | number;
  deduction_weight: string | number;
  net_weight: string | number;
  transport_cost: string | number;
  extra_cost: string | number;
  car_status: string;
  arrival_date: string | null;
  notes: string | null;
};

export default function CarsPage() {
  const [cars, setCars] = useState<Car[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const [form, setForm] = useState({
    car_number: "",
    plate_number: "",
    weight_card_number: "",
    gross_weight: "",
    deduction_weight: "",
    transport_cost: "",
    extra_cost: "",
    car_status: "OPEN",
    arrival_date: "",
    notes: "",
  });

  const openCount = useMemo(
    () => cars.filter((x) => x.car_status === "OPEN").length,
    [cars]
  );

  const netWeight =
    Number(form.gross_weight || 0) - Number(form.deduction_weight || 0);

  const loadCars = async () => {
    setLoading(true);
    try {
      const res = await api.get("/cars");
      setCars(res.data.data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCars();
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setForm({
      car_number: "",
      plate_number: "",
      weight_card_number: "",
      gross_weight: "",
      deduction_weight: "",
      transport_cost: "",
      extra_cost: "",
      car_status: "OPEN",
      arrival_date: "",
      notes: "",
    });
  };

  const openAddForm = () => {
    resetForm();
    setShowForm(true);
  };

  const openEditForm = (car: Car) => {
    setEditingId(car.id);
    setForm({
      car_number: car.car_number || "",
      plate_number: car.plate_number || "",
      weight_card_number: car.weight_card_number || "",
      gross_weight: String(car.gross_weight || ""),
      deduction_weight: String(car.deduction_weight || ""),
      transport_cost: String(car.transport_cost || ""),
      extra_cost: String(car.extra_cost || ""),
      car_status: car.car_status || "OPEN",
      arrival_date: car.arrival_date ? car.arrival_date.slice(0, 10) : "",
      notes: car.notes || "",
    });
    setShowForm(true);
  };

  const saveCar = async () => {
    setSaving(true);

    try {
      const payload = {
        ...form,
        gross_weight: Number(form.gross_weight || 0),
        deduction_weight: Number(form.deduction_weight || 0),
        net_weight: netWeight,
        transport_cost: Number(form.transport_cost || 0),
        extra_cost: Number(form.extra_cost || 0),
        arrival_date: form.arrival_date || null,
      };

      if (editingId) {
        await api.put(`/cars/${editingId}`, payload);
        alert("تم تحديث السيارة");
      } else {
        await api.post("/cars", payload);
        alert("تم إضافة السيارة");
      }

      setShowForm(false);
      resetForm();
      loadCars();
    } finally {
      setSaving(false);
    }
  };

  const deleteCar = async (id: number) => {
    if (!confirm("هل تريد حذف هذه السيارة؟")) return;
    await api.delete(`/cars/${id}`);
    alert("تم حذف السيارة");
    loadCars();
  };

  return (
    <section dir="rtl" className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-5 text-white shadow-lg sm:p-7">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm text-blue-100">إدارة السيارات</p>
            <h1 className="mt-2 text-2xl font-bold sm:text-4xl">
              سيارات السكراب والوزن
            </h1>
          </div>

          <button
            onClick={openAddForm}
            className="rounded-2xl bg-white px-5 py-3 font-bold text-[#0B2A4A] shadow"
          >
            + إضافة سيارة
          </button>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 sm:max-w-md">
          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">إجمالي السيارات</div>
            <div className="mt-1 text-3xl font-bold">{cars.length}</div>
          </div>
          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">المفتوحة</div>
            <div className="mt-1 text-3xl font-bold">{openCount}</div>
          </div>
        </div>
      </div>

      <div className="rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-200 p-4">
          <h2 className="text-xl font-bold text-slate-900">قائمة السيارات</h2>
          <span className="text-sm text-slate-500">
            {loading ? "جاري التحميل..." : `${cars.length} سيارة`}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-[1050px] w-full text-right">
            <thead className="bg-slate-100 text-slate-600">
              <tr>
                <th className="p-4">رقم السيارة</th>
                <th className="p-4">اللوحة</th>
                <th className="p-4">كرت الميزان</th>
                <th className="p-4">القائم</th>
                <th className="p-4">الخصم</th>
                <th className="p-4">الصافي</th>
                <th className="p-4">الإيجار</th>
                <th className="p-4">مصاريف</th>
                <th className="p-4">الحالة</th>
                <th className="p-4">إجراءات</th>
              </tr>
            </thead>

            <tbody>
              {cars.length === 0 ? (
                <tr>
                  <td className="p-6 text-center text-slate-500" colSpan={10}>
                    لا توجد بيانات
                  </td>
                </tr>
              ) : (
                cars.map((car) => (
                  <tr key={car.id} className="border-t border-slate-100">
                    <td className="p-4 font-bold text-[#0B2A4A]">
                      {car.car_number || "-"}
                    </td>
                    <td className="p-4">{car.plate_number || "-"}</td>
                    <td className="p-4">{car.weight_card_number || "-"}</td>
                    <td className="p-4">{Number(car.gross_weight || 0).toFixed(3)}</td>
                    <td className="p-4">{Number(car.deduction_weight || 0).toFixed(3)}</td>
                    <td className="p-4 font-bold">{Number(car.net_weight || 0).toFixed(3)}</td>
                    <td className="p-4">{Number(car.transport_cost || 0).toFixed(3)}</td>
                    <td className="p-4">{Number(car.extra_cost || 0).toFixed(3)}</td>
                    <td className="p-4">
                      <span
                        className={`rounded-full px-3 py-1 text-xs font-bold ${
                          car.car_status === "OPEN"
                            ? "bg-emerald-100 text-emerald-700"
                            : "bg-slate-200 text-slate-600"
                        }`}
                      >
                        {car.car_status === "OPEN" ? "مفتوحة" : "مغلقة"}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => openEditForm(car)}
                          className="rounded-xl bg-blue-700 px-4 py-2 text-sm font-bold text-white"
                        >
                          تعديل
                        </button>
                        <button
                          onClick={() => deleteCar(car.id)}
                          className="rounded-xl bg-rose-600 px-4 py-2 text-sm font-bold text-white"
                        >
                          حذف
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm">
          <div className="absolute left-0 top-0 h-full w-full overflow-y-auto bg-white p-5 shadow-2xl sm:w-[560px]">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-[#0B2A4A]">
                  {editingId ? "تعديل سيارة" : "إضافة سيارة"}
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  أدخل بيانات السيارة والوزن والمصاريف
                </p>
              </div>

              <button
                onClick={() => setShowForm(false)}
                className="rounded-xl bg-slate-200 px-4 py-2 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 gap-3">
              <input className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="رقم السيارة" value={form.car_number} onChange={(e) => setForm({ ...form, car_number: e.target.value })} />

              <input className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="رقم اللوحة" value={form.plate_number} onChange={(e) => setForm({ ...form, plate_number: e.target.value })} />

              <input className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="كرت الميزان" value={form.weight_card_number} onChange={(e) => setForm({ ...form, weight_card_number: e.target.value })} />

              <input type="date" className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" value={form.arrival_date} onChange={(e) => setForm({ ...form, arrival_date: e.target.value })} />

              <input type="number" className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="الوزن القائم" value={form.gross_weight} onChange={(e) => setForm({ ...form, gross_weight: e.target.value })} />

              <input type="number" className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="الخصم" value={form.deduction_weight} onChange={(e) => setForm({ ...form, deduction_weight: e.target.value })} />

              <div className="rounded-2xl border border-blue-100 bg-blue-50 p-4 text-[#0B2A4A]">
                الصافي المحسوب: <b>{netWeight.toFixed(3)}</b> طن
              </div>

              <input type="number" className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="إيجار السيارة" value={form.transport_cost} onChange={(e) => setForm({ ...form, transport_cost: e.target.value })} />

              <input type="number" className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="مصاريف أخرى" value={form.extra_cost} onChange={(e) => setForm({ ...form, extra_cost: e.target.value })} />

              <select className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" value={form.car_status} onChange={(e) => setForm({ ...form, car_status: e.target.value })}>
                <option value="OPEN">مفتوحة</option>
                <option value="CLOSED">مغلقة</option>
              </select>

              <textarea className="min-h-28 rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="ملاحظات" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />

              <button onClick={saveCar} disabled={saving} className="mt-3 rounded-2xl bg-[#0B2A4A] px-5 py-4 font-bold text-white disabled:opacity-60">
                {saving ? "جاري الحفظ..." : editingId ? "حفظ التعديل" : "إضافة السيارة"}
              </button>

              <button onClick={() => setShowForm(false)} className="rounded-2xl bg-slate-200 px-5 py-4 font-bold text-slate-700">
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}