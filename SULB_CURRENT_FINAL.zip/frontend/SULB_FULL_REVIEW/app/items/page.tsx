"use client";

import { useEffect, useMemo, useState } from "react";
import api from "../api";

type Item = {
  id: number;
  item_code: string | null;
  item_name: string;
  item_grade: string | null;
  unit_name: string | null;
  default_buy_price: string | number;
  default_sell_price: string | number;
  min_sell_price: string | number;
  color_notes: string | null;
  notes: string | null;
  is_active: number;
};

export default function ItemsPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const [form, setForm] = useState({
    item_code: "",
    item_name: "",
    item_grade: "",
    unit_name: "طن",
    default_buy_price: "",
    default_sell_price: "",
    min_sell_price: "",
    color_notes: "",
    notes: "",
    is_active: 1,
  });

  const activeCount = useMemo(
    () => items.filter((x) => Number(x.is_active) === 1).length,
    [items]
  );

  const loadItems = async () => {
    setLoading(true);
    try {
      const res = await api.get("/items");
      setItems(res.data.data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadItems();
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setForm({
      item_code: "",
      item_name: "",
      item_grade: "",
      unit_name: "طن",
      default_buy_price: "",
      default_sell_price: "",
      min_sell_price: "",
      color_notes: "",
      notes: "",
      is_active: 1,
    });
  };

  const openAddForm = () => {
    resetForm();
    setShowForm(true);
  };

  const openEditForm = (item: Item) => {
    setEditingId(item.id);
    setForm({
      item_code: item.item_code || "",
      item_name: item.item_name || "",
      item_grade: item.item_grade || "",
      unit_name: item.unit_name || "طن",
      default_buy_price: String(item.default_buy_price || ""),
      default_sell_price: String(item.default_sell_price || ""),
      min_sell_price: String(item.min_sell_price || ""),
      color_notes: item.color_notes || "",
      notes: item.notes || "",
      is_active: item.is_active ? 1 : 0,
    });
    setShowForm(true);
  };

  const saveItem = async () => {
    if (!form.item_name.trim()) {
      alert("اسم الصنف مطلوب");
      return;
    }

    setSaving(true);

    try {
      const payload = {
        ...form,
        default_buy_price: Number(form.default_buy_price || 0),
        default_sell_price: Number(form.default_sell_price || 0),
        min_sell_price: Number(form.min_sell_price || 0),
      };

      if (editingId) {
        await api.put(`/items/${editingId}`, payload);
        alert("تم تحديث الصنف");
      } else {
        await api.post("/items", payload);
        alert("تم إضافة الصنف");
      }

      setShowForm(false);
      resetForm();
      loadItems();
    } finally {
      setSaving(false);
    }
  };

  const deleteItem = async (id: number) => {
    if (!confirm("هل تريد حذف هذا الصنف؟")) return;
    await api.delete(`/items/${id}`);
    alert("تم حذف الصنف");
    loadItems();
  };

  return (
    <section dir="rtl" className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-5 text-white shadow-lg sm:p-7">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm text-blue-100">إدارة الأصناف</p>
            <h1 className="mt-2 text-2xl font-bold sm:text-4xl">
              أصناف السكراب والأسعار
            </h1>
          </div>

          <button
            onClick={openAddForm}
            className="rounded-2xl bg-white px-5 py-3 font-bold text-[#0B2A4A] shadow"
          >
            + إضافة صنف
          </button>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 sm:max-w-md">
          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">إجمالي الأصناف</div>
            <div className="mt-1 text-3xl font-bold">{items.length}</div>
          </div>

          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">النشطة</div>
            <div className="mt-1 text-3xl font-bold">{activeCount}</div>
          </div>
        </div>
      </div>

      <div className="rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-200 p-4">
          <h2 className="text-xl font-bold text-slate-900">قائمة الأصناف</h2>
          <span className="text-sm text-slate-500">
            {loading ? "جاري التحميل..." : `${items.length} صنف`}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-[1000px] w-full text-right">
            <thead className="bg-slate-100 text-slate-600">
              <tr>
                <th className="p-4">الكود</th>
                <th className="p-4">الصنف</th>
                <th className="p-4">التفصيل</th>
                <th className="p-4">الوحدة</th>
                <th className="p-4">شراء</th>
                <th className="p-4">بيع</th>
                <th className="p-4">أقل بيع</th>
                <th className="p-4">الحالة</th>
                <th className="p-4">الإجراءات</th>
              </tr>
            </thead>

            <tbody>
              {items.length === 0 ? (
                <tr>
                  <td className="p-6 text-center text-slate-500" colSpan={9}>
                    لا توجد بيانات
                  </td>
                </tr>
              ) : (
                items.map((item) => (
                  <tr key={item.id} className="border-t border-slate-100">
                    <td className="p-4">{item.item_code || "-"}</td>
                    <td className="p-4 font-bold text-[#0B2A4A]">
                      {item.item_name}
                    </td>
                    <td className="p-4">{item.item_grade || "-"}</td>
                    <td className="p-4">{item.unit_name || "-"}</td>
                    <td className="p-4">
                      {Number(item.default_buy_price || 0).toFixed(3)}
                    </td>
                    <td className="p-4">
                      {Number(item.default_sell_price || 0).toFixed(3)}
                    </td>
                    <td className="p-4">
                      {Number(item.min_sell_price || 0).toFixed(3)}
                    </td>
                    <td className="p-4">
                      <span
                        className={`rounded-full px-3 py-1 text-xs font-bold ${
                          item.is_active
                            ? "bg-emerald-100 text-emerald-700"
                            : "bg-slate-200 text-slate-600"
                        }`}
                      >
                        {item.is_active ? "نشط" : "غير نشط"}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => openEditForm(item)}
                          className="rounded-xl bg-blue-700 px-4 py-2 text-sm font-bold text-white"
                        >
                          تعديل
                        </button>
                        <button
                          onClick={() => deleteItem(item.id)}
                          className="rounded-xl bg-rose-600 px-4 py-2 text-sm font-bold text-white"
                        >
                          حذف
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm">
          <div className="absolute left-0 top-0 h-full w-full overflow-y-auto bg-white p-5 shadow-2xl sm:w-[540px]">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-[#0B2A4A]">
                  {editingId ? "تعديل صنف" : "إضافة صنف"}
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  أدخل بيانات الصنف والأسعار
                </p>
              </div>

              <button
                onClick={() => setShowForm(false)}
                className="rounded-xl bg-slate-200 px-4 py-2 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 gap-3">
              <input className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="كود الصنف" value={form.item_code} onChange={(e) => setForm({ ...form, item_code: e.target.value })} />

              <input className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="اسم الصنف *" value={form.item_name} onChange={(e) => setForm({ ...form, item_name: e.target.value })} />

              <input className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="التفصيل / الجودة" value={form.item_grade} onChange={(e) => setForm({ ...form, item_grade: e.target.value })} />

              <select className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" value={form.unit_name} onChange={(e) => setForm({ ...form, unit_name: e.target.value })}>
                <option value="طن">طن</option>
                <option value="كيلو">كيلو</option>
                <option value="عدد">عدد</option>
              </select>

              <input type="number" className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="سعر الشراء" value={form.default_buy_price} onChange={(e) => setForm({ ...form, default_buy_price: e.target.value })} />

              <input type="number" className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="سعر البيع" value={form.default_sell_price} onChange={(e) => setForm({ ...form, default_sell_price: e.target.value })} />

              <input type="number" className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="أقل سعر بيع" value={form.min_sell_price} onChange={(e) => setForm({ ...form, min_sell_price: e.target.value })} />

              <input className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="ملاحظات اللون / النوع" value={form.color_notes} onChange={(e) => setForm({ ...form, color_notes: e.target.value })} />

              <select className="rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" value={form.is_active} onChange={(e) => setForm({ ...form, is_active: Number(e.target.value) })}>
                <option value={1}>نشط</option>
                <option value={0}>غير نشط</option>
              </select>

              <textarea className="min-h-28 rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]" placeholder="ملاحظات" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />

              <button onClick={saveItem} disabled={saving} className="mt-3 rounded-2xl bg-[#0B2A4A] px-5 py-4 font-bold text-white disabled:opacity-60">
                {saving ? "جاري الحفظ..." : editingId ? "حفظ التعديل" : "إضافة الصنف"}
              </button>

              <button onClick={() => setShowForm(false)} className="rounded-2xl bg-slate-200 px-5 py-4 font-bold text-slate-700">
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}