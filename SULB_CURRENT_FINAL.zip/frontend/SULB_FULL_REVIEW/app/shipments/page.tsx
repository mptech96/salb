"use client";

import { useEffect, useMemo, useState } from "react";
import api from "../api";

type Line = {
  item_id: string;
  gross_weight: number;
  tare_weight: number;
  deduction_weight: number;
  net_weight: number;
  unit_price: number;
  discount_amount: number;
  vat_percent: number;
  vat_amount: number;
  total_before_vat: number;
  total_after_vat: number;
  line_total: number;
  notes?: string;
};

type SellLine = {
  shipment_item_id: string;
  item_name?: string;
  remaining_qty?: number;
  empty_weight: number;
  loaded_weight: number;
  deduction_weight: number;
  net_weight: number;
  unit_price: number;
  discount_amount: number;
  vat_percent: number;
  line_total: number;
};

export default function ShipmentsPage() {
  const [shipments, setShipments] = useState<any[]>([]);
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [drivers, setDrivers] = useState<any[]>([]);
  const [cars, setCars] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);

  const [selected, setSelected] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);
  const [showSellForm, setShowSellForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [msg, setMsg] = useState<any>(null);

  const [form, setForm] = useState<any>(defaultForm());
  const [lines, setLines] = useState<Line[]>([]);

  const [sellForm, setSellForm] = useState<any>({
    customer_id: "",
    car_id: "",
    invoice_date: new Date().toISOString().slice(0, 10),
    commission_amount: 0,
    notes: "",
  });

  const [sellLines, setSellLines] = useState<SellLine[]>([]);

  useEffect(() => {
    loadAll();
  }, []);

  function showMsg(type: "success" | "error" | "info", title: string, text: string) {
    setMsg({ type, title, text });
    setTimeout(() => setMsg(null), 4500);
  }

  async function loadAll() {
    try {
      const [sh, su, cu, dr, ca, it] = await Promise.allSettled([
        api.get("/shipments"),
        api.get("/suppliers"),
        api.get("/customers"),
        api.get("/drivers"),
        api.get("/cars"),
        api.get("/items"),
      ]);

      setShipments(sh.status === "fulfilled" ? sh.value.data.data || [] : []);
      setSuppliers(su.status === "fulfilled" ? su.value.data.data || [] : []);
      setCustomers(cu.status === "fulfilled" ? cu.value.data.data || [] : []);
      setDrivers(dr.status === "fulfilled" ? dr.value.data.data || [] : []);
      setCars(ca.status === "fulfilled" ? ca.value.data.data || [] : []);
      setItems(it.status === "fulfilled" ? it.value.data.data || [] : []);
    } catch {
      showMsg("error", "تعذر تحميل البيانات", "حدث خطأ أثناء تحميل بيانات الحمولات.");
    }
  }

  const totals = useMemo(() => {
    let gross = 0;
    let tare = 0;
    let deduction = 0;
    let net = 0;
    let beforeVat = 0;
    let vat = 0;
    let total = 0;
    let discount = 0;

    lines.forEach((l) => {
      gross += Number(l.gross_weight || 0);
      tare += Number(l.tare_weight || 0);
      deduction += Number(l.deduction_weight || 0);
      net += Number(l.net_weight || 0);
      beforeVat += Number(l.total_before_vat || 0);
      vat += Number(l.vat_amount || 0);
      total += Number(l.total_after_vat || 0);
      discount += Number(l.discount_amount || 0);
    });

    return { gross, tare, deduction, net, beforeVat, vat, total, discount };
  }, [lines]);

  const filtered = shipments.filter((s) =>
    `${s.shipment_number || ""} ${s.supplier_name || ""} ${s.driver_name || ""} ${s.status || ""}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  function openNew() {
    setSelected(null);
    setForm(defaultForm());
    setLines([]);
    setShowForm(true);
  }

  async function openEdit(id: number) {
    try {
      const res = await api.get(`/shipments/${id}`);
      const sh = res.data.data.shipment;
      const ln = res.data.data.lines || [];

      setSelected(sh);
      setForm({
        shipment_date: normalizeDate(sh.shipment_date),
        shipment_number: sh.shipment_number || "",
        supplier_id: sh.supplier_id || "",
        driver_id: sh.driver_id || "",
        car_id: sh.car_id || "",
        plate_number: sh.plate_number || "",
        weight_card_number: sh.weight_card_number || "",
        vat_percent: Number(sh.vat_percent || 15),
        notes: sh.notes || "",
        status: sh.status || "DRAFT",
      });

      setLines(
        ln.map((x: any) => ({
          item_id: String(x.item_id || ""),
          gross_weight: Number(x.gross_weight || 0),
          tare_weight: Number(x.tare_weight || 0),
          deduction_weight: Number(x.deduction_weight || 0),
          net_weight: Number(x.net_weight || 0),
          unit_price: Number(x.unit_price || 0),
          discount_amount: Number(x.discount_amount || 0),
          vat_percent: Number(x.vat_percent || sh.vat_percent || 15),
          vat_amount: Number(x.vat_amount || 0),
          total_before_vat: Number(x.total_before_vat || 0),
          total_after_vat: Number(x.total_after_vat || x.line_total || 0),
          line_total: Number(x.line_total || 0),
          notes: x.notes || "",
        }))
      );

      setShowForm(true);
    } catch (e: any) {
      showMsg("error", "تعذر فتح الحمولة", e?.response?.data?.message || "حدث خطأ أثناء فتح بيانات الحمولة.");
    }
  }

  function addLine() {
    setLines([
      ...lines,
      {
        item_id: "",
        gross_weight: 0,
        tare_weight: 0,
        deduction_weight: 0,
        net_weight: 0,
        unit_price: 0,
        discount_amount: 0,
        vat_percent: Number(form.vat_percent || 15),
        vat_amount: 0,
        total_before_vat: 0,
        total_after_vat: 0,
        line_total: 0,
        notes: "",
      },
    ]);
  }

  function updateLine(index: number, field: keyof Line, value: any) {
    const next = [...lines];
    const line: any = { ...next[index], [field]: value };

    const grossKg = Number(line.gross_weight || 0);
    const tareKg = Number(line.tare_weight || 0);
    const deductionKg = Number(line.deduction_weight || 0);
    const price = Number(line.unit_price || 0);
    const discount = Number(line.discount_amount || 0);
    const vatPercent = Number(line.vat_percent || 0);

    const netKg = Math.max(grossKg - tareKg - deductionKg, 0);
    const netTon = Number((netKg / 1000).toFixed(3));

    const beforeDiscount = netTon * price;
    const beforeVat = Math.max(beforeDiscount - discount, 0);
    const vatAmount = beforeVat * (vatPercent / 100);
    const afterVat = beforeVat + vatAmount;

    line.net_weight = netTon;
    line.total_before_vat = Number(beforeVat.toFixed(3));
    line.vat_amount = Number(vatAmount.toFixed(3));
    line.total_after_vat = Number(afterVat.toFixed(3));
    line.line_total = Number(afterVat.toFixed(3));

    next[index] = line;
    setLines(next);
  }

  function applyVatToLines() {
    const vat = Number(form.vat_percent || 0);

    setLines((old) =>
      old.map((l) => {
        const n: any = { ...l, vat_percent: vat };
        return recalcLine(n);
      })
    );

    showMsg("success", "تم تطبيق الضريبة", "تم تطبيق نسبة الضريبة على جميع أصناف الحمولة.");
  }

  function recalcLine(line: any) {
    const grossKg = Number(line.gross_weight || 0);
    const tareKg = Number(line.tare_weight || 0);
    const deductionKg = Number(line.deduction_weight || 0);
    const price = Number(line.unit_price || 0);
    const discount = Number(line.discount_amount || 0);
    const vatPercent = Number(line.vat_percent || 0);

    const netKg = Math.max(grossKg - tareKg - deductionKg, 0);
    const netTon = Number((netKg / 1000).toFixed(3));
    const beforeVat = Math.max(netTon * price - discount, 0);
    const vatAmount = beforeVat * (vatPercent / 100);
    const afterVat = beforeVat + vatAmount;

    return {
      ...line,
      net_weight: netTon,
      total_before_vat: Number(beforeVat.toFixed(3)),
      vat_amount: Number(vatAmount.toFixed(3)),
      total_after_vat: Number(afterVat.toFixed(3)),
      line_total: Number(afterVat.toFixed(3)),
    };
  }

  function validateShipment() {
    if (!form.shipment_date) {
      showMsg("error", "بيانات ناقصة", "يجب تحديد تاريخ الحمولة.");
      return false;
    }

    if (!form.supplier_id) {
      showMsg("error", "بيانات ناقصة", "يجب اختيار المورد قبل حفظ الحمولة.");
      return false;
    }

    if (lines.length === 0) {
      showMsg("error", "لا توجد أصناف", "يجب إضافة صنف واحد على الأقل داخل الحمولة.");
      return false;
    }

    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];

      if (!l.item_id) {
        showMsg("error", "الصنف مطلوب", `يجب اختيار الصنف في السطر رقم ${i + 1}.`);
        return false;
      }

      if (Number(l.gross_weight || 0) <= 0) {
        showMsg("error", "وزن غير صحيح", `القائم في السطر رقم ${i + 1} يجب أن يكون أكبر من صفر.`);
        return false;
      }

      if (Number(l.net_weight || 0) <= 0) {
        showMsg("error", "صافي غير صحيح", `الصافي في السطر رقم ${i + 1} يجب أن يكون أكبر من صفر.`);
        return false;
      }

      if (Number(l.unit_price || 0) < 0) {
        showMsg("error", "سعر غير صحيح", `السعر في السطر رقم ${i + 1} لا يمكن أن يكون سالبًا.`);
        return false;
      }
    }

    return true;
  }

  async function saveShipment() {
    if (!validateShipment()) return;

    setLoading(true);

    try {
      const payload = {
        ...form,
        supplier_id: form.supplier_id || null,
        driver_id: form.driver_id || null,
        car_id: form.car_id || null,
        items: lines,
      };

      if (selected) {
        await api.put(`/shipments/${selected.id}`, payload);
      } else {
        await api.post("/shipments", payload);
      }

      showMsg("success", "تم حفظ الحمولة", "تم حفظ الحمولة كمسودة بنجاح. يمكنك اعتمادها بعد مراجعة البيانات.");
      setShowForm(false);
      loadAll();
    } catch (e: any) {
      showMsg("error", "فشل حفظ الحمولة", e?.response?.data?.message || "حدث خطأ أثناء حفظ الحمولة.");
    } finally {
      setLoading(false);
    }
  }

  async function approveShipment(id: number) {
    if (!confirm("اعتماد الحمولة سينشئ فاتورة شراء ويدخل المخزون وينشئ قيدًا محاسبيًا. هل أنت متأكد؟")) return;

    try {
      const res = await api.post(`/shipments/${id}/approve`);

      showMsg(
        "success",
        "تم اعتماد الحمولة",
        res?.data?.message || "تم اعتماد الحمولة وإنشاء فاتورة الشراء وإدخال المخزون بنجاح."
      );

      loadAll();
      if (showForm) setShowForm(false);
    } catch (e: any) {
      showMsg("error", "فشل اعتماد الحمولة", e?.response?.data?.message || "تعذر اعتماد الحمولة.");
    }
  }

  async function deleteShipment(id: number) {
    if (!confirm("هل تريد حذف الحمولة؟ لا يمكن حذف حمولة بعد اعتمادها.")) return;

    try {
      await api.delete(`/shipments/${id}`);
      showMsg("success", "تم حذف الحمولة", "تم حذف الحمولة المسودة بنجاح.");
      loadAll();
    } catch (e: any) {
      showMsg("error", "فشل حذف الحمولة", e?.response?.data?.message || "تعذر حذف الحمولة.");
    }
  }

  function openSell(shipment: any) {
    setSelected(shipment);
    setSellForm({
      customer_id: "",
      car_id: "",
      invoice_date: new Date().toISOString().slice(0, 10),
      commission_amount: 0,
      notes: "",
    });

    const available = (shipment.items || [])
      .filter((x: any) => Number(x.remaining_qty || 0) > 0)
      .map((x: any) => ({
        shipment_item_id: String(x.id),
        item_name: itemName(x.item_id),
        remaining_qty: Number(x.remaining_qty || 0),
        empty_weight: 0,
        loaded_weight: 0,
        deduction_weight: 0,
        net_weight: 0,
        unit_price: 0,
        discount_amount: 0,
        vat_percent: 15,
        line_total: 0,
      }));

    setSellLines(available.length ? [available[0]] : []);
    setShowSellForm(true);
  }

  function addSellLine() {
    setSellLines([
      ...sellLines,
      {
        shipment_item_id: "",
        item_name: "",
        remaining_qty: 0,
        empty_weight: 0,
        loaded_weight: 0,
        deduction_weight: 0,
        net_weight: 0,
        unit_price: 0,
        discount_amount: 0,
        vat_percent: 15,
        line_total: 0,
      },
    ]);
  }

  function updateSellLine(index: number, field: keyof SellLine, value: any) {
    const next = [...sellLines];
    const line: any = { ...next[index], [field]: value };

    if (field === "shipment_item_id") {
      const found = (selected?.items || []).find((x: any) => String(x.id) === String(value));
      line.item_name = itemName(found?.item_id);
      line.remaining_qty = Number(found?.remaining_qty || 0);
    }

    const emptyKg = Number(line.empty_weight || 0);
    const loadedKg = Number(line.loaded_weight || 0);
    const deductionKg = Number(line.deduction_weight || 0);
    const price = Number(line.unit_price || 0);
    const discount = Number(line.discount_amount || 0);
    const vatPercent = Number(line.vat_percent || 0);

    const netKg = Math.max(loadedKg - emptyKg - deductionKg, 0);
    const netTon = Number((netKg / 1000).toFixed(3));
    const beforeVat = Math.max(netTon * price - discount, 0);
    const vat = beforeVat * (vatPercent / 100);

    line.net_weight = netTon;
    line.line_total = Number((beforeVat + vat).toFixed(3));

    next[index] = line;
    setSellLines(next);
  }

  function validateSell() {
    if (!sellForm.customer_id) {
      showMsg("error", "بيانات ناقصة", "يجب اختيار العميل قبل اعتماد البيع.");
      return false;
    }

    if (!sellLines.length) {
      showMsg("error", "لا توجد أصناف", "يجب إضافة صنف واحد على الأقل للبيع.");
      return false;
    }

    for (let i = 0; i < sellLines.length; i++) {
      const l = sellLines[i];

      if (!l.shipment_item_id) {
        showMsg("error", "صنف البيع مطلوب", `يجب اختيار صنف الحمولة في السطر رقم ${i + 1}.`);
        return false;
      }

      if (Number(l.net_weight || 0) <= 0) {
        showMsg("error", "وزن البيع غير صحيح", `وزن البيع في السطر رقم ${i + 1} يجب أن يكون أكبر من صفر.`);
        return false;
      }

      if (Number(l.net_weight || 0) > Number(l.remaining_qty || 0)) {
        showMsg("error", "كمية غير متوفرة", `الكمية أكبر من المتبقي للصنف ${l.item_name}.`);
        return false;
      }
    }

    return true;
  }

  async function saveSell() {
    if (!validateSell()) return;

    try {
      await api.post("/shipments/sell", {
        ...sellForm,
        items: sellLines,
      });

      showMsg("success", "تم إنشاء البيع", "تم إنشاء فاتورة البيع وخصم الكمية من المخزون بنجاح.");
      setShowSellForm(false);
      loadAll();
    } catch (e: any) {
      showMsg("error", "فشل حفظ البيع", e?.response?.data?.message || "تعذر حفظ عملية البيع.");
    }
  }

  function itemName(id: any) {
    return items.find((i) => Number(i.id) === Number(id))?.item_name || `صنف ${id || ""}`;
  }

  return (
    <section dir="rtl" className="space-y-5">
      {msg && <MessageBox msg={msg} />}

      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-6 text-white shadow-lg">
        <p className="text-sm text-blue-100">قلب نظام السكراب</p>
        <h1 className="mt-2 text-3xl font-black">مركز إدارة الحمولات</h1>
        <p className="mt-2 text-sm text-blue-100">
          شراء حمولة ← اعتماد ← مخزون ← وزن بيع ← فاتورة بيع
        </p>
      </div>

      <InfoBox
        title="طريقة العمل"
        text="احفظ الحمولة كمسودة أولًا، ثم راجع الأصناف والأوزان، وبعدها اضغط اعتماد لإنشاء فاتورة الشراء والمخزون والقيد المحاسبي."
      />

      <div className="grid grid-cols-1 gap-4 md:grid-cols-5">
        <Stat title="إجمالي الحمولات" value={shipments.length} />
        <Stat title="مسودات" value={shipments.filter((x) => x.status === "DRAFT").length} />
        <Stat title="معتمدة" value={shipments.filter((x) => x.status === "APPROVED").length} />
        <Stat title="إجمالي وزن صافي" value={fmt(shipments.reduce((a, b) => a + Number(b.total_net_weight || 0), 0))} />
        <button onClick={openNew} className="rounded-3xl bg-[#0B2A4A] p-5 text-xl font-black text-white shadow-sm">
          + حمولة شراء
        </button>
      </div>

      <div className="rounded-3xl border bg-white p-4 shadow-sm">
        <input
          className="w-full rounded-2xl border bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
          placeholder="بحث برقم الحمولة أو المورد أو السائق..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="overflow-hidden rounded-3xl border bg-white shadow-sm">
        <div className="border-b p-4">
          <h2 className="text-xl font-black text-[#0B2A4A]">قائمة الحمولات</h2>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-[1200px] w-full text-right">
            <thead className="bg-slate-100 text-slate-700">
              <tr>
                <th className="p-4">رقم الحمولة</th>
                <th className="p-4">التاريخ</th>
                <th className="p-4">المورد</th>
                <th className="p-4">السائق</th>
                <th className="p-4">السيارة</th>
                <th className="p-4">الصافي طن</th>
                <th className="p-4">القيمة</th>
                <th className="p-4">الحالة</th>
                <th className="p-4">الإجراءات</th>
              </tr>
            </thead>

            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-6 text-center text-slate-500">
                    لا توجد حمولات
                  </td>
                </tr>
              ) : (
                filtered.map((s) => (
                  <tr key={s.id} className="border-t hover:bg-slate-50">
                    <td className="p-4 font-black text-[#0B2A4A]">{s.shipment_number}</td>
                    <td className="p-4">{normalizeDate(s.shipment_date)}</td>
                    <td className="p-4">{s.supplier_name || "-"}</td>
                    <td className="p-4">{s.driver_name || "-"}</td>
                    <td className="p-4">{s.car_number || s.plate_number || "-"}</td>
                    <td className="p-4 font-bold">{fmt(s.total_net_weight)}</td>
                    <td className="p-4 font-bold">{money(s.total_amount)}</td>
                    <td className="p-4"><StatusBadge status={s.status} /></td>
                    <td className="p-4">
                      <div className="flex flex-wrap gap-2">
                        <button onClick={() => openEdit(s.id)} className="rounded-xl bg-blue-700 px-3 py-2 text-sm font-bold text-white">
                          فتح
                        </button>

                        {s.status === "APPROVED" && (
                          <button onClick={() => openSell(s)} className="rounded-xl bg-purple-700 px-3 py-2 text-sm font-bold text-white">
                            وزن بيع
                          </button>
                        )}

                        {s.status === "DRAFT" && (
                          <>
                            <button onClick={() => approveShipment(s.id)} className="rounded-xl bg-emerald-600 px-3 py-2 text-sm font-bold text-white">
                              اعتماد
                            </button>
                            <button onClick={() => deleteShipment(s.id)} className="rounded-xl bg-rose-600 px-3 py-2 text-sm font-bold text-white">
                              حذف
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <ShipmentModal
          selected={selected}
          form={form}
          setForm={setForm}
          lines={lines}
          setLines={setLines}
          totals={totals}
          suppliers={suppliers}
          drivers={drivers}
          cars={cars}
          items={items}
          loading={loading}
          addLine={addLine}
          updateLine={updateLine}
          applyVatToLines={applyVatToLines}
          saveShipment={saveShipment}
          approveShipment={approveShipment}
          close={() => setShowForm(false)}
        />
      )}

      {showSellForm && (
        <SellModal
          selected={selected}
          sellForm={sellForm}
          setSellForm={setSellForm}
          sellLines={sellLines}
          setSellLines={setSellLines}
          customers={customers}
          cars={cars}
          items={items}
          addSellLine={addSellLine}
          updateSellLine={updateSellLine}
          saveSell={saveSell}
          close={() => setShowSellForm(false)}
        />
      )}
    </section>
  );
}

function ShipmentModal(props: any) {
  const {
    selected, form, setForm, lines, setLines, totals, suppliers, drivers, cars, items,
    loading, addLine, updateLine, applyVatToLines, saveShipment, approveShipment, close
  } = props;

  const disabled = selected?.status === "APPROVED";

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 p-4 backdrop-blur-sm">
      <div className="mx-auto max-w-7xl rounded-3xl bg-white shadow-2xl">
        <div className="sticky top-0 z-10 rounded-t-3xl border-b bg-white p-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-2xl font-black text-[#0B2A4A]">
                {selected ? `مركز الحمولة ${selected.shipment_number}` : "حمولة شراء جديدة"}
              </h2>
              <p className="text-sm text-slate-500">السيارة تدخل محملة ثم تخرج فارغة، والصافي يتحول إلى طن.</p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button onClick={saveShipment} disabled={loading || disabled} className="rounded-2xl bg-[#0B2A4A] px-5 py-3 font-bold text-white disabled:opacity-50">
                {loading ? "جاري الحفظ..." : "حفظ مسودة"}
              </button>

              {selected && selected.status === "DRAFT" && (
                <button onClick={() => approveShipment(selected.id)} className="rounded-2xl bg-emerald-600 px-5 py-3 font-bold text-white">
                  اعتماد وإنشاء فاتورة
                </button>
              )}

              <button onClick={close} className="rounded-2xl bg-slate-200 px-5 py-3 font-bold text-slate-700">
                إغلاق
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-5 p-5">
          {disabled && (
            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm font-bold text-amber-800">
              هذه الحمولة معتمدة، لذلك لا يمكن تعديل بياناتها أو حذف أصنافها.
            </div>
          )}

          <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
            <Stat title="القائم كجم" value={fmt(totals.gross)} />
            <Stat title="الفارغ كجم" value={fmt(totals.tare)} />
            <Stat title="الخصم كجم" value={fmt(totals.deduction)} />
            <Stat title="الصافي طن" value={fmt(totals.net)} />
            <Stat title="قبل الضريبة" value={money(totals.beforeVat)} />
            <Stat title="الضريبة" value={money(totals.vat)} />
            <Stat title="الإجمالي" value={money(totals.total)} />
            <Stat title="الحالة" value={statusLabel(form.status)} />
          </div>

          <div className="rounded-3xl border bg-white p-5">
            <h3 className="mb-4 text-xl font-black text-[#0B2A4A]">بيانات الحمولة</h3>

            <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
              <Input disabled={disabled} label="رقم الحمولة" value={form.shipment_number} onChange={(v: any) => setForm({ ...form, shipment_number: v })} />
              <Input disabled={disabled} type="date" label="تاريخ الحمولة" value={form.shipment_date} onChange={(v: any) => setForm({ ...form, shipment_date: v })} />
              <Select disabled={disabled} label="المورد" value={form.supplier_id} onChange={(v: any) => setForm({ ...form, supplier_id: v })} options={suppliers} nameKey="supplier_name" />
              <Select disabled={disabled} label="السائق" value={form.driver_id} onChange={(v: any) => setForm({ ...form, driver_id: v })} options={drivers} nameKey="driver_name" />
              <Select disabled={disabled} label="السيارة" value={form.car_id} onChange={(v: any) => setForm({ ...form, car_id: v })} options={cars} nameKey="car_number" />
              <Input disabled={disabled} label="رقم اللوحة" value={form.plate_number} onChange={(v: any) => setForm({ ...form, plate_number: v })} />
              <Input disabled={disabled} label="رقم كرت الميزان" value={form.weight_card_number} onChange={(v: any) => setForm({ ...form, weight_card_number: v })} />
              <Input disabled={disabled} type="number" label="ضريبة عامة %" value={form.vat_percent} onChange={(v: any) => setForm({ ...form, vat_percent: v })} />

              <button disabled={disabled} onClick={applyVatToLines} className="rounded-2xl bg-slate-900 px-4 py-3 font-bold text-white disabled:opacity-50">
                تطبيق الضريبة على كل الأصناف
              </button>
            </div>

            <textarea
              disabled={disabled}
              className="mt-3 w-full rounded-2xl border bg-slate-50 p-4 outline-none focus:border-[#0B2A4A] disabled:opacity-60"
              placeholder="ملاحظات"
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
            />
          </div>

          <div className="rounded-3xl border bg-white p-5">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-xl font-black text-[#0B2A4A]">الأوزان والفرز</h3>
              <button onClick={addLine} disabled={disabled} className="rounded-2xl bg-[#0B2A4A] px-4 py-3 font-bold text-white disabled:opacity-50">
                + إضافة صنف
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-[1500px] w-full text-right">
                <thead className="bg-slate-100">
                  <tr>
                    <th className="p-3">الصنف</th>
                    <th className="p-3">قائم كجم</th>
                    <th className="p-3">فارغ كجم</th>
                    <th className="p-3">خصم كجم</th>
                    <th className="p-3">صافي طن</th>
                    <th className="p-3">السعر/طن</th>
                    <th className="p-3">خصم</th>
                    <th className="p-3">ضريبة %</th>
                    <th className="p-3">قبل الضريبة</th>
                    <th className="p-3">الضريبة</th>
                    <th className="p-3">بعد الضريبة</th>
                    <th className="p-3">ملاحظات</th>
                    <th className="p-3">حذف</th>
                  </tr>
                </thead>

                <tbody>
                  {lines.length === 0 ? (
                    <tr>
                      <td colSpan={13} className="p-6 text-center text-slate-500">لا توجد أصناف بعد</td>
                    </tr>
                  ) : (
                    lines.map((line: any, index: number) => (
                      <tr key={index} className="border-t">
                        <td className="p-2">
                          <select disabled={disabled} className="w-full rounded-xl border p-2" value={line.item_id} onChange={(e) => updateLine(index, "item_id", e.target.value)}>
                            <option value="">اختر</option>
                            {items.map((item: any) => <option key={item.id} value={item.id}>{item.item_name}</option>)}
                          </select>
                        </td>
                        <Cell disabled={disabled} value={line.gross_weight} onChange={(v: any) => updateLine(index, "gross_weight", v)} />
                        <Cell disabled={disabled} value={line.tare_weight} onChange={(v: any) => updateLine(index, "tare_weight", v)} />
                        <Cell disabled={disabled} value={line.deduction_weight} onChange={(v: any) => updateLine(index, "deduction_weight", v)} />
                        <td className="p-2 font-black text-[#0B2A4A]">{fmt(line.net_weight)}</td>
                        <Cell disabled={disabled} value={line.unit_price} onChange={(v: any) => updateLine(index, "unit_price", v)} />
                        <Cell disabled={disabled} value={line.discount_amount} onChange={(v: any) => updateLine(index, "discount_amount", v)} />
                        <Cell disabled={disabled} value={line.vat_percent} onChange={(v: any) => updateLine(index, "vat_percent", v)} />
                        <td className="p-2 font-bold">{money(line.total_before_vat)}</td>
                        <td className="p-2 font-bold">{money(line.vat_amount)}</td>
                        <td className="p-2 font-black">{money(line.total_after_vat)}</td>
                        <td className="p-2">
                          <input disabled={disabled} className="w-full rounded-xl border p-2" value={line.notes || ""} onChange={(e) => updateLine(index, "notes", e.target.value)} />
                        </td>
                        <td className="p-2">
                          <button disabled={disabled} onClick={() => setLines(lines.filter((_: any, i: number) => i !== index))} className="rounded-xl bg-rose-600 px-3 py-2 text-white disabled:opacity-50">
                            حذف
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

function SellModal(props: any) {
  const { selected, sellForm, setSellForm, sellLines, setSellLines, customers, cars, items, addSellLine, updateSellLine, saveSell, close } = props;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 p-4 backdrop-blur-sm">
      <div className="mx-auto max-w-6xl rounded-3xl bg-white shadow-2xl">
        <div className="sticky top-0 z-10 rounded-t-3xl border-b bg-white p-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-2xl font-black text-[#0B2A4A]">وزن بيع من الحمولة {selected?.shipment_number}</h2>
              <p className="text-sm text-slate-500">السيارة تدخل فارغة ثم تخرج محملة، والنظام يخصم من المتبقي.</p>
            </div>

            <div className="flex gap-2">
              <button onClick={saveSell} className="rounded-2xl bg-purple-700 px-5 py-3 font-bold text-white">
                اعتماد البيع
              </button>
              <button onClick={close} className="rounded-2xl bg-slate-200 px-5 py-3 font-bold">
                إغلاق
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-5 p-5">
          <InfoBox
            title="تنبيه البيع"
            text="لا يمكن بيع كمية أكبر من المتبقي في الحمولة. يتم احتساب الصافي بالطن تلقائيًا من الأوزان."
          />

          <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
            <Select label="العميل" value={sellForm.customer_id} onChange={(v: any) => setSellForm({ ...sellForm, customer_id: v })} options={customers} nameKey="customer_name" />
            <Select label="السيارة" value={sellForm.car_id} onChange={(v: any) => setSellForm({ ...sellForm, car_id: v })} options={cars} nameKey="car_number" />
            <Input type="date" label="تاريخ البيع" value={sellForm.invoice_date} onChange={(v: any) => setSellForm({ ...sellForm, invoice_date: v })} />
            <Input type="number" label="عمولة بيع" value={sellForm.commission_amount} onChange={(v: any) => setSellForm({ ...sellForm, commission_amount: v })} />
          </div>

          <div className="rounded-3xl border bg-white p-5">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-xl font-black text-[#0B2A4A]">الأوزان الخارجة للبيع</h3>
              <button onClick={addSellLine} className="rounded-2xl bg-[#0B2A4A] px-4 py-3 font-bold text-white">
                + إضافة صنف
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-[1300px] w-full text-right">
                <thead className="bg-slate-100">
                  <tr>
                    <th className="p-3">صنف الحمولة</th>
                    <th className="p-3">المتبقي طن</th>
                    <th className="p-3">فارغة كجم</th>
                    <th className="p-3">محملة كجم</th>
                    <th className="p-3">خصم كجم</th>
                    <th className="p-3">الصافي طن</th>
                    <th className="p-3">السعر</th>
                    <th className="p-3">خصم</th>
                    <th className="p-3">ضريبة %</th>
                    <th className="p-3">الإجمالي</th>
                    <th className="p-3">حذف</th>
                  </tr>
                </thead>

                <tbody>
                  {sellLines.map((line: any, index: number) => (
                    <tr key={index} className="border-t">
                      <td className="p-2">
                        <select className="w-full rounded-xl border p-2" value={line.shipment_item_id} onChange={(e) => updateSellLine(index, "shipment_item_id", e.target.value)}>
                          <option value="">اختر</option>
                          {(selected?.items || []).filter((x: any) => Number(x.remaining_qty || 0) > 0).map((x: any) => {
                            const itemName = items.find((i: any) => Number(i.id) === Number(x.item_id))?.item_name || `صنف ${x.item_id}`;
                            return <option key={x.id} value={x.id}>{itemName}</option>;
                          })}
                        </select>
                      </td>
                      <td className="p-2 font-black text-[#0B2A4A]">{fmt(line.remaining_qty)}</td>
                      <Cell value={line.empty_weight} onChange={(v: any) => updateSellLine(index, "empty_weight", v)} />
                      <Cell value={line.loaded_weight} onChange={(v: any) => updateSellLine(index, "loaded_weight", v)} />
                      <Cell value={line.deduction_weight} onChange={(v: any) => updateSellLine(index, "deduction_weight", v)} />
                      <td className="p-2 font-black text-[#0B2A4A]">{fmt(line.net_weight)}</td>
                      <Cell value={line.unit_price} onChange={(v: any) => updateSellLine(index, "unit_price", v)} />
                      <Cell value={line.discount_amount} onChange={(v: any) => updateSellLine(index, "discount_amount", v)} />
                      <Cell value={line.vat_percent} onChange={(v: any) => updateSellLine(index, "vat_percent", v)} />
                      <td className="p-2 font-black">{money(line.line_total)}</td>
                      <td className="p-2">
                        <button onClick={() => setSellLines(sellLines.filter((_: any, i: number) => i !== index))} className="rounded-xl bg-rose-600 px-3 py-2 text-white">
                          حذف
                        </button>
                      </td>
                    </tr>
                  ))}

                  {sellLines.length === 0 && (
                    <tr>
                      <td colSpan={11} className="p-6 text-center text-slate-500">لا توجد أصناف للبيع</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <textarea
            className="w-full rounded-2xl border bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
            placeholder="ملاحظات البيع"
            value={sellForm.notes}
            onChange={(e) => setSellForm({ ...sellForm, notes: e.target.value })}
          />
        </div>
      </div>
    </div>
  );
}

function MessageBox({ msg }: any) {
  const cls =
    msg.type === "success"
      ? "bg-emerald-50 text-emerald-800 border-emerald-200"
      : msg.type === "error"
      ? "bg-rose-50 text-rose-800 border-rose-200"
      : "bg-blue-50 text-blue-800 border-blue-200";

  return (
    <div className={`rounded-3xl border p-4 font-bold shadow-sm ${cls}`}>
      <div className="text-lg font-black">{msg.title}</div>
      <div className="mt-1 text-sm">{msg.text}</div>
    </div>
  );
}

function InfoBox({ title, text }: any) {
  return (
    <div className="rounded-3xl border border-blue-200 bg-blue-50 p-4 text-blue-900">
      <div className="font-black">{title}</div>
      <div className="mt-1 text-sm font-semibold">{text}</div>
    </div>
  );
}

function Stat({ title, value }: any) {
  return (
    <div className="rounded-3xl bg-white p-5 shadow-sm border">
      <div className="text-sm text-slate-500">{title}</div>
      <div className="mt-2 text-2xl font-black text-[#0B2A4A]">{value}</div>
    </div>
  );
}

function StatusBadge({ status }: any) {
  const isApproved = status === "APPROVED";
  const cls = isApproved ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700";
  return <span className={`rounded-full px-3 py-1 text-xs font-bold ${cls}`}>{isApproved ? "معتمدة" : "مسودة"}</span>;
}

function Input({ label, value, onChange, type = "text", disabled = false }: any) {
  const isNumber = type === "number";

  return (
    <label className="block">
      <div className="mb-1 text-sm font-bold text-slate-600">{label}</div>
      <input
        disabled={disabled}
        type={type}
        inputMode={isNumber ? "decimal" : undefined}
        step={isNumber ? "0.001" : undefined}
        min={isNumber ? "0" : undefined}
        className="w-full rounded-2xl border bg-slate-50 p-3 outline-none focus:border-[#0B2A4A] disabled:opacity-60"
        value={value ?? ""}
        onWheel={(e: any) => isNumber && e.currentTarget.blur()}
        onChange={(e) => onChange(isNumber ? Number(e.target.value) : e.target.value)}
      />
    </label>
  );
}

function Select({ label, value, onChange, options, nameKey, disabled = false }: any) {
  return (
    <label className="block">
      <div className="mb-1 text-sm font-bold text-slate-600">{label}</div>
      <select disabled={disabled} className="w-full rounded-2xl border bg-slate-50 p-3 outline-none focus:border-[#0B2A4A] disabled:opacity-60" value={value ?? ""} onChange={(e) => onChange(e.target.value)}>
        <option value="">اختر</option>
        {options.map((x: any) => <option key={x.id} value={x.id}>{x[nameKey] || x.name || x.id}</option>)}
      </select>
    </label>
  );
}

function Cell({ value, onChange, disabled = false }: any) {
  return (
    <td className="p-2">
      <input
        disabled={disabled}
        type="number"
        inputMode="decimal"
        step="0.001"
        min="0"
        className="w-28 rounded-xl border p-2 outline-none focus:border-[#0B2A4A] disabled:opacity-60"
        value={value ?? 0}
        onWheel={(e: any) => e.currentTarget.blur()}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </td>
  );
}

function defaultForm() {
  return {
    shipment_date: new Date().toISOString().slice(0, 10),
    shipment_number: "",
    supplier_id: "",
    driver_id: "",
    car_id: "",
    plate_number: "",
    weight_card_number: "",
    vat_percent: 15,
    notes: "",
    status: "DRAFT",
  };
}

function normalizeDate(v: any) {
  if (!v) return "";
  return String(v).slice(0, 10);
}

function fmt(v: any) {
  return Number(v || 0).toFixed(3);
}

function money(v: any) {
  return Number(v || 0).toFixed(3);
}

function statusLabel(v: any) {
  if (v === "APPROVED") return "معتمدة";
  if (v === "DRAFT") return "مسودة";
  return v || "-";
}