import axios from "axios";
import {
  clearAllSessions,
  getAuthToken,
  hasPlatformSessionBackup,
  readSession,
  restorePlatformSession,
} from "@/lib/session";

const api = axios.create({
  baseURL:
    process.env.NEXT_PUBLIC_API_URL ||
    "http://127.0.0.1:8000/api",
  headers: {
    Accept: "application/json",
    "Content-Type": "application/json",
  },
  timeout: 30000,
});

api.interceptors.request.use(
  (config) => {
    const token = getAuthToken();

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    } else if (config.headers.Authorization) {
      delete config.headers.Authorization;
    }

    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = Number(error?.response?.status || 0);
    const requestUrl = String(error?.config?.url || "");
    const isLoginRequest = requestUrl.endsWith("/login") || requestUrl === "/login";

    if (
      typeof window !== "undefined" &&
      status === 401 &&
      !isLoginRequest
    ) {
      const currentSession = readSession();

      if (
        currentSession?.user?.is_support_mode &&
        hasPlatformSessionBackup() &&
        restorePlatformSession()
      ) {
        window.location.replace("/system-center/companies?support=expired");
      } else {
        clearAllSessions();

        if (window.location.pathname !== "/login") {
          window.location.replace("/login?session=expired");
        }
      }
    }

    return Promise.reject(error);
  }
);

export default api;
