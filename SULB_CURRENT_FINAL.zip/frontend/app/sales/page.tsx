"use client";

import { useEffect, useMemo, useState } from "react";
import api from "../api";
import SystemDialog from "@/components/common/SystemDialog";

type Sale = {
  id: number;
  invoice_number: string | null;
  invoice_date: string | null;
  customer_name: string | null;
  car_number: string | null;
  total_qty: string | number;
  total_amount: string | number;
  payment_status: string | null;
};

export default function SalesPage() {
  const [sales, setSales] = useState<Sale[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [cars, setCars] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(false);
  const [dialog, setDialog] = useState({
    open: false,
    type: "info" as "success" | "error" | "warning" | "info" | "confirm",
    title: "",
    message: "",
  });

  const showMessage = (
    type: "success" | "error" | "warning" | "info",
    title: string,
    message: string
  ) => setDialog({ open: true, type, title, message });

  const apiMessage = (error: any) =>
    error?.response?.data?.message ||
    error?.message ||
    "تعذر إكمال العملية. حاول مرة أخرى.";

  const [invoice, setInvoice] = useState({
    customer_id: "",
    car_id: "",
    invoice_number: "",
    invoice_date: "",
    discount_amount: 0,
    commission_amount: 0,
    notes: "",
  });

  const [lines, setLines] = useState([
    {
      item_id: "",
      qty: 0,
      unit_price: 0,
      discount_amount: 0,
      line_total: 0,
    },
  ]);

  const loadAll = async () => {
    setLoading(true);

    try {
      const [salesRes, customersRes, carsRes, itemsRes] = await Promise.all([
        api.get("/sales-invoices"),
        api.get("/customers"),
        api.get("/cars"),
        api.get("/items"),
      ]);

      setSales(salesRes.data.data || []);
      setCustomers(customersRes.data.data || []);
      setCars(carsRes.data.data || []);
      setItems(itemsRes.data.data || []);
    } catch (error: any) {
      setSales([]);
      setCustomers([]);
      setCars([]);
      setItems([]);
      showMessage("error", "تعذر فتح فواتير المبيعات", apiMessage(error));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setInvoice({
      customer_id: "",
      car_id: "",
      invoice_number: "",
      invoice_date: "",
      discount_amount: 0,
      commission_amount: 0,
      notes: "",
    });
    setLines([
      {
        item_id: "",
        qty: 0,
        unit_price: 0,
        discount_amount: 0,
        line_total: 0,
      },
    ]);
  };

  const openAddForm = () => {
    resetForm();
    setShowForm(true);
  };

  const updateLine = (index: number, field: string, value: any) => {
    const updated = [...lines] as any[];

    updated[index] = {
      ...updated[index],
      [field]: value,
    };

    const qty = Number(updated[index].qty || 0);
    const price = Number(updated[index].unit_price || 0);
    const discount = Number(updated[index].discount_amount || 0);

    updated[index].line_total = qty * price - discount;

    setLines(updated);
  };

  const addLine = () => {
    setLines([
      ...lines,
      {
        item_id: "",
        qty: 0,
        unit_price: 0,
        discount_amount: 0,
        line_total: 0,
      },
    ]);
  };

  const removeLine = (index: number) => {
    if (lines.length === 1) return;
    setLines(lines.filter((_, i) => i !== index));
  };

  const totalQty = useMemo(() => {
    return lines.reduce((sum, line) => sum + Number(line.qty || 0), 0);
  }, [lines]);

  const subtotal = useMemo(() => {
    return lines.reduce((sum, line) => sum + Number(line.line_total || 0), 0);
  }, [lines]);

  const finalTotal = useMemo(() => {
    return (
      subtotal -
      Number(invoice.discount_amount || 0) -
      Number(invoice.commission_amount || 0)
    );
  }, [subtotal, invoice]);

  const saveInvoice = async () => {
    if (!invoice.customer_id) {
      showMessage("warning", "تحقق من البيانات", "اختر العميل.");
      return;
    }

    const cleanLines = lines.filter((l) => l.item_id && Number(l.qty) > 0);

    if (cleanLines.length === 0) {
      showMessage("warning", "تحقق من البيانات", "أضف صنفًا واحدًا على الأقل.");
      return;
    }

    setSaving(true);

    try {
      const payload = {
        ...invoice,
        car_id: invoice.car_id || null,
        total_qty: totalQty,
        total_before_discount: subtotal,
        discount_amount: Number(invoice.discount_amount || 0),
        commission_amount: Number(invoice.commission_amount || 0),
        total_amount: finalTotal,
        items: cleanLines,
      };

      if (editingId) {
        await api.put(`/sales-invoices/${editingId}`, payload);
        showMessage("success", "تم تعديل الفاتورة", "تم حفظ تعديلات فاتورة البيع بنجاح.");
      } else {
        await api.post("/sales-invoices", payload);
        showMessage("success", "تم حفظ الفاتورة", "تم إنشاء فاتورة البيع بنجاح.");
      }

      setShowForm(false);
      resetForm();
      loadAll();
    } catch (error: any) {
      showMessage("error", "تعذر حفظ الفاتورة", apiMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const editInvoice = async (id: number) => {
    try {
      const res = await api.get(`/sales-invoices/${id}`);
      const data = res.data.data;

      setEditingId(id);
      setInvoice({
        customer_id: String(data.invoice.customer_id || ""),
        car_id: String(data.invoice.car_id || ""),
        invoice_number: data.invoice.invoice_number || "",
        invoice_date: data.invoice.invoice_date || "",
        discount_amount: Number(data.invoice.discount_amount || 0),
        commission_amount: Number(data.invoice.commission_amount || 0),
        notes: data.invoice.notes || "",
      });

      setLines(
        data.lines.map((line: any) => ({
          item_id: String(line.item_id),
          qty: Number(line.qty || 0),
          unit_price: Number(line.unit_price || 0),
          discount_amount: Number(line.discount_amount || 0),
          line_total: Number(line.line_total || 0),
        }))
      );
      setShowForm(true);
    } catch (error: any) {
      showMessage("error", "تعذر فتح الفاتورة", apiMessage(error));
    }
  };

  const deleteInvoice = async (id: number) => {
    if (!confirm("هل أنت متأكد من حذف الفاتورة؟")) {
      return;
    }

    try {
      await api.delete(`/sales-invoices/${id}`);
      showMessage("success", "تم حذف الفاتورة", "تم حذف الفاتورة بنجاح.");
      loadAll();
    } catch (error: any) {
      showMessage("error", "تعذر حذف الفاتورة", apiMessage(error));
    }
  };

  return (
    <>
      <section dir="rtl" className="space-y-5">
      <div className="rounded-3xl bg-gradient-to-l from-[#0B2A4A] to-[#123D68] p-5 text-white shadow-lg sm:p-7">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm text-blue-100">المبيعات</p>
            <h1 className="mt-2 text-2xl font-bold sm:text-4xl">
              فواتير بيع السكراب
            </h1>
            <p className="mt-2 text-sm text-blue-100">
              البيع من سيارة محددة أو من الحوش / المخزون العام.
            </p>
          </div>

          <button
            onClick={openAddForm}
            className="rounded-2xl bg-white px-5 py-3 font-bold text-[#0B2A4A]"
          >
            + إضافة فاتورة
          </button>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 sm:max-w-md">
          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">عدد الفواتير</div>
            <div className="mt-1 text-3xl font-bold">{sales.length}</div>
          </div>

          <div className="rounded-2xl bg-white/10 p-4">
            <div className="text-sm text-blue-100">إجمالي البيع</div>
            <div className="mt-1 text-2xl font-bold">
              {sales.reduce((s, x) => s + Number(x.total_amount || 0), 0).toFixed(3)}
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-200 p-4">
          <h2 className="text-xl font-bold text-slate-900">قائمة الفواتير</h2>
          <span className="text-sm text-slate-500">
            {loading ? "جاري التحميل..." : `${sales.length} فاتورة`}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-[1000px] w-full text-right">
            <thead className="bg-slate-100 text-slate-600">
              <tr>
                <th className="p-4">الفاتورة</th>
                <th className="p-4">التاريخ</th>
                <th className="p-4">العميل</th>
                <th className="p-4">المصدر</th>
                <th className="p-4">الكمية</th>
                <th className="p-4">الإجمالي</th>
                <th className="p-4">الإجراءات</th>
              </tr>
            </thead>

            <tbody>
              {sales.length === 0 ? (
                <tr>
                  <td className="p-6 text-center text-slate-500" colSpan={7}>
                    لا توجد بيانات
                  </td>
                </tr>
              ) : (
                sales.map((sale) => (
                  <tr key={sale.id} className="border-t border-slate-100">
                    <td className="p-4 font-bold text-[#0B2A4A]">
                      {sale.invoice_number || "-"}
                    </td>
                    <td className="p-4">{sale.invoice_date || "-"}</td>
                    <td className="p-4">{sale.customer_name || "-"}</td>
                    <td className="p-4">
                      {sale.car_number ? `سيارة ${sale.car_number}` : "الحوش / عام"}
                    </td>
                    <td className="p-4">{Number(sale.total_qty || 0).toFixed(3)}</td>
                    <td className="p-4">{Number(sale.total_amount || 0).toFixed(3)}</td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => editInvoice(sale.id)}
                          className="rounded-xl bg-blue-700 px-4 py-2 text-sm font-bold text-white"
                        >
                          تعديل
                        </button>

                        <button
                          onClick={() => deleteInvoice(sale.id)}
                          className="rounded-xl bg-rose-600 px-4 py-2 text-sm font-bold text-white"
                        >
                          حذف
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm">
          <div className="absolute left-0 top-0 h-full w-full overflow-y-auto bg-white p-5 shadow-2xl xl:w-[940px]">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-[#0B2A4A]">
                  {editingId ? "تعديل فاتورة بيع" : "إضافة فاتورة بيع"}
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  اختر العميل، ثم حدد هل البيع من سيارة أو من الحوش.
                </p>
              </div>

              <button
                onClick={() => setShowForm(false)}
                className="rounded-xl bg-slate-200 px-4 py-2 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">العميل *</span>
                <select
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={invoice.customer_id}
                  onChange={(e) =>
                    setInvoice({ ...invoice, customer_id: e.target.value })
                  }
                >
                  <option value="">اختر العميل</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.customer_name}
                    </option>
                  ))}
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">
                  مصدر البيع
                </span>
                <select
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={invoice.car_id}
                  onChange={(e) =>
                    setInvoice({ ...invoice, car_id: e.target.value })
                  }
                >
                  <option value="">الحوش / المخزون العام</option>
                  {cars.map((c) => (
                    <option key={c.id} value={c.id}>
                      سيارة: {c.car_number || c.plate_number}
                    </option>
                  ))}
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">رقم الفاتورة</span>
                <input
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  placeholder="مثال: SAL-0001"
                  value={invoice.invoice_number}
                  onChange={(e) =>
                    setInvoice({ ...invoice, invoice_number: e.target.value })
                  }
                />
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">تاريخ الفاتورة</span>
                <input
                  type="date"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#0B2A4A]"
                  value={invoice.invoice_date}
                  onChange={(e) =>
                    setInvoice({ ...invoice, invoice_date: e.target.value })
                  }
                />
              </label>
            </div>

            <div className="mt-6 rounded-3xl border border-slate-200 p-4">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-xl font-bold text-[#0B2A4A]">الأصناف</h3>

                <button
                  onClick={addLine}
                  className="rounded-2xl bg-[#0B2A4A] px-4 py-3 font-bold text-white"
                >
                  + صنف
                </button>
              </div>

              <div className="space-y-3">
                {lines.map((line, index) => (
                  <div key={index} className="rounded-2xl bg-slate-50 p-3">
                    <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-5">
                      <label className="space-y-1">
                        <span className="text-xs font-bold text-slate-500">الصنف</span>
                        <select
                          className="w-full rounded-xl border border-slate-200 bg-white p-3"
                          value={line.item_id}
                          onChange={(e) =>
                            updateLine(index, "item_id", e.target.value)
                          }
                        >
                          <option value="">اختر الصنف</option>
                          {items.map((item) => (
                            <option key={item.id} value={item.id}>
                              {item.item_name}
                            </option>
                          ))}
                        </select>
                      </label>

                      <label className="space-y-1">
                        <span className="text-xs font-bold text-slate-500">
                          الكمية بالطن
                        </span>
                        <input
                          type="number"
                          className="w-full rounded-xl border border-slate-200 bg-white p-3"
                          placeholder="مثال: 1.500"
                          value={line.qty}
                          onChange={(e) =>
                            updateLine(index, "qty", e.target.value)
                          }
                        />
                      </label>

                      <label className="space-y-1">
                        <span className="text-xs font-bold text-slate-500">
                          سعر الطن
                        </span>
                        <input
                          type="number"
                          className="w-full rounded-xl border border-slate-200 bg-white p-3"
                          placeholder="سعر البيع"
                          value={line.unit_price}
                          onChange={(e) =>
                            updateLine(index, "unit_price", e.target.value)
                          }
                        />
                      </label>

                      <label className="space-y-1">
                        <span className="text-xs font-bold text-slate-500">
                          خصم السطر
                        </span>
                        <input
                          type="number"
                          className="w-full rounded-xl border border-slate-200 bg-white p-3"
                          placeholder="خصم"
                          value={line.discount_amount}
                          onChange={(e) =>
                            updateLine(index, "discount_amount", e.target.value)
                          }
                        />
                      </label>

                      <div className="flex items-end gap-2">
                        <div className="flex-1 rounded-xl bg-blue-50 p-3 text-center font-bold text-[#0B2A4A]">
                          الإجمالي: {Number(line.line_total || 0).toFixed(3)}
                        </div>

                        <button
                          onClick={() => removeLine(index)}
                          className="rounded-xl bg-rose-600 px-4 py-3 font-bold text-white"
                        >
                          حذف
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6 grid grid-cols-1 gap-3 md:grid-cols-2">
              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">خصم الفاتورة</span>
                <input
                  type="number"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4"
                  value={invoice.discount_amount}
                  onChange={(e) =>
                    setInvoice({
                      ...invoice,
                      discount_amount: Number(e.target.value),
                    })
                  }
                />
              </label>

              <label className="space-y-1">
                <span className="text-sm font-bold text-slate-600">عمولة</span>
                <input
                  type="number"
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4"
                  value={invoice.commission_amount}
                  onChange={(e) =>
                    setInvoice({
                      ...invoice,
                      commission_amount: Number(e.target.value),
                    })
                  }
                />
              </label>
            </div>

            <textarea
              className="mt-3 min-h-24 w-full rounded-2xl border border-slate-200 bg-slate-50 p-4"
              placeholder="ملاحظات"
              value={invoice.notes}
              onChange={(e) => setInvoice({ ...invoice, notes: e.target.value })}
            />

            <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
              <div className="rounded-2xl bg-slate-100 p-4">
                <div className="text-sm text-slate-500">الكمية</div>
                <div className="mt-1 text-2xl font-bold">{totalQty.toFixed(3)}</div>
              </div>

              <div className="rounded-2xl bg-slate-100 p-4">
                <div className="text-sm text-slate-500">قبل الخصم</div>
                <div className="mt-1 text-2xl font-bold">{subtotal.toFixed(3)}</div>
              </div>

              <div className="rounded-2xl bg-blue-50 p-4">
                <div className="text-sm text-[#0B2A4A]">الإجمالي النهائي</div>
                <div className="mt-1 text-2xl font-bold text-[#0B2A4A]">
                  {finalTotal.toFixed(3)}
                </div>
              </div>

              <button
                onClick={saveInvoice}
                disabled={saving}
                className="rounded-2xl bg-[#0B2A4A] p-4 text-lg font-bold text-white"
              >
                {saving
                  ? "جاري الحفظ..."
                  : editingId
                  ? "حفظ التعديل"
                  : "حفظ الفاتورة"}
              </button>
            </div>
          </div>
        </div>
      )}
      </section>

      <SystemDialog
        open={dialog.open}
        type={dialog.type}
        title={dialog.title}
        message={dialog.message}
        confirmText="حسنًا"
        showCancel={false}
        onConfirm={() => setDialog((current) => ({ ...current, open: false }))}
        onClose={() => setDialog((current) => ({ ...current, open: false }))}
      />
    </>
  );
}