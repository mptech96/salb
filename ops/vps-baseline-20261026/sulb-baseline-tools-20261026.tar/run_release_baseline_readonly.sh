#!/usr/bin/env bash
set -euo pipefail
umask 077
trap 'stty echo < /dev/tty 2>/dev/null || true' EXIT
tool_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
command -v php >/dev/null || { echo 'PHP CLI required' >&2; exit 1; }
out=$(mktemp -d /tmp/sulb-metadata.XXXXXXXX)
php "$tool_dir/release_runtime_baseline.php" --metadata-only > "$out/runtime.json"
# Password comes from /dev/tty inside PHP; stdin carries neither password nor SQL.
# Authorization and collection use the same PDO session and fixed dedicated reader.
php "$tool_dir/release_metadata_collect.php" --metadata-only > "$out/schema.json"
{
  printf 'node: '; if command -v node >/dev/null; then node --version; else printf 'NOT_FOUND\n'; fi
  for browser in chromium chromium-browser google-chrome; do
    if command -v "$browser" >/dev/null; then "$browser" --version; fi
  done
  printf 'Scope: CLI runtime and visible database metadata only; FPM and complete metadata visibility not certified.\n'
} > "$out/tooling.txt"
tar -czf "$out/metadata.tar.gz" -C "$out" runtime.json schema.json tooling.txt
printf '\nMETADATA_FILE=%s/metadata.tar.gz\n' "$out"
printf 'No application bootstrap, business-row query, migration or service change executed.\n'
