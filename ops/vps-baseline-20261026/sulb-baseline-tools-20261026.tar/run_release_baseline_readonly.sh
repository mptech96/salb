#!/usr/bin/env bash
set -euo pipefail
umask 077
tool_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
command -v php >/dev/null || { echo 'PHP CLI required' >&2; exit 1; }
if command -v mariadb >/dev/null; then client=mariadb;
elif command -v mysql >/dev/null; then client=mysql;
else echo 'MariaDB/MySQL CLI required' >&2; exit 1; fi
read -r -p 'Production database name (not password): ' database
read -r -p 'Authorized metadata/read-only DB username: ' db_user
[[ -n "$database" && -n "$db_user" ]] || exit 2
out=$(mktemp -d /tmp/sulb-metadata.XXXXXXXX)
php "$tool_dir/release_runtime_baseline.php" --metadata-only > "$out/runtime.json"
# No defaults/login-path/environment credentials; password is entered at client prompt.
env -u MYSQL_PWD MYSQL_TEST_LOGIN_FILE=/dev/null "$client" --no-defaults \
  --host=localhost --user="$db_user" --password --database="$database" \
  --batch --raw < "$tool_dir/release_schema_baseline_readonly.sql" > "$out/schema.tsv"
{
  printf 'node: '; if command -v node >/dev/null; then node --version; else printf 'NOT_FOUND\n'; fi
  for browser in chromium chromium-browser google-chrome; do
    if command -v "$browser" >/dev/null; then "$browser" --version; fi
  done
  printf 'Scope: CLI runtime and visible database metadata only; FPM and complete metadata visibility not certified.\n'
} > "$out/tooling.txt"
tar -czf "$out/metadata.tar.gz" -C "$out" runtime.json schema.tsv tooling.txt
printf '\nMETADATA_FILE=%s/metadata.tar.gz\n' "$out"
printf 'No application bootstrap, business-row query, migration or service change executed.\n'
